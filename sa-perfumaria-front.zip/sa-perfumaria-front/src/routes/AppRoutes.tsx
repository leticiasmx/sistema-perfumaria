import { lazy, Suspense } from 'react';
import { Route, Routes } from 'react-router-dom';
import { StoreLayout } from '@/layouts/StoreLayout';
import { AdminLayout } from '@/layouts/AdminLayout';
import { ProtectedRoute } from './ProtectedRoute';
import { Loading } from '@/components/ui';

// Loja
const HomePage = lazy(() => import('@/pages/store/HomePage'));
const CatalogPage = lazy(() => import('@/pages/store/CatalogPage'));
const ProductDetailPage = lazy(() => import('@/pages/store/ProductDetailPage'));
const CartPage = lazy(() => import('@/pages/store/CartPage'));
const CheckoutPage = lazy(() => import('@/pages/store/CheckoutPage'));
const OrderSuccessPage = lazy(() => import('@/pages/store/OrderSuccessPage'));
const NotFoundPage = lazy(() => import('@/pages/store/NotFoundPage'));
// Painel
const LoginPage = lazy(() => import('@/pages/admin/LoginPage'));
const DashboardPage = lazy(() => import('@/pages/admin/DashboardPage'));
const ProductsPage = lazy(() => import('@/pages/admin/ProductsPage'));
const BrandsCategoriesPage = lazy(() => import('@/pages/admin/BrandsCategoriesPage'));
const StockPage = lazy(() => import('@/pages/admin/StockPage'));
const OrdersPage = lazy(() => import('@/pages/admin/OrdersPage'));
const CustomersPage = lazy(() => import('@/pages/admin/CustomersPage'));
const FinancialPage = lazy(() => import('@/pages/admin/FinancialPage'));
const InstallmentsPage = lazy(() => import('@/pages/admin/InstallmentsPage'));
const CouponsPage = lazy(() => import('@/pages/admin/CouponsPage'));
const ReportsPage = lazy(() => import('@/pages/admin/ReportsPage'));

export function AppRoutes() {
  return (
    <Suspense fallback={<Loading className="min-h-screen" />}>
      <Routes>
        <Route element={<StoreLayout />}>
          <Route index element={<HomePage />} />
          <Route path="catalogo" element={<CatalogPage />} />
          <Route path="produto/:id" element={<ProductDetailPage />} />
          <Route path="carrinho" element={<CartPage />} />
          <Route path="finalizar" element={<CheckoutPage />} />
          <Route path="pedido/confirmado" element={<OrderSuccessPage />} />
          <Route path="*" element={<NotFoundPage />} />
        </Route>

        <Route path="admin/login" element={<LoginPage />} />
        <Route path="admin" element={<ProtectedRoute />}>
          <Route element={<AdminLayout />}>
            <Route index element={<DashboardPage />} />
            <Route path="produtos" element={<ProductsPage />} />
            <Route path="marcas-categorias" element={<BrandsCategoriesPage />} />
            <Route path="estoque" element={<StockPage />} />
            <Route path="pedidos" element={<OrdersPage />} />
            <Route path="clientes" element={<CustomersPage />} />
            <Route path="financeiro" element={<FinancialPage />} />
            <Route path="parcelas" element={<InstallmentsPage />} />
            <Route path="cupons" element={<CouponsPage />} />
            <Route path="relatorios" element={<ReportsPage />} />
            <Route path="*" element={<NotFoundPage />} />
          </Route>
        </Route>
      </Routes>
    </Suspense>
  );
}
