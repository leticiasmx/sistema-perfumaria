import { useEffect, useState } from 'react';
import { Link, NavLink, Outlet, useLocation } from 'react-router-dom';
import {
  LayoutDashboard, Package, Tags, Boxes, ShoppingCart, Users, Wallet, CalendarClock, TicketPercent, FileBarChart,
  LogOut, Menu, X, Store,
} from 'lucide-react';
import { Logo, MockBanner } from '@/components/ui';
import { useAuth } from '@/contexts/AuthContext';
import { cn } from '@/utils/cn';

const groups = [
  { title: 'Visão geral', items: [{ to: '/admin', label: 'Dashboard', Icon: LayoutDashboard, end: true }] },
  { title: 'Vendas', items: [
    { to: '/admin/pedidos', label: 'Pedidos', Icon: ShoppingCart },
    { to: '/admin/clientes', label: 'Clientes', Icon: Users },
    { to: '/admin/cupons', label: 'Cupons e promoções', Icon: TicketPercent },
  ] },
  { title: 'Catálogo', items: [
    { to: '/admin/produtos', label: 'Produtos', Icon: Package },
    { to: '/admin/marcas-categorias', label: 'Marcas e categorias', Icon: Tags },
    { to: '/admin/estoque', label: 'Estoque', Icon: Boxes },
  ] },
  { title: 'Financeiro', items: [
    { to: '/admin/financeiro', label: 'Financeiro', Icon: Wallet },
    { to: '/admin/parcelas', label: 'Parcelas e cobranças', Icon: CalendarClock },
    { to: '/admin/relatorios', label: 'Relatórios', Icon: FileBarChart },
  ] },
];

function Sidebar({ onNavigate }: { onNavigate?: () => void }) {
  const { user, logout } = useAuth();
  return (
    <div className="flex h-full flex-col bg-wine-900 text-white/80">
      <div className="px-6 py-6"><Link to="/admin" onClick={onNavigate}><Logo light /></Link></div>
      <div className="gold-rule mx-6 opacity-50" />
      <nav className="flex-1 space-y-6 overflow-y-auto px-3 py-6">
        {groups.map((g) => (
          <div key={g.title}>
            <p className="px-3 pb-2 text-[10px] font-semibold uppercase tracking-[0.24em] text-gold/80">{g.title}</p>
            <ul className="space-y-0.5">
              {g.items.map(({ to, label, Icon, ...rest }) => (
                <li key={to}>
                  <NavLink to={to} end={'end' in rest} onClick={onNavigate}
                    className={({ isActive }) => cn('group relative flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition',
                      isActive ? 'bg-white/10 text-white' : 'hover:bg-white/5 hover:text-white')}>
                    {({ isActive }) => (
                      <>
                        {isActive && <span className="absolute inset-y-2 left-0 w-[3px] rounded-full bg-gold" />}
                        <Icon className={cn('size-[18px]', isActive ? 'text-gold' : 'text-white/50 group-hover:text-gold-light')} />
                        {label}
                      </>
                    )}
                  </NavLink>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </nav>
      <div className="border-t border-white/10 p-4">
        <Link to="/" target="_blank" className="mb-2 flex items-center gap-3 rounded-xl px-3 py-2 text-sm hover:bg-white/5"><Store className="size-4 text-gold-light" /> Ver loja</Link>
        <div className="flex items-center gap-3 rounded-xl bg-white/5 px-3 py-2.5">
          <span className="grid size-9 place-items-center rounded-full bg-gold font-display text-lg font-semibold text-wine-900">{user?.name?.charAt(0).toUpperCase() ?? 'V'}</span>
          <div className="min-w-0 flex-1"><p className="truncate text-sm font-semibold text-white">{user?.name ?? 'Vendedora'}</p><p className="truncate text-xs text-white/50">{user?.email}</p></div>
          <button onClick={logout} className="rounded-lg p-2 text-white/60 hover:bg-white/10 hover:text-white" aria-label="Sair"><LogOut className="size-4" /></button>
        </div>
      </div>
    </div>
  );
}

export function AdminLayout() {
  const [open, setOpen] = useState(false);
  const { pathname } = useLocation();
  useEffect(() => { setOpen(false); window.scrollTo({ top: 0 }); }, [pathname]);

  return (
    <div className="min-h-screen bg-ivory">
      <MockBanner />
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-68 lg:block"><Sidebar /></aside>
      {open && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 animate-fade-in bg-ink/50" onClick={() => setOpen(false)} />
          <aside className="absolute inset-y-0 left-0 w-72 animate-fade-up">
            <button onClick={() => setOpen(false)} className="absolute right-3 top-6 z-10 rounded-full p-2 text-white/70" aria-label="Fechar menu"><X className="size-5" /></button>
            <Sidebar onNavigate={() => setOpen(false)} />
          </aside>
        </div>
      )}
      <div className="lg:pl-68">
        <header className="sticky top-0 z-20 flex items-center gap-3 border-b border-line bg-white/85 px-4 py-3 backdrop-blur lg:hidden">
          <button onClick={() => setOpen(true)} className="rounded-full p-2" aria-label="Abrir menu"><Menu className="size-6" /></button>
          <Logo compact /> <span className="font-display text-xl font-semibold text-wine-900">Painel</span>
        </header>
        <main className="mx-auto max-w-[1400px] px-4 py-8 sm:px-8 lg:py-10"><Outlet /></main>
      </div>
    </div>
  );
}
