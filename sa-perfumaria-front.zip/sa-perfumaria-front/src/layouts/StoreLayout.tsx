import { Outlet, useLocation } from 'react-router-dom';
import { useEffect } from 'react';
import { StoreHeader } from '@/components/store/StoreHeader';
import { StoreFooter } from '@/components/store/StoreFooter';
import { WhatsAppFloat } from '@/components/store/WhatsAppFloat';
import { MockBanner } from '@/components/ui';

export function StoreLayout() {
  const { pathname } = useLocation();
  useEffect(() => { window.scrollTo({ top: 0 }); }, [pathname]);
  return (
    <div className="flex min-h-screen flex-col">
      <MockBanner />
      <StoreHeader />
      <main className="flex-1">
        <Outlet />
      </main>
      <StoreFooter />
      <WhatsAppFloat />
    </div>
  );
}
