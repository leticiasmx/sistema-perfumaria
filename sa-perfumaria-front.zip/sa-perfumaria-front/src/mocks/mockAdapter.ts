/**
 * 🧪 ADAPTADOR DE MOCKS — SOMENTE DESENVOLVIMENTO
 * ------------------------------------------------------------------
 * Intercepta as requisições da instância Axios quando VITE_USE_MOCKS=true
 * e responde com dados fictícios em memória (perdidos ao recarregar).
 * Os serviços reais NÃO sabem que os mocks existem.
 *
 * Para remover: apague a pasta src/mocks e o bloco "mocks" em src/main.tsx.
 * Login de demonstração: qualquer e-mail + senha "demo123".
 */
import { AxiosError, AxiosHeaders, type AxiosInstance, type AxiosResponse, type InternalAxiosRequestConfig } from 'axios';
import * as db from './data';
import type {
  Customer, Dashboard, Installment, Order, Product, ProductPayload, ReportResult, ReportType,
} from '@/interfaces';
import { daysUntil, parseDate, toISODate } from '@/utils/format';

type Params = Record<string, string | undefined>;
type Handler = (ctx: { params: Params; query: Params; body: any }) => unknown;

const routes: { method: string; pattern: RegExp; keys: string[]; handler: Handler }[] = [];
function route(method: string, path: string, handler: Handler) {
  const keys: string[] = [];
  const pattern = new RegExp('^' + path.replace(/:(\w+)/g, (_, k) => (keys.push(k), '([^/]+)')) + '$');
  routes.push({ method, pattern, keys, handler });
}

class HttpError extends Error {
  constructor(public status: number, message: string) { super(message); }
}

let nextId = 5000;
const newId = () => ++nextId;
const same = (a: unknown, b: unknown) => String(a) === String(b);
const inPeriod = (dateStr: string, q: Params) => {
  const v = dateStr.slice(0, 10);
  return (!q.from || v >= q.from) && (!q.to || v <= q.to);
};
const isLow = (p: Product) => p.stockQuantity <= p.minimumStock;
const effectivePrice = (p: Product) => p.promotionalPrice ?? p.price;

function buildProduct(payload: ProductPayload, base?: Product): Product {
  return {
    ...(base ?? { id: newId(), imageUrl: null, soldQuantity: 0 }),
    ...payload,
    brand: db.brands.find((b) => same(b.id, payload.brandId)) ?? null,
    category: db.categories.find((c) => same(c.id, payload.categoryId)) ?? null,
  } as Product;
}

/* -------- Auth -------- */
route('post', '/auth/login', ({ body }) => {
  if (body?.password !== 'demo123') throw new HttpError(401, 'E-mail ou senha inválidos.');
  return { token: 'mock-token', user: { id: 1, name: 'Vendedora (demo)', email: body.email } };
});
route('get', '/auth/me', () => ({ id: 1, name: 'Vendedora (demo)', email: 'demo@loja.com' }));

/* -------- Catálogo -------- */
route('get', '/products', ({ query }) =>
  db.products
    .filter((p) => !query.name || p.name.toLowerCase().includes(query.name.toLowerCase()))
    .filter((p) => !query.brandId || same(p.brand?.id, query.brandId))
    .filter((p) => !query.categoryId || same(p.category?.id, query.categoryId))
    .filter((p) => query.featured !== 'true' || p.featured)
    .sort((a, b) => (query.sort === 'bestsellers' ? (b.soldQuantity ?? 0) - (a.soldQuantity ?? 0) : 0)),
);
route('get', '/products/:id', ({ params }) => {
  const p = db.products.find((x) => same(x.id, params.id));
  if (!p) throw new HttpError(404, 'Produto não encontrado.');
  return p;
});
route('post', '/products', ({ body }) => {
  const p = buildProduct(body);
  db.products.unshift(p);
  return p;
});
route('put', '/products/:id', ({ params, body }) => {
  const i = db.products.findIndex((x) => same(x.id, params.id));
  if (i < 0) throw new HttpError(404, 'Produto não encontrado.');
  db.products[i] = buildProduct(body, db.products[i]);
  return db.products[i];
});
route('delete', '/products/:id', ({ params }) => {
  const i = db.products.findIndex((x) => same(x.id, params.id));
  if (i >= 0) db.products.splice(i, 1);
  return null;
});
route('post', '/products/:id/image', ({ params, body }) => {
  const p = db.products.find((x) => same(x.id, params.id));
  if (!p) throw new HttpError(404, 'Produto não encontrado.');
  const file = (body as FormData)?.get?.('file');
  if (file instanceof File) p.imageUrl = URL.createObjectURL(file);
  return p;
});

for (const [path, list] of [['/brands', db.brands], ['/categories', db.categories]] as const) {
  route('get', path, () => list);
  route('post', path, ({ body }) => { const it = { id: newId(), name: body.name }; list.push(it); return it; });
  route('put', `${path}/:id`, ({ params, body }) => {
    const it = list.find((x) => same(x.id, params.id));
    if (!it) throw new HttpError(404, 'Registro não encontrado.');
    it.name = body.name;
    return it;
  });
  route('delete', `${path}/:id`, ({ params }) => {
    const field = path === '/brands' ? 'brand' : 'category';
    if (db.products.some((p) => same(p[field]?.id, params.id)))
      throw new HttpError(409, 'Existem produtos vinculados a este registro.');
    const i = list.findIndex((x) => same(x.id, params.id));
    if (i >= 0) list.splice(i, 1);
    return null;
  });
}

/* -------- Clientes -------- */
route('get', '/customers', ({ query }) => {
  const s = (query.search || '').toLowerCase();
  const digits = s.replace(/\D/g, '');
  return db.customers.filter((c) => !s || c.name.toLowerCase().includes(s) || (digits && c.phone.includes(digits)));
});
route('get', '/customers/birthdays', ({ query }) =>
  db.customers.filter((c) => (parseDate(c.birthDate)?.getMonth() ?? -1) + 1 === Number(query.month)),
);
route('get', '/customers/phone/:phone', ({ params }) => {
  const c = db.customers.find((x) => x.phone === params.phone);
  if (!c) throw new HttpError(404, 'Cliente não encontrado.');
  return c;
});
route('get', '/customers/:id/orders', ({ params }) => db.orders.filter((o) => same(o.customer.id, params.id)));

/* -------- Pedidos -------- */
route('post', '/orders', ({ body }) => {
  let customer: Customer | undefined = db.customers.find((c) => c.phone === body.customer.phone);
  if (!customer) {
    customer = { id: newId(), ...body.customer, totalSpent: 0, ordersCount: 0, lastOrderDate: null };
    db.customers.push(customer!);
  }
  const items = body.items.map((it: { productId: number; quantity: number }) => {
    const p = db.products.find((x) => same(x.id, it.productId));
    if (!p) throw new HttpError(400, 'Produto inválido no carrinho.');
    if (p.stockQuantity < it.quantity) throw new HttpError(409, `Estoque insuficiente para ${p.name}.`);
    return { productId: p.id, productName: p.name, quantity: it.quantity, unitPrice: effectivePrice(p), subtotal: +(effectivePrice(p) * it.quantity).toFixed(2) };
  });
  const subtotal = +items.reduce((s: number, it: { subtotal: number }) => s + it.subtotal, 0).toFixed(2);
  const discount = body.couponCode ? couponDiscount(body.couponCode, subtotal).discount : 0;
  const id = newId();
  const order: Order = {
    id, number: `PED-${id}`, customer: { id: customer!.id, name: customer!.name, phone: customer!.phone },
    createdAt: new Date().toISOString(), items, subtotal, discount, total: +(subtotal - discount).toFixed(2),
    paymentMethod: body.paymentMethod, installments: body.installments || 1, status: 'PENDENTE', couponCode: body.couponCode ?? null,
  };
  db.orders.unshift(order);
  db.orderHistory[String(id)] = [{ id: 1, status: 'PENDENTE', changedAt: order.createdAt, note: 'Pedido recebido pela loja virtual' }];
  return order;
});
route('get', '/orders', ({ query }) =>
  db.orders
    .filter((o) => !query.status || o.status === query.status)
    .filter((o) => !query.customerId || same(o.customer.id, query.customerId))
    .filter((o) => inPeriod(o.createdAt, query)),
);
route('get', '/orders/:id', ({ params }) => {
  const o = db.orders.find((x) => same(x.id, params.id));
  if (!o) throw new HttpError(404, 'Pedido não encontrado.');
  return o;
});
route('get', '/orders/:id/history', ({ params }) => db.orderHistory[String(params.id)] ?? []);
const changeStatus = (id: string | undefined, status: Order['status'], note?: string) => {
  const o = db.orders.find((x) => same(x.id, id));
  if (!o) throw new HttpError(404, 'Pedido não encontrado.');
  if (o.status === 'CANCELADO') throw new HttpError(409, 'Pedido cancelado não pode ser alterado.');
  o.status = status;
  (db.orderHistory[String(o.id)] ??= []).push({ id: newId(), status, changedAt: new Date().toISOString(), note: note ?? null });
  return o;
};
route('patch', '/orders/:id/status', ({ params, body }) => changeStatus(params.id, body.status));
route('patch', '/orders/:id/cancel', ({ params, body }) => changeStatus(params.id, 'CANCELADO', body?.reason));

/* -------- Estoque -------- */
route('get', '/stock', () => db.products);
route('get', '/stock/low', () => db.products.filter(isLow));
route('get', '/stock/movements', ({ query }) =>
  db.movements
    .filter((m) => !query.productId || same(m.productId, query.productId))
    .filter((m) => !query.type || m.type === query.type)
    .filter((m) => inPeriod(m.date, query)),
);
route('post', '/stock/entries', ({ body }) => {
  const p = db.products.find((x) => same(x.id, body.productId));
  if (!p) throw new HttpError(404, 'Produto não encontrado.');
  p.stockQuantity += Number(body.quantity);
  const m = { id: newId(), productId: p.id, productName: p.name, type: 'ENTRADA' as const, quantity: Number(body.quantity), date: new Date().toISOString(), note: body.note || null };
  db.movements.unshift(m);
  return m;
});

/* -------- Financeiro -------- */
function monthly(query: Params) {
  const months: string[] = [];
  const end = parseDate(query.to) ?? new Date();
  // Mock: sempre mostra os 6 meses até o fim do período, para os gráficos mensais terem histórico.
  const start = new Date(end.getFullYear(), end.getMonth() - 5, 1);
  for (let dt = new Date(start.getFullYear(), start.getMonth(), 1); dt <= end; dt.setMonth(dt.getMonth() + 1))
    months.push(toISODate(dt).slice(0, 7));
  return months.map((month) => ({
    month,
    revenue: +db.revenues.filter((r) => r.date.startsWith(month)).reduce((s, r) => s + r.amount, 0).toFixed(2),
    expenses: +db.expenses.filter((e) => e.date.startsWith(month)).reduce((s, e) => s + e.amount, 0).toFixed(2),
  }));
}
function summary(query: Params) {
  const rev = db.revenues.filter((r) => inPeriod(r.date, query));
  const exp = db.expenses.filter((e) => inPeriod(e.date, query));
  const revenue = rev.reduce((s, r) => s + r.amount, 0);
  const totalExpenses = exp.reduce((s, e) => s + e.amount, 0);
  const receivable = db.installments.filter((i) => i.status !== 'PAGA').reduce((s, i) => s + i.amount, 0);
  return {
    revenue: +revenue.toFixed(2), totalIncome: +revenue.toFixed(2), totalExpenses: +totalExpenses.toFixed(2),
    profit: +(revenue - totalExpenses).toFixed(2), received: +rev.filter((r) => r.received).reduce((s, r) => s + r.amount, 0).toFixed(2),
    receivable: +receivable.toFixed(2),
  };
}
route('get', '/financial/summary', ({ query }) => summary(query));
route('get', '/financial/monthly', ({ query }) => monthly(query));
route('get', '/financial/revenues', ({ query }) =>
  db.revenues.filter((r) => inPeriod(r.date, query)).filter((r) => query.received === undefined || String(r.received) === query.received),
);
route('post', '/financial/revenues', ({ body }) => { const r = { id: newId(), orderId: null, ...body }; db.revenues.unshift(r); return r; });
route('get', '/financial/expenses', ({ query }) =>
  db.expenses.filter((e) => inPeriod(e.date, query)).filter((e) => !query.type || e.type === query.type),
);
route('post', '/financial/expenses', ({ body }) => { const e = { id: newId(), ...body }; db.expenses.unshift(e); return e; });

/* -------- Parcelas -------- */
route('get', '/installments', ({ query }) =>
  db.installments
    .filter((i) => !query.status || i.status === query.status)
    .filter((i) => !query.customerId || same(i.customer.id, query.customerId))
    .sort((a, b) => a.dueDate.localeCompare(b.dueDate)),
);
route('patch', '/installments/:id/pay', ({ params, body }) => {
  const i = db.installments.find((x) => same(x.id, params.id));
  if (!i) throw new HttpError(404, 'Parcela não encontrada.');
  if (i.status === 'PAGA') throw new HttpError(409, 'Esta parcela já foi paga.');
  Object.assign(i, { status: 'PAGA', paymentDate: body.paymentDate, amount: body.amount ?? i.amount });
  return i;
});

/* -------- Cupons e promoções -------- */
function couponDiscount(code: string, subtotal: number) {
  const c = db.coupons.find((x) => x.code.toUpperCase() === String(code).toUpperCase());
  const t = toISODate(new Date());
  if (!c || !c.active || (c.validUntil && c.validUntil < t) || (c.validFrom && c.validFrom > t))
    return { valid: false, code, discount: 0, message: 'Cupom inválido ou expirado.' };
  if (c.minimumOrderValue && subtotal < c.minimumOrderValue)
    return { valid: false, code, discount: 0, message: `Pedido mínimo de R$ ${c.minimumOrderValue.toFixed(2).replace('.', ',')} para este cupom.` };
  const discount = c.discountType === 'PERCENTUAL' ? (subtotal * c.discountValue) / 100 : Math.min(c.discountValue, subtotal);
  return { valid: true, code: c.code, discount: +discount.toFixed(2), message: 'Cupom aplicado!' };
}
route('post', '/coupons/validate', ({ body }) => couponDiscount(body.code, Number(body.subtotal)));
for (const [path, list] of [['/coupons', db.coupons], ['/promotions', db.promotions]] as const) {
  route('get', path, () => list);
  route('post', path, ({ body }) => { const it = { id: newId(), timesUsed: 0, ...body }; (list as any[]).unshift(it); return it; });
  route('put', `${path}/:id`, ({ params, body }) => {
    const it = (list as any[]).find((x) => same(x.id, params.id));
    if (!it) throw new HttpError(404, 'Registro não encontrado.');
    Object.assign(it, body);
    return it;
  });
  route('delete', `${path}/:id`, ({ params }) => {
    const i = (list as any[]).findIndex((x) => same(x.id, params.id));
    if (i >= 0) list.splice(i, 1);
    return null;
  });
}

/* -------- Dashboard -------- */
route('get', '/dashboard', ({ query }): Dashboard => {
  const valid = db.orders.filter((o) => o.status !== 'CANCELADO' && inPeriod(o.createdAt, query));
  const s = summary(query);
  const byDay = new Map<string, number>();
  valid.forEach((o) => byDay.set(o.createdAt.slice(0, 10), (byDay.get(o.createdAt.slice(0, 10)) ?? 0) + o.total));
  const top = new Map<string, { productId: number | string; name: string; quantity: number }>();
  valid.flatMap((o) => o.items).forEach((it) => {
    const cur = top.get(String(it.productId)) ?? { productId: it.productId, name: it.productName ?? '', quantity: 0 };
    cur.quantity += it.quantity;
    top.set(String(it.productId), cur);
  });
  const mon = monthly(query);
  return {
    monthRevenue: s.revenue,
    monthProfit: s.profit,
    totalOrders: valid.length,
    pendingOrders: db.orders.filter((o) => o.status === 'PENDENTE').length,
    receivable: s.receivable,
    overdueInstallments: db.installments.filter((i) => i.status === 'VENCIDA').length,
    lowStockProducts: db.products.filter(isLow).length,
    salesByPeriod: [...byDay.entries()].sort().map(([date, total]) => ({ date, total: +total.toFixed(2) })),
    monthlyRevenue: mon.map(({ month, revenue }) => ({ month, revenue })),
    incomeVsExpenses: mon,
    topProducts: [...top.values()].sort((a, b) => b.quantity - a.quantity).slice(0, 6),
    latestOrders: db.orders.slice(0, 6),
    upcomingInstallments: db.installments.filter((i) => i.status !== 'PAGA' && daysUntil(i.dueDate) <= 15).slice(0, 6) as Installment[],
    birthdayCustomers: db.customers.filter((c) => parseDate(c.birthDate)?.getMonth() === new Date().getMonth()),
    stockAlerts: db.products.filter(isLow),
  };
});

/* -------- Relatórios -------- */
function report(type: ReportType, q: Params): ReportResult {
  switch (type) {
    case 'sales': {
      const rows = db.orders.filter((o) => inPeriod(o.createdAt, q)).map((o) => ({ number: o.number, customer: o.customer.name, date: o.createdAt, status: o.status, total: o.total }));
      return { columns: [{ key: 'number', label: 'Pedido' }, { key: 'customer', label: 'Cliente' }, { key: 'date', label: 'Data', type: 'date' }, { key: 'status', label: 'Status' }, { key: 'total', label: 'Total', type: 'money' }], rows, totals: { total: rows.filter((r) => r.status !== 'CANCELADO').reduce((s, r) => s + r.total, 0) } };
    }
    case 'financial':
      return { columns: [{ key: 'month', label: 'Mês' }, { key: 'revenue', label: 'Receitas', type: 'money' }, { key: 'expenses', label: 'Despesas', type: 'money' }, { key: 'profit', label: 'Resultado', type: 'money' }], rows: monthly(q).map((m) => ({ ...m, profit: +(m.revenue - m.expenses).toFixed(2) })) };
    case 'top-products':
      return { columns: [{ key: 'name', label: 'Produto' }, { key: 'brand', label: 'Marca' }, { key: 'sold', label: 'Vendidos', type: 'number' }], rows: [...db.products].sort((a, b) => (b.soldQuantity ?? 0) - (a.soldQuantity ?? 0)).map((p) => ({ name: p.name, brand: p.brand?.name, sold: p.soldQuantity })) };
    case 'stock':
      return { columns: [{ key: 'name', label: 'Produto' }, { key: 'stock', label: 'Em estoque', type: 'number' }, { key: 'min', label: 'Mínimo', type: 'number' }, { key: 'value', label: 'Valor em estoque', type: 'money' }], rows: db.products.map((p) => ({ name: p.name, stock: p.stockQuantity, min: p.minimumStock, value: +((p.costPrice ?? 0) * p.stockQuantity).toFixed(2) })) };
    case 'customers':
      return { columns: [{ key: 'name', label: 'Cliente' }, { key: 'phone', label: 'Telefone' }, { key: 'orders', label: 'Pedidos', type: 'number' }, { key: 'spent', label: 'Total comprado', type: 'money' }], rows: db.customers.map((c) => ({ name: c.name, phone: c.phone, orders: c.ordersCount, spent: c.totalSpent })) };
    case 'installments':
      return { columns: [{ key: 'customer', label: 'Cliente' }, { key: 'parcel', label: 'Parcela' }, { key: 'due', label: 'Vencimento', type: 'date' }, { key: 'status', label: 'Status' }, { key: 'amount', label: 'Valor', type: 'money' }], rows: db.installments.map((i) => ({ customer: i.customer.name, parcel: `${i.number}/${i.totalInstallments}`, due: i.dueDate, status: i.status, amount: i.amount })) };
  }
}
route('get', '/reports/:type', ({ params, query }) => report(params.type as ReportType, query));
route('get', '/reports/:type/export', ({ params, query }) => {
  const r = report(params.type as ReportType, query);
  const csv = [r.columns.map((c) => c.label).join(';'), ...r.rows.map((row) => r.columns.map((c) => String(row[c.key] ?? '')).join(';'))].join('\n');
  return new Blob(['﻿' + csv], { type: 'text/csv;charset=utf-8' });
});

/* -------- Adaptador -------- */
export function installMocks(instance: AxiosInstance) {
  instance.defaults.adapter = async (config: InternalAxiosRequestConfig): Promise<AxiosResponse> => {
    await new Promise((r) => setTimeout(r, 250 + Math.random() * 250));
    const url = (config.url || '').replace(/^https?:\/\/[^/]+/, '').split('?')[0];
    const method = (config.method || 'get').toLowerCase();
    const query: Params = Object.fromEntries(Object.entries(config.params ?? {}).map(([k, v]) => [k, v == null ? undefined : String(v)]));
    let body: any = config.data;
    if (typeof body === 'string') { try { body = JSON.parse(body); } catch { /* mantém */ } }

    const respond = (status: number, data: unknown): AxiosResponse => ({ data, status, statusText: String(status), headers: new AxiosHeaders(), config });
    for (const r of routes) {
      const m = r.method === method && r.pattern.exec(url);
      if (!m) continue;
      try {
        const params = Object.fromEntries(r.keys.map((k, i) => [k, decodeURIComponent(m[i + 1])]));
        const data = structuredCloneSafe(r.handler({ params, query, body }));
        return respond(data === null ? 204 : 200, data);
      } catch (e) {
        const status = e instanceof HttpError ? e.status : 500;
        const res = respond(status, { message: (e as Error).message });
        throw new AxiosError((e as Error).message, String(status), config, null, res);
      }
    }
    const res = respond(404, { message: `[mock] rota não simulada: ${method.toUpperCase()} ${url}` });
    throw new AxiosError(res.data.message, '404', config, null, res);
  };
  console.info('%c[mocks] Dados fictícios ativos (VITE_USE_MOCKS=true)', 'color:#A6192E;font-weight:bold');
}

/** Copia objetos para que a UI não altere o "banco" em memória por referência. */
function structuredCloneSafe<T>(v: T): T {
  if (v instanceof Blob || v === null || v === undefined) return v;
  return JSON.parse(JSON.stringify(v));
}
