/**
 * 🧪 DADOS FICTÍCIOS — SOMENTE DESENVOLVIMENTO
 * Usados apenas quando VITE_USE_MOCKS=true. Não representam dados reais.
 * Pode apagar a pasta src/mocks inteira sem afetar o restante do código.
 */
import type {
  Brand, Category, Coupon, Customer, Expense, Installment, Order, OrderHistoryEntry,
  OrderStatus, PaymentMethod, Product, Promotion, Revenue, StockMovement,
} from '@/interfaces';
import { toISODate } from '@/utils/format';

const day = 86_400_000;
const now = new Date();
const iso = (offsetDays: number) => new Date(now.getTime() + offsetDays * day).toISOString();
const d = (offsetDays: number) => toISODate(new Date(now.getTime() + offsetDays * day));

let seed = 7;
const rand = () => ((seed = (seed * 16807) % 2147483647) - 1) / 2147483646;
const pick = <T,>(arr: T[]) => arr[Math.floor(rand() * arr.length)];

export const brands: Brand[] = ['O Boticário', 'Natura', 'Eudora', 'Avon', 'Quem Disse, Berenice?', 'Mary Kay'].map(
  (name, i) => ({ id: i + 1, name }),
);

export const categories: Category[] = ['Perfumaria', 'Maquiagem', 'Cuidados com a pele', 'Cabelos', 'Corpo e banho', 'Revistas'].map(
  (name, i) => ({ id: i + 1, name }),
);

const productSeed: [string, number, number, number, number | null, number, string][] = [
  ['Colônia Floral Intensa 100ml', 1, 1, 189.9, 159.9, 14, 'Fragrância floral com notas de jasmim, peônia e almíscar.'],
  ['Desodorante Colônia Amadeirado 75ml', 2, 1, 154.9, null, 3, 'Notas amadeiradas e especiadas para o dia a dia.'],
  ['Batom Matte Veludo — Vermelho Clássico', 3, 2, 49.9, 39.9, 22, 'Alta cobertura, acabamento aveludado e longa duração.'],
  ['Base Líquida Cobertura Natural', 4, 2, 64.9, null, 2, 'Textura leve, FPS 20, acabamento natural.'],
  ['Sérum Facial Vitamina C 30ml', 2, 3, 119.9, 99.9, 9, 'Uniformiza o tom e ilumina a pele.'],
  ['Hidratante Facial Ácido Hialurônico', 1, 3, 89.9, null, 0, 'Hidratação intensa por até 48 horas.'],
  ['Kit Shampoo e Condicionador Reparação', 3, 4, 79.9, 64.9, 11, 'Recupera fios danificados e devolve o brilho.'],
  ['Óleo Corporal Desodorante 200ml', 2, 5, 69.9, null, 18, 'Pele perfumada e macia após o banho.'],
  ['Hidratante Corporal Frutas Vermelhas', 4, 5, 34.9, 27.9, 4, 'Hidratação com fragrância frutada.'],
  ['Máscara de Cílios Volume Extremo', 5, 2, 42.9, null, 16, 'Volume e curvatura sem grumos.'],
  ['Perfume Feminino Eau de Parfum 50ml', 3, 1, 249.9, null, 6, 'Oriental floral marcante para ocasiões especiais.'],
  ['Revista Catálogo — Ciclo Atual', 4, 6, 5.0, null, 40, 'Catálogo com todas as ofertas do ciclo.'],
];

export const products: Product[] = productSeed.map(([name, brandId, categoryId, price, promo, stock, description], i) => ({
  id: i + 1,
  name,
  description,
  price,
  promotionalPrice: promo,
  costPrice: Math.round(price * 0.62 * 100) / 100,
  stockQuantity: stock,
  minimumStock: 5,
  imageUrl: null,
  brand: brands[brandId - 1],
  category: categories[categoryId - 1],
  featured: i % 3 === 0,
  active: true,
  soldQuantity: Math.round(rand() * 60) + 5,
}));

const people = ['Ana Paula Ribeiro', 'Juliana Martins', 'Fernanda Costa', 'Mariana Alves', 'Patrícia Souza', 'Camila Rocha', 'Beatriz Lima', 'Renata Oliveira'];
export const customers: Customer[] = people.map((name, i) => ({
  id: i + 1,
  name,
  phone: `119${String(87654321 + i * 1111).slice(0, 8)}`,
  birthDate: toISODate(new Date(1980 + i * 2, i < 3 ? now.getMonth() : (now.getMonth() + i) % 12, 5 + i * 3)),
  totalSpent: 0,
  ordersCount: 0,
  lastOrderDate: null,
}));

const statuses: OrderStatus[] = ['PENDENTE', 'CONFIRMADO', 'EM_SEPARACAO', 'ENTREGUE', 'ENTREGUE', 'ENTREGUE', 'CANCELADO'];
const methods: PaymentMethod[] = ['PIX', 'CARTAO_CREDITO', 'CREDIARIO', 'DINHEIRO', 'CREDIARIO'];

export const orders: Order[] = [];
export const installments: Installment[] = [];
export const orderHistory: Record<string, OrderHistoryEntry[]> = {};
export const movements: StockMovement[] = [];

for (let i = 0; i < 26; i++) {
  const c = pick(customers);
  const items = Array.from({ length: 1 + Math.floor(rand() * 3) }, () => {
    const p = pick(products);
    const q = 1 + Math.floor(rand() * 2);
    const unit = p.promotionalPrice ?? p.price;
    return { productId: p.id, productName: p.name, quantity: q, unitPrice: unit, subtotal: +(unit * q).toFixed(2) };
  });
  const subtotal = +items.reduce((s, it) => s + it.subtotal, 0).toFixed(2);
  const method = pick(methods);
  const n = method === 'CREDIARIO' ? 3 : method === 'CARTAO_CREDITO' ? 2 : 1;
  const offset = -Math.floor(i * 6.5) - 1;
  const status = i < 3 ? 'PENDENTE' : pick(statuses);
  const order: Order = {
    id: 1000 + i,
    number: `PED-${1000 + i}`,
    customer: { id: c.id, name: c.name, phone: c.phone },
    createdAt: iso(offset),
    items,
    subtotal,
    discount: 0,
    total: subtotal,
    paymentMethod: method,
    installments: n,
    status,
  };
  orders.push(order);
  orderHistory[String(order.id)] = [{ id: 1, status: 'PENDENTE', changedAt: order.createdAt, note: 'Pedido recebido pela loja virtual' }];
  if (status !== 'PENDENTE' && status !== 'CANCELADO')
    orderHistory[String(order.id)].push({ id: 2, status, changedAt: iso(offset + 1), note: null });
  if (status !== 'CANCELADO') {
    c.totalSpent = +((c.totalSpent ?? 0) + order.total).toFixed(2);
    c.ordersCount = (c.ordersCount ?? 0) + 1;
    if (!c.lastOrderDate || c.lastOrderDate < order.createdAt) c.lastOrderDate = order.createdAt;
    items.forEach((it) =>
      movements.push({ id: movements.length + 1, productId: it.productId, productName: it.productName!, type: 'SAIDA', quantity: it.quantity, date: order.createdAt, orderId: order.id, note: `Pedido ${order.number}` }),
    );
  }
  if (method === 'CREDIARIO' && status !== 'CANCELADO') {
    for (let k = 1; k <= n; k++) {
      const due = offset + k * 30;
      const paid = due < -3 && rand() > 0.25;
      installments.push({
        id: installments.length + 1,
        orderId: order.id,
        customer: order.customer,
        number: k,
        totalInstallments: n,
        amount: +(order.total / n).toFixed(2),
        dueDate: d(due),
        paymentDate: paid ? d(due - 1) : null,
        status: paid ? 'PAGA' : due < 0 ? 'VENCIDA' : 'EM_ABERTO',
      });
    }
  }
}

products.slice(0, 6).forEach((p, i) =>
  movements.push({ id: movements.length + 1, productId: p.id, productName: p.name, type: 'ENTRADA', quantity: 10 + i * 2, date: iso(-40 + i * 3), note: 'Reposição do ciclo' }),
);
movements.sort((a, b) => b.date.localeCompare(a.date));

export const expenses: Expense[] = Array.from({ length: 14 }, (_, i) => ({
  id: i + 1,
  description: i % 2 ? 'Compra de mercadorias — pedido do ciclo' : pick(['Embalagens e sacolas', 'Combustível de entregas', 'Taxa da maquininha', 'Internet e celular']),
  amount: i % 2 ? 400 + Math.round(rand() * 600) : 40 + Math.round(rand() * 140),
  date: d(-i * 12 - 2),
  type: i % 2 ? 'COMPRA_MERCADORIA' : 'DESPESA',
  category: i % 2 ? 'Mercadorias' : 'Operacional',
}));

export const revenues: Revenue[] = orders
  .filter((o) => o.status !== 'CANCELADO')
  .map((o, i) => ({
    id: i + 1,
    description: `Venda ${o.number}`,
    amount: o.total,
    date: o.createdAt.slice(0, 10),
    orderId: o.id,
    received: o.paymentMethod !== 'CREDIARIO',
  }));

export const coupons: Coupon[] = [
  { id: 1, code: 'BEMVINDA10', discountType: 'PERCENTUAL', discountValue: 10, validFrom: d(-30), validUntil: d(60), minimumOrderValue: 80, usageLimit: 100, timesUsed: 12, active: true },
  { id: 2, code: 'FRETE15', discountType: 'VALOR', discountValue: 15, validFrom: d(-10), validUntil: d(20), minimumOrderValue: 120, usageLimit: null, timesUsed: 4, active: true },
  { id: 3, code: 'NATAL25', discountType: 'PERCENTUAL', discountValue: 25, validFrom: d(-400), validUntil: d(-300), minimumOrderValue: null, usageLimit: 50, timesUsed: 50, active: false },
];

export const promotions: Promotion[] = [
  { id: 1, name: 'Semana da Perfumaria', scope: 'PRODUTO', discountType: 'PERCENTUAL', discountValue: 15, productIds: [1, 11], startDate: d(-3), endDate: d(10), active: true },
  { id: 2, name: 'Compre acima de R$ 200', scope: 'PEDIDO', discountType: 'VALOR', discountValue: 20, startDate: d(-1), endDate: d(30), active: true },
];
