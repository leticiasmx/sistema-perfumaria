/**
 * ⚠️ TIPOS PROVISÓRIOS
 * ------------------------------------------------------------------
 * Estes tipos representam o que o front-end espera receber/enviar.
 * Eles NÃO foram gerados a partir dos DTOs Java (que não estavam
 * disponíveis). Ao receber o back-end, alinhe cada interface com o
 * DTO correspondente — os nomes dos campos aqui devem ser IGUAIS aos
 * do JSON da API. Não renomeie campos da API para caber no front.
 */

export type Id = number | string;

/** Formato padrão de paginação do Spring Data (Page<T>). */
export interface Page<T> {
  content: T[];
  totalElements: number;
  totalPages: number;
  number: number;
  size: number;
}

export interface Period {
  from?: string; // yyyy-MM-dd
  to?: string;
}

/* ---------------- Auth ---------------- */
export interface LoginRequest {
  email: string;
  password: string;
}
export interface AuthUser {
  id: Id;
  name: string;
  email: string;
  role?: string;
}
export interface LoginResponse {
  token: string;
  user?: AuthUser;
}

/* ---------------- Catálogo ---------------- */
export interface Brand {
  id: Id;
  name: string;
  logoUrl?: string | null;
}
export interface Category {
  id: Id;
  name: string;
}
export interface Product {
  id: Id;
  name: string;
  description?: string | null;
  price: number;
  promotionalPrice?: number | null;
  costPrice?: number | null;
  stockQuantity: number;
  minimumStock: number;
  imageUrl?: string | null;
  brand?: Brand | null;
  category?: Category | null;
  featured?: boolean;
  active?: boolean;
  soldQuantity?: number;
}
export interface ProductPayload {
  name: string;
  description?: string;
  price: number;
  promotionalPrice?: number | null;
  costPrice?: number | null;
  stockQuantity: number;
  minimumStock: number;
  brandId: Id;
  categoryId: Id;
  featured?: boolean;
  active?: boolean;
}
export interface ProductFilters {
  name?: string;
  brandId?: Id;
  categoryId?: Id;
  featured?: boolean;
  sort?: string;
}

/* ---------------- Clientes ---------------- */
export interface Customer {
  id: Id;
  name: string;
  phone: string;
  birthDate?: string | null; // yyyy-MM-dd
  totalSpent?: number;
  ordersCount?: number;
  lastOrderDate?: string | null;
}
export interface CustomerPayload {
  name: string;
  phone: string;
  birthDate?: string | null;
}

/* ---------------- Pedidos ---------------- */
export type PaymentMethod = 'PIX' | 'DINHEIRO' | 'CARTAO_DEBITO' | 'CARTAO_CREDITO' | 'CREDIARIO';
export type OrderStatus = 'PENDENTE' | 'CONFIRMADO' | 'EM_SEPARACAO' | 'ENTREGUE' | 'CANCELADO';

export interface OrderItem {
  productId: Id;
  productName?: string;
  quantity: number;
  unitPrice?: number;
  subtotal?: number;
}
export interface Order {
  id: Id;
  number?: string;
  customer: Pick<Customer, 'id' | 'name' | 'phone'>;
  createdAt: string;
  items: OrderItem[];
  subtotal: number;
  discount: number;
  total: number;
  paymentMethod: PaymentMethod;
  installments: number;
  status: OrderStatus;
  couponCode?: string | null;
}
export interface CreateOrderPayload {
  customer: CustomerPayload & { id?: Id };
  items: { productId: Id; quantity: number }[];
  paymentMethod: PaymentMethod;
  installments: number;
  couponCode?: string | null;
}
export interface OrderHistoryEntry {
  id: Id;
  status: OrderStatus;
  changedAt: string;
  note?: string | null;
}
export interface OrderFilters extends Period {
  status?: OrderStatus | '';
  customerId?: Id;
}

/* ---------------- Estoque ---------------- */
export type StockMovementType = 'ENTRADA' | 'SAIDA';
export interface StockMovement {
  id: Id;
  productId: Id;
  productName: string;
  type: StockMovementType;
  quantity: number;
  date: string;
  note?: string | null;
  orderId?: Id | null;
}
export interface StockEntryPayload {
  productId: Id;
  quantity: number;
  unitCost?: number | null;
  note?: string;
}

/* ---------------- Financeiro ---------------- */
export interface FinancialSummary {
  revenue: number;
  profit: number;
  totalExpenses: number;
  totalIncome: number;
  received: number;
  receivable: number;
}
export interface MonthlyFinance {
  month: string; // yyyy-MM
  revenue: number;
  expenses: number;
}
export interface Revenue {
  id: Id;
  description: string;
  amount: number;
  date: string;
  orderId?: Id | null;
  received: boolean;
}
export interface RevenuePayload {
  description: string;
  amount: number;
  date: string;
  received: boolean;
}
export type ExpenseType = 'DESPESA' | 'COMPRA_MERCADORIA';
export interface Expense {
  id: Id;
  description: string;
  amount: number;
  date: string;
  type: ExpenseType;
  category?: string | null;
}
export interface ExpensePayload {
  description: string;
  amount: number;
  date: string;
  type: ExpenseType;
  category?: string;
}

/* ---------------- Parcelas ---------------- */
export type InstallmentStatus = 'PAGA' | 'EM_ABERTO' | 'VENCIDA';
export interface Installment {
  id: Id;
  orderId: Id;
  customer: Pick<Customer, 'id' | 'name' | 'phone'>;
  number: number;
  totalInstallments: number;
  amount: number;
  dueDate: string;
  paymentDate?: string | null;
  status: InstallmentStatus;
}
export interface PayInstallmentPayload {
  paymentDate: string;
  amount: number;
}

/* ---------------- Cupons e promoções ---------------- */
export type DiscountType = 'PERCENTUAL' | 'VALOR';
export interface Coupon {
  id: Id;
  code: string;
  discountType: DiscountType;
  discountValue: number;
  validFrom?: string | null;
  validUntil?: string | null;
  minimumOrderValue?: number | null;
  usageLimit?: number | null;
  timesUsed?: number;
  active: boolean;
}
export type CouponPayload = Omit<Coupon, 'id' | 'timesUsed'>;
export interface CouponValidation {
  valid: boolean;
  code: string;
  discount: number;
  message?: string;
}
export type PromotionScope = 'PRODUTO' | 'PEDIDO';
export interface Promotion {
  id: Id;
  name: string;
  scope: PromotionScope;
  discountType: DiscountType;
  discountValue: number;
  productIds?: Id[];
  startDate: string;
  endDate: string;
  active: boolean;
}
export type PromotionPayload = Omit<Promotion, 'id'>;

/* ---------------- Dashboard e relatórios ---------------- */
export interface Dashboard {
  monthRevenue: number;
  monthProfit: number;
  totalOrders: number;
  pendingOrders: number;
  receivable: number;
  overdueInstallments: number;
  lowStockProducts: number;
  salesByPeriod: { date: string; total: number }[];
  monthlyRevenue: { month: string; revenue: number }[];
  incomeVsExpenses: MonthlyFinance[];
  topProducts: { productId: Id; name: string; quantity: number }[];
  latestOrders: Order[];
  upcomingInstallments: Installment[];
  birthdayCustomers: Customer[];
  stockAlerts: Product[];
}

export type ReportType = 'sales' | 'financial' | 'top-products' | 'stock' | 'customers' | 'installments';
export interface ReportResult {
  columns: { key: string; label: string; type?: 'money' | 'date' | 'number' | 'text' }[];
  rows: Record<string, unknown>[];
  totals?: Record<string, number>;
}
