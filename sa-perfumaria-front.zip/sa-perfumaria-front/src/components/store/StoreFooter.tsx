import { Link } from 'react-router-dom';
import { Instagram, Facebook, MessageCircle, Lock } from 'lucide-react';
import { Logo } from '@/components/ui';
import { env } from '@/config/env';
import { hasStoreWhatsapp, storeWaLink } from '@/utils/whatsapp';

export function StoreFooter() {
  const socials = [
    env.instagramUrl && { href: env.instagramUrl, label: 'Instagram', Icon: Instagram },
    env.facebookUrl && { href: env.facebookUrl, label: 'Facebook', Icon: Facebook },
    hasStoreWhatsapp() && { href: storeWaLink('Olá! Vim pela loja virtual.'), label: 'WhatsApp', Icon: MessageCircle },
  ].filter(Boolean) as { href: string; label: string; Icon: typeof Instagram }[];

  return (
    <footer className="mt-20 bg-wine-900 text-white/80">
      <div className="gold-rule" />
      <div className="mx-auto grid max-w-7xl gap-10 px-6 py-14 md:grid-cols-3">
        <div>
          <Logo light />
          <p className="mt-4 max-w-xs text-sm leading-relaxed text-white/70">{env.storeTagline}. Atendimento personalizado e as melhores marcas de beleza.</p>
        </div>
        <div>
          <p className="eyebrow !text-gold-light">Navegue</p>
          <ul className="mt-4 space-y-2.5 text-sm">
            <li><Link to="/catalogo" className="hover:text-gold-light">Catálogo completo</Link></li>
            <li><Link to="/catalogo?promo=1" className="hover:text-gold-light">Promoções</Link></li>
            <li><Link to="/carrinho" className="hover:text-gold-light">Minha sacola</Link></li>
          </ul>
        </div>
        <div>
          <p className="eyebrow !text-gold-light">Fale comigo</p>
          {socials.length ? (
            <div className="mt-4 flex gap-3">
              {socials.map(({ href, label, Icon }) => (
                <a key={label} href={href} target="_blank" rel="noreferrer" aria-label={label}
                  className="grid size-11 place-items-center rounded-full border border-gold/50 text-gold-light transition hover:bg-gold hover:text-wine-900">
                  <Icon className="size-5" />
                </a>
              ))}
            </div>
          ) : (
            <p className="mt-4 text-sm text-white/60">Canais de contato em breve.</p>
          )}
        </div>
      </div>
      <div className="border-t border-white/10">
        <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-3 px-6 py-5 text-xs text-white/50 sm:flex-row">
          <span>© {new Date().getFullYear()} {env.storeName}. Marcas citadas pertencem aos seus respectivos donos.</span>
          <Link to="/admin" className="inline-flex items-center gap-1.5 hover:text-gold-light"><Lock className="size-3" /> Área da vendedora</Link>
        </div>
      </div>
    </footer>
  );
}
