import { money } from '@/utils/format';
import { cn } from '@/utils/cn';

export function PriceTag({ price, promo, size = 'md' }: { price: number; promo?: number | null; size?: 'md' | 'lg' }) {
  const hasPromo = promo != null && promo < price;
  return (
    <div className="flex flex-wrap items-baseline gap-x-2">
      {hasPromo && <span className={cn('text-ink-soft line-through', size === 'lg' ? 'text-base' : 'text-xs')}>{money(price)}</span>}
      <span className={cn('font-bold tabular-nums', hasPromo ? 'text-wine-700' : 'text-ink', size === 'lg' ? 'text-3xl' : 'text-lg')}>
        {money(hasPromo ? promo : price)}
      </span>
    </div>
  );
}

export const discountPct = (price: number, promo?: number | null) =>
  promo != null && promo < price ? Math.round((1 - promo / price) * 100) : 0;
