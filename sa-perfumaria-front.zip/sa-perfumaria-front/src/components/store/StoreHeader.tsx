import { useEffect, useState, type FormEvent } from 'react';
import { Link, useLocation, useNavigate, useSearchParams } from 'react-router-dom';
import { Menu, Search, ShoppingBag, X } from 'lucide-react';
import { Logo } from '@/components/ui';
import { useCart } from '@/contexts/CartContext';
import { cn } from '@/utils/cn';

const nav = [
  { to: '/', label: 'Início' },
  { to: '/catalogo', label: 'Catálogo' },
  { to: '/catalogo?promo=1', label: 'Promoções' },
  { to: '/carrinho', label: 'Minha sacola' },
];

export function StoreHeader() {
  const { count } = useCart();
  const [open, setOpen] = useState(false);
  const [params] = useSearchParams();
  const [q, setQ] = useState(params.get('q') ?? '');
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => { setOpen(false); }, [location.pathname, location.search]);

  const submit = (e: FormEvent) => {
    e.preventDefault();
    navigate(q.trim() ? `/catalogo?q=${encodeURIComponent(q.trim())}` : '/catalogo');
  };

  const searchBox = (
    <form onSubmit={submit} role="search" className="relative w-full">
      <Search className="pointer-events-none absolute left-4 top-1/2 size-4 -translate-y-1/2 text-gold-dark" />
      <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Busque perfumes, batons, cremes…" aria-label="Buscar produtos"
        className="h-11 w-full rounded-full border border-line bg-ivory pl-11 pr-4 text-sm outline-none transition focus:border-gold focus:bg-white focus:ring-4 focus:ring-gold/15" />
    </form>
  );

  return (
    <header className="sticky top-0 z-40 border-b border-line bg-white/90 backdrop-blur-md">
      <div className="bg-wine-900 py-2 text-center text-[11px] font-medium tracking-wide text-gold-light">
        Compre sem cadastro · Parcelamento facilitado · Atendimento pelo WhatsApp
      </div>
      <div className="mx-auto flex max-w-7xl items-center gap-4 px-4 py-3 sm:px-6">
        <button className="rounded-full p-2 text-ink lg:hidden" onClick={() => setOpen(true)} aria-label="Abrir menu"><Menu className="size-6" /></button>
        <Link to="/" aria-label="Página inicial" className="min-w-0"><Logo /></Link>
        <nav className="ml-6 hidden items-center gap-1 lg:flex">
          {nav.slice(0, 3).map((n) => {
            const promo = location.search.includes('promo=1');
            const active = n.to === '/' ? location.pathname === '/'
              : location.pathname === '/catalogo' && (n.to.includes('promo') ? promo : !promo);
            return (
              <Link key={n.label} to={n.to}
                className={cn('relative rounded-full px-3.5 py-2 text-sm font-semibold transition', active ? 'text-wine-700' : 'text-ink-soft hover:text-ink')}>
                {n.label}
                {active && <span className="absolute inset-x-3.5 -bottom-0.5 h-px bg-gold" />}
              </Link>
            );
          })}
        </nav>
        <div className="ml-auto hidden max-w-sm flex-1 md:block">{searchBox}</div>
        <Link to="/carrinho" className="relative ml-auto grid size-11 place-items-center rounded-full border border-gold/50 text-wine-700 transition hover:bg-gold-50 md:ml-0" aria-label={`Sacola com ${count} itens`}>
          <ShoppingBag className="size-5" />
          {count > 0 && (
            <span className="absolute -right-1 -top-1 grid min-w-5 place-items-center rounded-full bg-wine-700 px-1 text-[11px] font-bold text-white ring-2 ring-white">{count}</span>
          )}
        </Link>
      </div>
      <div className="px-4 pb-3 md:hidden">{searchBox}</div>

      {open && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 animate-fade-in bg-ink/40" onClick={() => setOpen(false)} />
          <aside className="absolute inset-y-0 left-0 flex w-[82%] max-w-xs animate-fade-up flex-col bg-white p-5 shadow-lift">
            <div className="flex items-center justify-between"><Logo /><button onClick={() => setOpen(false)} aria-label="Fechar menu" className="p-2"><X className="size-5" /></button></div>
            <div className="gold-rule my-5" />
            <nav className="flex flex-col gap-1">
              {nav.map((n) => (
                <Link key={n.label} to={n.to} className="rounded-xl px-3 py-3 text-base font-semibold text-ink hover:bg-gold-50">{n.label}</Link>
              ))}
            </nav>
          </aside>
        </div>
      )}
    </header>
  );
}
