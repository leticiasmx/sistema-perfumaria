import { Link } from 'react-router-dom';
import { ShoppingBag, Check } from 'lucide-react';
import { useState } from 'react';
import type { Product } from '@/interfaces';
import { ProductImage } from '@/components/ui';
import { PriceTag, discountPct } from './PriceTag';
import { useCart } from '@/contexts/CartContext';
import { useToast } from '@/contexts/ToastContext';
import { cn } from '@/utils/cn';

export function ProductCard({ product }: { product: Product }) {
  const { add } = useCart();
  const toast = useToast();
  const [added, setAdded] = useState(false);
  const out = product.stockQuantity <= 0;
  const pct = discountPct(product.price, product.promotionalPrice);

  const onAdd = () => {
    add(product);
    setAdded(true);
    toast.success(`${product.name} foi para a sacola.`);
    setTimeout(() => setAdded(false), 1400);
  };

  return (
    <article className="group flex flex-col overflow-hidden rounded-2xl border border-line bg-white shadow-soft transition duration-300 hover:-translate-y-1 hover:border-gold-light hover:shadow-lift">
      <Link to={`/produto/${product.id}`} className="relative block aspect-square overflow-hidden bg-ivory">
        <div className="h-full w-full transition duration-500 group-hover:scale-[1.04]">
          <ProductImage src={product.imageUrl} alt={product.name} />
        </div>
        <div className="absolute left-3 top-3 flex flex-col gap-1.5">
          {pct > 0 && <span className="rounded-full bg-wine-700 px-2.5 py-1 text-[11px] font-bold text-white shadow">-{pct}%</span>}
          {product.featured && <span className="rounded-full bg-white/95 px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider text-gold-dark ring-1 ring-gold-light">Destaque</span>}
        </div>
        {out && <div className="absolute inset-0 grid place-items-center bg-white/70 text-sm font-semibold text-ink-soft backdrop-blur-[1px]">Esgotado</div>}
      </Link>
      <div className="flex flex-1 flex-col p-4">
        <p className="eyebrow !text-[10px] !tracking-[0.18em]">{product.brand?.name ?? '—'}</p>
        <Link to={`/produto/${product.id}`} className="mt-1 line-clamp-2 min-h-[2.6em] text-[15px] font-semibold leading-snug text-ink hover:text-wine-700">
          {product.name}
        </Link>
        <div className="mt-2">
          <PriceTag price={product.price} promo={product.promotionalPrice} />
        </div>
        <p className={cn('mt-1 text-xs', out ? 'text-wine-700' : product.stockQuantity <= product.minimumStock ? 'text-amber-700' : 'text-emerald-700')}>
          {out ? 'Indisponível no momento' : product.stockQuantity <= product.minimumStock ? `Últimas ${product.stockQuantity} unidades` : 'Em estoque'}
        </p>
        <button onClick={onAdd} disabled={out}
          className={cn('mt-4 flex h-11 items-center justify-center gap-2 rounded-full text-sm font-semibold transition active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-40',
            added ? 'bg-emerald-600 text-white' : 'bg-wine-700 text-white hover:bg-wine-900')}>
          {added ? <><Check className="size-4" /> Adicionado</> : <><ShoppingBag className="size-4" /> Adicionar</>}
        </button>
      </div>
    </article>
  );
}

export function ProductGridSkeleton({ count = 8 }: { count?: number }) {
  return (
    <div className="grid grid-cols-2 gap-3 sm:gap-5 md:grid-cols-3 lg:grid-cols-4">
      {Array.from({ length: count }, (_, i) => (
        <div key={i} className="overflow-hidden rounded-2xl border border-line bg-white">
          <div className="aspect-square animate-pulse bg-line/60" />
          <div className="space-y-2 p-4"><div className="h-3 w-1/3 animate-pulse rounded bg-line" /><div className="h-4 w-4/5 animate-pulse rounded bg-line" /><div className="h-5 w-1/2 animate-pulse rounded bg-line" /></div>
        </div>
      ))}
    </div>
  );
}
