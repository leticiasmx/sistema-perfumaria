import { MessageCircle } from 'lucide-react';
import { hasStoreWhatsapp, storeWaLink } from '@/utils/whatsapp';

export function WhatsAppFloat() {
  if (!hasStoreWhatsapp()) return null;
  return (
    <a href={storeWaLink('Olá! Vim pela loja virtual e gostaria de ajuda.')} target="_blank" rel="noreferrer"
      className="fixed bottom-5 right-5 z-30 flex items-center gap-2 rounded-full bg-[#1f9d55] py-3 pl-3.5 pr-4 text-sm font-semibold text-white shadow-lift ring-4 ring-white transition hover:scale-105"
      aria-label="Conversar pelo WhatsApp">
      <MessageCircle className="size-5" /> <span className="hidden sm:inline">Fale comigo</span>
    </a>
  );
}
