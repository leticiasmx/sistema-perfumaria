import type { ReactNode } from 'react';
import { cn } from '@/utils/cn';

export interface Column<T> {
  key: string;
  header: ReactNode;
  render: (row: T) => ReactNode;
  className?: string;
  align?: 'left' | 'right' | 'center';
  hideOnMobile?: boolean;
}

export function DataTable<T>({ columns, rows, rowKey, onRowClick, rowClassName }: {
  columns: Column<T>[]; rows: T[]; rowKey: (r: T) => string | number;
  onRowClick?: (r: T) => void; rowClassName?: (r: T) => string | undefined;
}) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full min-w-[640px] text-sm">
        <thead>
          <tr className="border-b border-line">
            {columns.map((c) => (
              <th key={c.key} className={cn('whitespace-nowrap px-4 py-3 text-[11px] font-semibold uppercase tracking-[0.14em] text-ink-soft',
                c.align === 'right' ? 'text-right' : c.align === 'center' ? 'text-center' : 'text-left', c.hideOnMobile && 'hidden md:table-cell')}>
                {c.header}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((r) => (
            <tr key={rowKey(r)} onClick={onRowClick ? () => onRowClick(r) : undefined}
              className={cn('border-b border-line/70 transition-colors last:border-0', onRowClick && 'cursor-pointer hover:bg-gold-50/50', rowClassName?.(r))}>
              {columns.map((c) => (
                <td key={c.key} className={cn('px-4 py-3.5 align-middle', c.align === 'right' ? 'text-right' : c.align === 'center' ? 'text-center' : '', c.hideOnMobile && 'hidden md:table-cell', c.className)}>
                  {c.render(r)}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
