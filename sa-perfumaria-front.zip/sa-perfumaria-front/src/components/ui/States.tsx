import type { ReactNode } from 'react';
import { AlertCircle, Loader2, PackageOpen, RotateCw } from 'lucide-react';
import { Button } from './Button';
import { cn } from '@/utils/cn';

export function Loading({ label = 'Carregando…', className }: { label?: string; className?: string }) {
  return (
    <div className={cn('flex flex-col items-center justify-center gap-3 py-16 text-ink-soft', className)} role="status">
      <Loader2 className="size-6 animate-spin text-gold-dark" />
      <span className="text-sm">{label}</span>
    </div>
  );
}

export function Skeleton({ className }: { className?: string }) {
  return <div className={cn('animate-pulse rounded-xl bg-gradient-to-r from-line/70 via-ivory to-line/70', className)} />;
}

export function EmptyState({ title, message, icon, action }: { title: string; message?: string; icon?: ReactNode; action?: ReactNode }) {
  return (
    <div className="flex flex-col items-center justify-center px-6 py-14 text-center">
      <div className="mb-4 grid size-14 place-items-center rounded-full bg-gold-50 text-gold-dark ring-1 ring-gold-light">
        {icon ?? <PackageOpen className="size-6" />}
      </div>
      <h3 className="text-xl font-semibold text-ink">{title}</h3>
      {message && <p className="mt-1 max-w-sm text-sm text-ink-soft">{message}</p>}
      {action && <div className="mt-5">{action}</div>}
    </div>
  );
}

export function ErrorState({ message, onRetry }: { message: string; onRetry?: () => void }) {
  return (
    <div className="flex flex-col items-center justify-center px-6 py-14 text-center">
      <div className="mb-4 grid size-14 place-items-center rounded-full bg-wine-50 text-wine-700 ring-1 ring-wine-500/20">
        <AlertCircle className="size-6" />
      </div>
      <h3 className="text-xl font-semibold text-ink">Algo não saiu como esperado</h3>
      <p className="mt-1 max-w-md text-sm text-ink-soft">{message}</p>
      {onRetry && (
        <Button variant="outline" size="sm" className="mt-5" onClick={onRetry}>
          <RotateCw className="size-4" /> Tentar novamente
        </Button>
      )}
    </div>
  );
}

/** Renderiza o estado correto (loading → erro → vazio → conteúdo). */
export function AsyncContent<T>({ loading, error, data, onRetry, isEmpty, empty, children, loadingView }: {
  loading: boolean; error: string | null; data: T | undefined; onRetry?: () => void;
  isEmpty?: (d: T) => boolean; empty?: ReactNode; children: (d: T) => ReactNode; loadingView?: ReactNode;
}) {
  if (loading && data === undefined) return <>{loadingView ?? <Loading />}</>;
  if (error) return <ErrorState message={error} onRetry={onRetry} />;
  if (data === undefined) return null;
  const emptyCheck = isEmpty ?? ((d: T) => Array.isArray(d) && d.length === 0);
  if (emptyCheck(data)) return <>{empty ?? <EmptyState title="Nada por aqui ainda" />}</>;
  return <>{children(data)}</>;
}
