import { useState } from 'react';
import { CalendarRange } from 'lucide-react';
import type { Period } from '@/interfaces';
import { periodPreset } from '@/utils/format';
import { cn } from '@/utils/cn';

type Preset = 'month' | 'last30' | 'quarter' | 'year' | 'custom';
const labels: Record<Preset, string> = { month: 'Este mês', last30: '30 dias', quarter: 'Trimestre', year: 'Ano', custom: 'Personalizado' };

export function PeriodFilter({ value, onChange }: { value: Period; onChange: (p: Period) => void }) {
  const [preset, setPreset] = useState<Preset>('month');
  const choose = (p: Preset) => {
    setPreset(p);
    if (p !== 'custom') onChange(periodPreset(p));
  };
  return (
    <div className="flex flex-wrap items-center gap-2">
      <div className="flex rounded-full border border-line bg-white p-1 shadow-soft">
        {(Object.keys(labels) as Preset[]).map((p) => (
          <button key={p} onClick={() => choose(p)}
            className={cn('rounded-full px-3 py-1.5 text-xs font-semibold transition', preset === p ? 'bg-wine-700 text-white' : 'text-ink-soft hover:text-ink')}>
            {labels[p]}
          </button>
        ))}
      </div>
      {preset === 'custom' && (
        <div className="flex items-center gap-2 rounded-full border border-line bg-white px-3 py-1.5 text-xs shadow-soft">
          <CalendarRange className="size-4 text-gold-dark" />
          <input type="date" aria-label="Data inicial" value={value.from ?? ''} onChange={(e) => onChange({ ...value, from: e.target.value })} className="bg-transparent outline-none" />
          <span className="text-ink-soft">até</span>
          <input type="date" aria-label="Data final" value={value.to ?? ''} onChange={(e) => onChange({ ...value, to: e.target.value })} className="bg-transparent outline-none" />
        </div>
      )}
    </div>
  );
}
