import type { LucideIcon } from 'lucide-react';
import { cn } from '@/utils/cn';

export function StatCard({ label, value, icon: Icon, hint, tone = 'default', loading }: {
  label: string; value: string | number; icon: LucideIcon; hint?: string; tone?: 'default' | 'alert' | 'gold'; loading?: boolean;
}) {
  return (
    <div className={cn('card group relative overflow-hidden p-5 transition hover:-translate-y-0.5 hover:shadow-lift',
      tone === 'alert' && 'border-wine-500/30')}>
      <div className="absolute inset-x-0 top-0 h-[3px] bg-gradient-to-r from-gold-light via-gold to-gold-light opacity-0 transition group-hover:opacity-100" />
      <div className="flex items-start justify-between gap-3">
        <p className="text-[13px] font-medium text-ink-soft">{label}</p>
        <span className={cn('grid size-9 place-items-center rounded-full ring-1',
          tone === 'alert' ? 'bg-wine-50 text-wine-700 ring-wine-500/20' : 'bg-gold-50 text-gold-dark ring-gold-light')}>
          <Icon className="size-[18px]" />
        </span>
      </div>
      {loading ? <div className="mt-3 h-8 w-28 animate-pulse rounded-lg bg-line" /> :
        <p className={cn('mt-2 font-display text-[32px] font-semibold leading-none tabular-nums', tone === 'alert' ? 'text-wine-700' : 'text-ink')}>{value}</p>}
      {hint && <p className="mt-2 text-xs text-ink-soft">{hint}</p>}
    </div>
  );
}
