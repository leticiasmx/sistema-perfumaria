import { forwardRef, useId, type InputHTMLAttributes, type ReactNode, type SelectHTMLAttributes, type TextareaHTMLAttributes } from 'react';
import { ChevronDown } from 'lucide-react';
import { cn } from '@/utils/cn';

const control =
  'w-full rounded-xl border bg-white px-3.5 text-sm text-ink placeholder:text-ink-soft/60 transition focus:outline-none focus:ring-4 disabled:bg-ivory';
const ok = 'border-line focus:border-gold focus:ring-gold/15';
const bad = 'border-wine-500 focus:border-wine-500 focus:ring-wine-500/15';

interface Wrap { label?: string; error?: string; hint?: string; icon?: ReactNode }

function FieldShell({ id, label, error, hint, children, required }: Wrap & { id: string; children: ReactNode; required?: boolean }) {
  return (
    <div className="space-y-1.5">
      {label && (
        <label htmlFor={id} className="block text-[13px] font-semibold text-ink">
          {label} {required && <span className="text-wine-700">*</span>}
        </label>
      )}
      {children}
      {error ? <p className="text-xs font-medium text-wine-700">{error}</p> : hint ? <p className="text-xs text-ink-soft">{hint}</p> : null}
    </div>
  );
}

export const Input = forwardRef<HTMLInputElement, InputHTMLAttributes<HTMLInputElement> & Wrap>(function Input(
  { label, error, hint, icon, className, id, ...rest }, ref,
) {
  const auto = useId();
  const fid = id ?? auto;
  return (
    <FieldShell id={fid} label={label} error={error} hint={hint} required={rest.required}>
      <div className="relative">
        {icon && <span className="pointer-events-none absolute inset-y-0 left-3.5 flex items-center text-ink-soft">{icon}</span>}
        <input ref={ref} id={fid} aria-invalid={!!error} className={cn(control, 'h-11', error ? bad : ok, icon ? 'pl-10' : '', className)} {...rest} />
      </div>
    </FieldShell>
  );
});

export const Select = forwardRef<HTMLSelectElement, SelectHTMLAttributes<HTMLSelectElement> & Wrap>(function Select(
  { label, error, hint, className, id, children, ...rest }, ref,
) {
  const auto = useId();
  const fid = id ?? auto;
  return (
    <FieldShell id={fid} label={label} error={error} hint={hint} required={rest.required}>
      <div className="relative">
        <select ref={ref} id={fid} aria-invalid={!!error} className={cn(control, 'h-11 appearance-none pr-10', error ? bad : ok, className)} {...rest}>
          {children}
        </select>
        <ChevronDown className="pointer-events-none absolute right-3.5 top-1/2 size-4 -translate-y-1/2 text-gold-dark" />
      </div>
    </FieldShell>
  );
});

export const Textarea = forwardRef<HTMLTextAreaElement, TextareaHTMLAttributes<HTMLTextAreaElement> & Wrap>(function Textarea(
  { label, error, hint, className, id, ...rest }, ref,
) {
  const auto = useId();
  const fid = id ?? auto;
  return (
    <FieldShell id={fid} label={label} error={error} hint={hint} required={rest.required}>
      <textarea ref={ref} id={fid} aria-invalid={!!error} className={cn(control, 'min-h-24 py-3', error ? bad : ok, className)} {...rest} />
    </FieldShell>
  );
});

export function Checkbox({ label, checked, onChange }: { label: string; checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <label className="inline-flex cursor-pointer items-center gap-2.5 text-sm text-ink">
      <input type="checkbox" checked={checked} onChange={(e) => onChange(e.target.checked)} className="size-4 rounded border-line accent-wine-700" />
      {label}
    </label>
  );
}
