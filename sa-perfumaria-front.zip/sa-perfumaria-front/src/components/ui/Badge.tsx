import type { ReactNode } from 'react';
import { cn } from '@/utils/cn';
import type { Tone } from '@/utils/status';

const tones: Record<Tone, string> = {
  neutral: 'bg-ivory text-ink-soft ring-line',
  gold: 'bg-gold-50 text-gold-dark ring-gold-light',
  wine: 'bg-wine-50 text-wine-700 ring-wine-500/25',
  success: 'bg-emerald-50 text-emerald-700 ring-emerald-200',
  warning: 'bg-amber-50 text-amber-700 ring-amber-200',
  danger: 'bg-wine-50 text-wine-900 ring-wine-500/30',
  info: 'bg-sky-50 text-sky-700 ring-sky-200',
};

export function Badge({ tone = 'neutral', children, className, dot }: { tone?: Tone; children: ReactNode; className?: string; dot?: boolean }) {
  return (
    <span className={cn('inline-flex items-center gap-1.5 whitespace-nowrap rounded-full px-2.5 py-0.5 text-xs font-semibold ring-1 ring-inset', tones[tone], className)}>
      {dot && <span className="size-1.5 rounded-full bg-current" />}
      {children}
    </span>
  );
}
