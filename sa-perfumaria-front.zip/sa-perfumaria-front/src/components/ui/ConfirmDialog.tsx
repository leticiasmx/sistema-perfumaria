import { Modal } from './Modal';
import { Button } from './Button';

interface Props {
  open: boolean;
  title: string;
  message: string;
  confirmLabel?: string;
  loading?: boolean;
  onConfirm: () => void;
  onClose: () => void;
}

export function ConfirmDialog({ open, title, message, confirmLabel = 'Confirmar', loading, onConfirm, onClose }: Props) {
  return (
    <Modal open={open} onClose={onClose} title={title} size="sm"
      footer={<><Button variant="ghost" onClick={onClose}>Voltar</Button><Button onClick={onConfirm} loading={loading}>{confirmLabel}</Button></>}>
      <p className="text-sm leading-relaxed text-ink-soft">{message}</p>
    </Modal>
  );
}
