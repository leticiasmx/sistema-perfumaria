import { env } from '@/config/env';
import { cn } from '@/utils/cn';

export function Logo({ light, className, compact }: { light?: boolean; className?: string; compact?: boolean }) {
  const mono = env.storeMonogram;
  return (
    <span className={cn('inline-flex items-center gap-2.5', className)}>
      <span className={cn('grid size-11 shrink-0 place-items-center rounded-full ring-1', light ? 'bg-white/10 ring-gold/60' : 'bg-wine-900 ring-gold/70')}>
        <span className={cn('font-display italic leading-none text-gold-light', mono.length > 2 ? 'text-[15px]' : 'text-[22px]')}>{mono}</span>
      </span>
      {!compact && (
        <span className="flex flex-col leading-none">
          <span className={cn('font-display text-[23px] font-semibold', light ? 'text-white' : 'text-wine-900')}>{env.storeName}</span>
          <span className={cn('mt-1 text-[9.5px] font-semibold uppercase tracking-[0.28em]', light ? 'text-gold-light' : 'text-gold-dark')}>Beleza & Cosméticos</span>
        </span>
      )}
    </span>
  );
}
