import { cn } from '@/utils/cn';

export function Tabs<T extends string>({ tabs, value, onChange }: { tabs: { value: T; label: string; count?: number }[]; value: T; onChange: (v: T) => void }) {
  return (
    <div className="scrollbar-none -mx-1 flex gap-1 overflow-x-auto px-1" role="tablist">
      {tabs.map((t) => (
        <button key={t.value} role="tab" aria-selected={value === t.value} onClick={() => onChange(t.value)}
          className={cn('flex shrink-0 items-center gap-2 rounded-full px-4 py-2 text-sm font-semibold transition',
            value === t.value ? 'bg-wine-700 text-white shadow-soft' : 'text-ink-soft hover:bg-white hover:text-ink')}>
          {t.label}
          {t.count !== undefined && (
            <span className={cn('rounded-full px-1.5 text-[11px]', value === t.value ? 'bg-white/20' : 'bg-line')}>{t.count}</span>
          )}
        </button>
      ))}
    </div>
  );
}
