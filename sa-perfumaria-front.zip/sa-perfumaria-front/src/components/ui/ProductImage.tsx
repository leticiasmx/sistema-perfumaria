import { useState } from 'react';
import { cn } from '@/utils/cn';

/** Mostra a imagem do produto; sem imagem, exibe um placeholder elegante. */
export function ProductImage({ src, alt, className }: { src?: string | null; alt: string; className?: string }) {
  const [failed, setFailed] = useState(false);
  if (src && !failed)
    return <img src={src} alt={alt} loading="lazy" onError={() => setFailed(true)} className={cn('h-full w-full object-cover', className)} />;
  return (
    <div className={cn('relative grid h-full w-full place-items-center overflow-hidden bg-gradient-to-br from-gold-50 via-white to-wine-50', className)} aria-label={alt} role="img">
      <svg viewBox="0 0 120 160" className="h-1/2 w-auto opacity-80" aria-hidden>
        <rect x="48" y="10" width="24" height="22" rx="3" fill="#D4AF37" />
        <rect x="44" y="30" width="32" height="8" rx="2" fill="#B8860B" />
        <path d="M30 52c0-8 6-14 14-14h32c8 0 14 6 14 14v86c0 8-6 14-14 14H44c-8 0-14-6-14-14z" fill="#fff" stroke="#E8D9A8" strokeWidth="2" />
        <path d="M30 92h60v32H30z" fill="#A6192E" opacity=".9" />
        <path d="M40 100h40" stroke="#E8D9A8" strokeWidth="1.5" />
      </svg>
    </div>
  );
}
