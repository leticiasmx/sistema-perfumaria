import { useEffect, type ReactNode } from 'react';
import { createPortal } from 'react-dom';
import { X } from 'lucide-react';
import { cn } from '@/utils/cn';

interface ModalProps {
  open: boolean;
  onClose: () => void;
  title: string;
  description?: string;
  children: ReactNode;
  footer?: ReactNode;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  side?: boolean; // painel lateral (drawer)
}

export function Modal({ open, onClose, title, description, children, footer, size = 'md', side }: ModalProps) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && onClose();
    document.addEventListener('keydown', onKey);
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => { document.removeEventListener('keydown', onKey); document.body.style.overflow = prev; };
  }, [open, onClose]);

  if (!open) return null;
  return createPortal(
    <div className={cn('fixed inset-0 z-50 flex', side ? 'justify-end' : 'items-end justify-center sm:items-center sm:p-6')}>
      <div className="absolute inset-0 animate-fade-in bg-ink/45 backdrop-blur-[2px]" onClick={onClose} />
      <div
        role="dialog"
        aria-modal="true"
        aria-label={title}
        className={cn(
          'relative flex max-h-[92vh] w-full animate-fade-up flex-col bg-white shadow-lift',
          side ? 'h-full max-h-none max-w-xl' : 'rounded-t-3xl sm:rounded-3xl',
          !side && size === 'sm' && 'sm:max-w-md',
          !side && size === 'md' && 'sm:max-w-xl',
          !side && size === 'lg' && 'sm:max-w-3xl',
          !side && size === 'xl' && 'sm:max-w-5xl',
        )}
      >
        <div className="flex items-start justify-between gap-4 border-b border-line px-6 py-5">
          <div>
            <h2 className="text-2xl font-semibold text-ink">{title}</h2>
            {description && <p className="mt-1 text-sm text-ink-soft">{description}</p>}
          </div>
          <button onClick={onClose} className="rounded-full p-2 text-ink-soft transition hover:bg-wine-50 hover:text-wine-700" aria-label="Fechar">
            <X className="size-5" />
          </button>
        </div>
        <div className="flex-1 overflow-y-auto px-6 py-5">{children}</div>
        {footer && <div className="flex flex-wrap justify-end gap-3 border-t border-line bg-ivory/60 px-6 py-4">{footer}</div>}
      </div>
    </div>,
    document.body,
  );
}
