import { forwardRef, type ButtonHTMLAttributes } from 'react';
import { Loader2 } from 'lucide-react';
import { cn } from '@/utils/cn';

type Variant = 'primary' | 'gold' | 'outline' | 'ghost' | 'danger' | 'whatsapp';
type Size = 'sm' | 'md' | 'lg';

export interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
  size?: Size;
  loading?: boolean;
}

export const buttonClass = (variant: Variant = 'primary', size: Size = 'md', extra?: string) =>
  cn(
    'inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-full font-semibold transition-all duration-200 select-none',
    'disabled:cursor-not-allowed disabled:opacity-50 active:scale-[0.98]',
    size === 'sm' && 'h-9 px-4 text-[13px]',
    size === 'md' && 'h-11 px-5 text-sm',
    size === 'lg' && 'h-13 px-7 text-[15px]',
    variant === 'primary' && 'bg-wine-700 text-white shadow-[inset_0_-1px_0_rgb(0_0_0/0.15)] hover:bg-wine-900 hover:shadow-lift',
    variant === 'gold' && 'bg-gradient-to-b from-gold to-gold-dark text-white shadow-[inset_0_1px_0_rgb(255_255_255/0.35)] hover:brightness-105 hover:shadow-lift',
    variant === 'outline' && 'border border-gold/70 bg-white text-ink hover:border-gold hover:bg-gold-50',
    variant === 'ghost' && 'text-ink-soft hover:bg-wine-50 hover:text-wine-700',
    variant === 'danger' && 'bg-white text-wine-700 border border-wine-500/40 hover:bg-wine-50',
    variant === 'whatsapp' && 'bg-[#1f9d55] text-white hover:bg-[#178246]',
    extra,
  );

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(function Button(
  { variant, size, loading, className, children, disabled, type = 'button', ...rest },
  ref,
) {
  return (
    <button ref={ref} type={type} disabled={disabled || loading} className={buttonClass(variant, size, className)} {...rest}>
      {loading && <Loader2 className="size-4 animate-spin" />}
      {children}
    </button>
  );
});
