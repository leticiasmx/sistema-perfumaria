/**
 * Gráficos do painel (Recharts). Paleta validada para daltonismo e contraste:
 * série 1 = vinho #A6192E · série 2 = dourado escuro #B8860B.
 * Texto e eixos usam tons de tinta, nunca a cor da série.
 */
import {
  Area, AreaChart, Bar, BarChart, CartesianGrid, Legend, ResponsiveContainer, Tooltip, XAxis, YAxis,
} from 'recharts';
import { money, monthLabel, dayMonth } from '@/utils/format';

export const SERIES = { wine: '#A6192E', gold: '#B8860B' };
const axis = { stroke: '#6b6060', fontSize: 11, tickLine: false, axisLine: false } as const;
const grid = <CartesianGrid stroke="#ece5dc" strokeDasharray="0" vertical={false} />;
const compact = (v: number) => (v >= 1000 ? `R$ ${(v / 1000).toFixed(1).replace('.', ',')} mil` : `R$ ${v}`);

function TooltipBox({ active, payload, label, labelFormat, valueFormat }: any) {
  if (!active || !payload?.length) return null;
  return (
    <div className="rounded-xl border border-line bg-white px-3.5 py-2.5 text-xs shadow-lift">
      <p className="mb-1 font-semibold text-ink">{labelFormat ? labelFormat(label) : label}</p>
      {payload.map((p: any) => (
        <p key={p.dataKey} className="flex items-center gap-2 text-ink-soft">
          <span className="size-2 rounded-full" style={{ background: p.color }} />
          {p.name}: <b className="text-ink tabular-nums">{valueFormat ? valueFormat(p.value) : p.value}</b>
        </p>
      ))}
    </div>
  );
}

export function SalesAreaChart({ data }: { data: { date: string; total: number }[] }) {
  return (
    <ResponsiveContainer width="100%" height={260}>
      <AreaChart data={data} margin={{ top: 10, right: 8, left: 0, bottom: 0 }}>
        <defs>
          <linearGradient id="salesFill" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={SERIES.wine} stopOpacity={0.22} />
            <stop offset="100%" stopColor={SERIES.wine} stopOpacity={0} />
          </linearGradient>
        </defs>
        {grid}
        <XAxis dataKey="date" tickFormatter={dayMonth} {...axis} minTickGap={24} />
        <YAxis tickFormatter={compact} {...axis} width={70} />
        <Tooltip cursor={{ stroke: '#D4AF37', strokeWidth: 1 }} content={<TooltipBox labelFormat={dayMonth} valueFormat={money} />} />
        <Area type="monotone" dataKey="total" name="Vendas" stroke={SERIES.wine} strokeWidth={2} fill="url(#salesFill)" activeDot={{ r: 5, stroke: '#fff', strokeWidth: 2 }} />
      </AreaChart>
    </ResponsiveContainer>
  );
}

export function MonthlyBarChart({ data, dataKey, name }: { data: any[]; dataKey: string; name: string }) {
  return (
    <ResponsiveContainer width="100%" height={260}>
      <BarChart data={data} margin={{ top: 10, right: 8, left: 0, bottom: 0 }} barCategoryGap="30%">
        {grid}
        <XAxis dataKey="month" tickFormatter={monthLabel} {...axis} />
        <YAxis tickFormatter={compact} {...axis} width={70} />
        <Tooltip cursor={{ fill: '#f8f2df' }} content={<TooltipBox labelFormat={monthLabel} valueFormat={money} />} />
        <Bar dataKey={dataKey} name={name} fill={SERIES.wine} radius={[4, 4, 0, 0]} maxBarSize={36} />
      </BarChart>
    </ResponsiveContainer>
  );
}

export function IncomeExpenseChart({ data }: { data: { month: string; revenue: number; expenses: number }[] }) {
  return (
    <ResponsiveContainer width="100%" height={280}>
      <BarChart data={data} margin={{ top: 10, right: 8, left: 0, bottom: 0 }} barGap={2} barCategoryGap="28%">
        {grid}
        <XAxis dataKey="month" tickFormatter={monthLabel} {...axis} />
        <YAxis tickFormatter={compact} {...axis} width={70} />
        <Tooltip cursor={{ fill: '#f8f2df' }} content={<TooltipBox labelFormat={monthLabel} valueFormat={money} />} />
        <Legend iconType="circle" iconSize={8} wrapperStyle={{ fontSize: 12, color: '#292323', paddingTop: 8 }} />
        <Bar dataKey="revenue" name="Receitas" fill={SERIES.wine} radius={[4, 4, 0, 0]} maxBarSize={28} />
        <Bar dataKey="expenses" name="Despesas" fill={SERIES.gold} radius={[4, 4, 0, 0]} maxBarSize={28} />
      </BarChart>
    </ResponsiveContainer>
  );
}

export function TopProductsChart({ data }: { data: { name: string; quantity: number }[] }) {
  return (
    <ResponsiveContainer width="100%" height={Math.max(180, data.length * 44)}>
      <BarChart data={data} layout="vertical" margin={{ top: 0, right: 24, left: 0, bottom: 0 }} barCategoryGap="30%">
        <XAxis type="number" hide />
        <YAxis type="category" dataKey="name" {...axis} width={170} tickFormatter={(v: string) => (v.length > 26 ? v.slice(0, 25) + '…' : v)} />
        <Tooltip cursor={{ fill: '#f8f2df' }} content={<TooltipBox valueFormat={(v: number) => `${v} un.`} />} />
        <Bar dataKey="quantity" name="Vendidos" fill={SERIES.wine} radius={[0, 4, 4, 0]} maxBarSize={22} label={{ position: 'right', fontSize: 11, fill: '#292323' }} />
      </BarChart>
    </ResponsiveContainer>
  );
}
