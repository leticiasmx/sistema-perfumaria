/**
 * ⚠️ CONTRATO PROVISÓRIO DA API
 * ------------------------------------------------------------------
 * O código do back-end Java não foi disponibilizado durante o
 * desenvolvimento deste front-end. Os caminhos abaixo seguem convenções
 * REST comuns em Spring Boot e PRECISAM ser conferidos com os
 * @RestController / @RequestMapping reais antes de ir para produção.
 *
 * Todos os endpoints do sistema estão concentrados neste arquivo:
 * ajustar a integração = ajustar este arquivo + os tipos em src/interfaces.
 * Nenhum componente monta URL por conta própria.
 */
export const endpoints = {
  auth: {
    login: '/auth/login',
    me: '/auth/me',
  },
  products: {
    base: '/products',
    byId: (id: Id) => `/products/${id}`,
    image: (id: Id) => `/products/${id}/image`,
  },
  brands: { base: '/brands', byId: (id: Id) => `/brands/${id}` },
  categories: { base: '/categories', byId: (id: Id) => `/categories/${id}` },
  customers: {
    base: '/customers',
    byId: (id: Id) => `/customers/${id}`,
    byPhone: (phone: string) => `/customers/phone/${phone}`,
    orders: (id: Id) => `/customers/${id}/orders`,
    birthdays: '/customers/birthdays',
  },
  orders: {
    base: '/orders',
    byId: (id: Id) => `/orders/${id}`,
    status: (id: Id) => `/orders/${id}/status`,
    cancel: (id: Id) => `/orders/${id}/cancel`,
    history: (id: Id) => `/orders/${id}/history`,
  },
  stock: {
    base: '/stock',
    low: '/stock/low',
    movements: '/stock/movements',
    entries: '/stock/entries',
  },
  financial: {
    summary: '/financial/summary',
    monthly: '/financial/monthly',
    revenues: '/financial/revenues',
    expenses: '/financial/expenses',
  },
  installments: {
    base: '/installments',
    pay: (id: Id) => `/installments/${id}/pay`,
  },
  coupons: {
    base: '/coupons',
    byId: (id: Id) => `/coupons/${id}`,
    validate: '/coupons/validate',
  },
  promotions: { base: '/promotions', byId: (id: Id) => `/promotions/${id}` },
  dashboard: { base: '/dashboard' },
  reports: {
    byType: (type: string) => `/reports/${type}`,
    export: (type: string) => `/reports/${type}/export`,
  },
} as const;

export type Id = number | string;
