import type { PaymentMethod } from '@/interfaces';

/**
 * ⚠️ PROVISÓRIO — formas de pagamento e limite de parcelas.
 * Se o back-end expuser esses dados (ex.: GET /payment-methods), troque
 * esta constante por uma chamada de serviço. Os valores das parcelas são
 * SEMPRE calculados pelo back-end; o front só mostra uma estimativa.
 */
export const PAYMENT_METHODS: { value: PaymentMethod; label: string; maxInstallments: number }[] = [
  { value: 'PIX', label: 'Pix', maxInstallments: 1 },
  { value: 'DINHEIRO', label: 'Dinheiro', maxInstallments: 1 },
  { value: 'CARTAO_DEBITO', label: 'Cartão de débito', maxInstallments: 1 },
  { value: 'CARTAO_CREDITO', label: 'Cartão de crédito', maxInstallments: 6 },
  { value: 'CREDIARIO', label: 'Crediário (parcelado com a vendedora)', maxInstallments: 4 },
];

export const paymentLabel = (m?: string) =>
  PAYMENT_METHODS.find((p) => p.value === m)?.label ?? m ?? '—';

/** Dias de antecedência para considerar uma parcela "próxima do vencimento" (apenas exibição). */
export const DUE_SOON_DAYS = 5;
