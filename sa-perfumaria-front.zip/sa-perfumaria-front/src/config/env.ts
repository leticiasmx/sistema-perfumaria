const e = import.meta.env;

export const env = {
  apiUrl: (e.VITE_API_URL || 'http://localhost:8080').replace(/\/$/, ''),
  useMocks: e.VITE_USE_MOCKS === 'true',
  storeName: e.VITE_STORE_NAME || 'S&A Perfumaria',
  storeMonogram: e.VITE_STORE_MONOGRAM || 'S&A',
  storeTagline: e.VITE_STORE_TAGLINE || 'Beleza, perfumaria e cuidados pessoais',
  whatsappNumber: (e.VITE_WHATSAPP_NUMBER || '').replace(/\D/g, ''),
  instagramUrl: e.VITE_INSTAGRAM_URL || '',
  facebookUrl: e.VITE_FACEBOOK_URL || '',
  heroImageUrl: e.VITE_HERO_IMAGE_URL || '',
} as const;
