import { api, cleanParams } from './api';
import { endpoints } from '@/config/endpoints';
import type { Period, ReportResult, ReportType } from '@/interfaces';

export const reportService = {
  async get(type: ReportType, period?: Period): Promise<ReportResult> {
    return (await api.get<ReportResult>(endpoints.reports.byType(type), { params: cleanParams(period) })).data;
  },
  /** ⚠️ PROVISÓRIO: só funciona se a API oferecer exportação. */
  async export(type: ReportType, format: 'csv' | 'pdf' | 'xlsx', period?: Period): Promise<Blob> {
    const { data } = await api.get<Blob>(endpoints.reports.export(type), {
      params: cleanParams({ ...period, format }),
      responseType: 'blob',
    });
    return data;
  },
};
