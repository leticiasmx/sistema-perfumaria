import { api, tokenStorage } from './api';
import { endpoints } from '@/config/endpoints';
import type { AuthUser, LoginRequest, LoginResponse } from '@/interfaces';

export const authService = {
  async login(payload: LoginRequest): Promise<LoginResponse> {
    const { data } = await api.post<LoginResponse>(endpoints.auth.login, payload);
    tokenStorage.set(data.token);
    return data;
  },
  async me(): Promise<AuthUser> {
    const { data } = await api.get<AuthUser>(endpoints.auth.me);
    return data;
  },
  logout() {
    tokenStorage.clear();
  },
};
