import { api, asList, cleanParams } from './api';
import { endpoints, type Id } from '@/config/endpoints';
import type { Page, Product, StockEntryPayload, StockMovement, StockMovementType } from '@/interfaces';

export const stockService = {
  async list(): Promise<Product[]> {
    return asList((await api.get<Product[] | Page<Product>>(endpoints.stock.base)).data);
  },
  async low(): Promise<Product[]> {
    return asList((await api.get<Product[] | Page<Product>>(endpoints.stock.low)).data);
  },
  async movements(params?: { productId?: Id; type?: StockMovementType | ''; from?: string; to?: string }): Promise<StockMovement[]> {
    return asList((await api.get<StockMovement[] | Page<StockMovement>>(endpoints.stock.movements, { params: cleanParams(params) })).data);
  },
  async registerEntry(payload: StockEntryPayload): Promise<StockMovement> {
    return (await api.post<StockMovement>(endpoints.stock.entries, payload)).data;
  },
};
