import axios, { AxiosError } from 'axios';
import { env } from '@/config/env';
import type { Page } from '@/interfaces';

const TOKEN_KEY = 'be.admin.token';

/** localStorage pode estar indisponível (modo privado, iframes): nunca deixa a app quebrar. */
export const safeStorage = {
  get: (k: string) => { try { return localStorage.getItem(k); } catch { return null; } },
  set: (k: string, v: string) => { try { localStorage.setItem(k, v); } catch { /* ignora */ } },
  remove: (k: string) => { try { localStorage.removeItem(k); } catch { /* ignora */ } },
};

export const tokenStorage = {
  get: () => safeStorage.get(TOKEN_KEY),
  set: (t: string) => safeStorage.set(TOKEN_KEY, t),
  clear: () => safeStorage.remove(TOKEN_KEY),
};

/** Instância única do Axios. Nenhum componente deve usar axios diretamente. */
export const api = axios.create({
  baseURL: env.apiUrl,
  timeout: 20_000,
  headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
});

// ⚠️ PROVISÓRIO: assume JWT no header Authorization: Bearer <token>.
// Se o back-end usar sessão/cookie (JSESSIONID) troque por `withCredentials: true`.
api.interceptors.request.use((config) => {
  const token = tokenStorage.get();
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

export const UNAUTHORIZED_EVENT = 'auth:unauthorized';

api.interceptors.response.use(
  (res) => res,
  (error: AxiosError) => {
    const status = error.response?.status;
    const isLogin = error.config?.url?.includes('/auth/login');
    if (status === 401 && !isLogin && tokenStorage.get()) {
      tokenStorage.clear();
      window.dispatchEvent(new Event(UNAUTHORIZED_EVENT));
    }
    return Promise.reject(error);
  },
);

/** Aceita tanto lista simples quanto Page<T> do Spring. */
export function asList<T>(data: T[] | Page<T> | null | undefined): T[] {
  if (!data) return [];
  return Array.isArray(data) ? data : data.content ?? [];
}

/** Remove parâmetros vazios antes de enviar a query string. */
export function cleanParams<T extends object>(params?: T) {
  if (!params) return undefined;
  return Object.fromEntries(
    Object.entries(params).filter(([, v]) => v !== undefined && v !== null && v !== ''),
  );
}
