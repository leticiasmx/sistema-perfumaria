import { api, asList } from './api';
import { endpoints, type Id } from '@/config/endpoints';
import type { Coupon, CouponPayload, CouponValidation, Page } from '@/interfaces';

export const couponService = {
  list: async () => asList((await api.get<Coupon[] | Page<Coupon>>(endpoints.coupons.base)).data),
  create: async (p: CouponPayload) => (await api.post<Coupon>(endpoints.coupons.base, p)).data,
  update: async (id: Id, p: CouponPayload) => (await api.put<Coupon>(endpoints.coupons.byId(id), p)).data,
  remove: async (id: Id) => { await api.delete(endpoints.coupons.byId(id)); },
  /** A regra do desconto fica no back-end; o front só exibe o resultado. */
  validate: async (code: string, subtotal: number) =>
    (await api.post<CouponValidation>(endpoints.coupons.validate, { code, subtotal })).data,
};
