import { api, asList } from './api';
import { endpoints, type Id } from '@/config/endpoints';
import type { Brand, Category, Page } from '@/interfaces';

export const brandService = {
  list: async () => asList((await api.get<Brand[] | Page<Brand>>(endpoints.brands.base)).data),
  create: async (p: { name: string }) => (await api.post<Brand>(endpoints.brands.base, p)).data,
  update: async (id: Id, p: { name: string }) => (await api.put<Brand>(endpoints.brands.byId(id), p)).data,
  remove: async (id: Id) => { await api.delete(endpoints.brands.byId(id)); },
};

export const categoryService = {
  list: async () => asList((await api.get<Category[] | Page<Category>>(endpoints.categories.base)).data),
  create: async (p: { name: string }) => (await api.post<Category>(endpoints.categories.base, p)).data,
  update: async (id: Id, p: { name: string }) => (await api.put<Category>(endpoints.categories.byId(id), p)).data,
  remove: async (id: Id) => { await api.delete(endpoints.categories.byId(id)); },
};
