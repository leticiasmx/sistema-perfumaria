import { api, asList } from './api';
import { endpoints, type Id } from '@/config/endpoints';
import type { Page, Promotion, PromotionPayload } from '@/interfaces';

export const promotionService = {
  list: async () => asList((await api.get<Promotion[] | Page<Promotion>>(endpoints.promotions.base)).data),
  create: async (p: PromotionPayload) => (await api.post<Promotion>(endpoints.promotions.base, p)).data,
  update: async (id: Id, p: PromotionPayload) => (await api.put<Promotion>(endpoints.promotions.byId(id), p)).data,
  remove: async (id: Id) => { await api.delete(endpoints.promotions.byId(id)); },
};
