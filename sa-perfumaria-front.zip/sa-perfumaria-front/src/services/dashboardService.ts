import { api, cleanParams } from './api';
import { endpoints } from '@/config/endpoints';
import type { Dashboard, Period } from '@/interfaces';

/**
 * ⚠️ PROVISÓRIO: assume um endpoint agregado. Se o back-end não tiver
 * um /dashboard, compor aqui a partir dos serviços de pedidos,
 * financeiro, parcelas, estoque e clientes — sem recalcular regras.
 */
export const dashboardService = {
  get: async (period?: Period) => (await api.get<Dashboard>(endpoints.dashboard.base, { params: cleanParams(period) })).data,
};
