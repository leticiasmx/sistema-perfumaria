import { api, asList, cleanParams } from './api';
import { endpoints } from '@/config/endpoints';
import type { Expense, ExpensePayload, FinancialSummary, MonthlyFinance, Page, Period, Revenue, RevenuePayload } from '@/interfaces';

export const financialService = {
  async summary(period?: Period): Promise<FinancialSummary> {
    return (await api.get<FinancialSummary>(endpoints.financial.summary, { params: cleanParams(period) })).data;
  },
  async monthly(period?: Period): Promise<MonthlyFinance[]> {
    return asList((await api.get<MonthlyFinance[] | Page<MonthlyFinance>>(endpoints.financial.monthly, { params: cleanParams(period) })).data);
  },
  async revenues(params?: Period & { received?: boolean }): Promise<Revenue[]> {
    return asList((await api.get<Revenue[] | Page<Revenue>>(endpoints.financial.revenues, { params: cleanParams(params) })).data);
  },
  async createRevenue(p: RevenuePayload): Promise<Revenue> {
    return (await api.post<Revenue>(endpoints.financial.revenues, p)).data;
  },
  async expenses(params?: Period & { type?: string }): Promise<Expense[]> {
    return asList((await api.get<Expense[] | Page<Expense>>(endpoints.financial.expenses, { params: cleanParams(params) })).data);
  },
  async createExpense(p: ExpensePayload): Promise<Expense> {
    return (await api.post<Expense>(endpoints.financial.expenses, p)).data;
  },
};
