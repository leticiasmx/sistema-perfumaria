import { api, asList, cleanParams } from './api';
import { endpoints, type Id } from '@/config/endpoints';
import type { Customer, CustomerPayload, Order, Page } from '@/interfaces';
import { isNotFound } from '@/utils/errors';

export const customerService = {
  async list(search?: string): Promise<Customer[]> {
    const { data } = await api.get<Customer[] | Page<Customer>>(endpoints.customers.base, { params: cleanParams({ search }) });
    return asList(data);
  },
  /** Retorna null quando a API responde 404 (cliente ainda não cadastrado). */
  async findByPhone(phone: string): Promise<Customer | null> {
    try {
      const { data } = await api.get<Customer>(endpoints.customers.byPhone(phone));
      return data;
    } catch (err) {
      if (isNotFound(err)) return null;
      throw err;
    }
  },
  async create(payload: CustomerPayload): Promise<Customer> {
    return (await api.post<Customer>(endpoints.customers.base, payload)).data;
  },
  async update(id: Id, payload: CustomerPayload): Promise<Customer> {
    return (await api.put<Customer>(endpoints.customers.byId(id), payload)).data;
  },
  async orders(id: Id): Promise<Order[]> {
    return asList((await api.get<Order[] | Page<Order>>(endpoints.customers.orders(id))).data);
  },
  async birthdays(month: number): Promise<Customer[]> {
    return asList((await api.get<Customer[] | Page<Customer>>(endpoints.customers.birthdays, { params: { month } })).data);
  },
};
