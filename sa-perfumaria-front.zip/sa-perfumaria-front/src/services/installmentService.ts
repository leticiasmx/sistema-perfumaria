import { api, asList, cleanParams } from './api';
import { endpoints, type Id } from '@/config/endpoints';
import type { Installment, InstallmentStatus, Page, PayInstallmentPayload } from '@/interfaces';

export const installmentService = {
  async list(params?: { status?: InstallmentStatus; customerId?: Id }): Promise<Installment[]> {
    return asList((await api.get<Installment[] | Page<Installment>>(endpoints.installments.base, { params: cleanParams(params) })).data);
  },
  async pay(id: Id, payload: PayInstallmentPayload): Promise<Installment> {
    return (await api.patch<Installment>(endpoints.installments.pay(id), payload)).data;
  },
};
