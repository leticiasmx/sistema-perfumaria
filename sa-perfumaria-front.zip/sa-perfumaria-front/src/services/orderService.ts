import { api, asList, cleanParams } from './api';
import { endpoints, type Id } from '@/config/endpoints';
import type { CreateOrderPayload, Order, OrderFilters, OrderHistoryEntry, OrderStatus, Page } from '@/interfaces';

export const orderService = {
  /** Endpoint público usado pela loja (cliente sem login). */
  async create(payload: CreateOrderPayload): Promise<Order> {
    return (await api.post<Order>(endpoints.orders.base, payload)).data;
  },
  async list(filters?: OrderFilters): Promise<Order[]> {
    return asList((await api.get<Order[] | Page<Order>>(endpoints.orders.base, { params: cleanParams(filters) })).data);
  },
  async get(id: Id): Promise<Order> {
    return (await api.get<Order>(endpoints.orders.byId(id))).data;
  },
  async updateStatus(id: Id, status: OrderStatus): Promise<Order> {
    return (await api.patch<Order>(endpoints.orders.status(id), { status })).data;
  },
  async cancel(id: Id, reason?: string): Promise<Order> {
    return (await api.patch<Order>(endpoints.orders.cancel(id), { reason })).data;
  },
  async history(id: Id): Promise<OrderHistoryEntry[]> {
    return asList((await api.get<OrderHistoryEntry[] | Page<OrderHistoryEntry>>(endpoints.orders.history(id))).data);
  },
};
