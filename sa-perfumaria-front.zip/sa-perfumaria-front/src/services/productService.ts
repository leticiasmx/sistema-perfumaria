import { api, asList, cleanParams } from './api';
import { endpoints, type Id } from '@/config/endpoints';
import type { Page, Product, ProductFilters, ProductPayload } from '@/interfaces';

export const productService = {
  async list(filters?: ProductFilters): Promise<Product[]> {
    const { data } = await api.get<Product[] | Page<Product>>(endpoints.products.base, { params: cleanParams(filters) });
    return asList(data);
  },
  async get(id: Id): Promise<Product> {
    const { data } = await api.get<Product>(endpoints.products.byId(id));
    return data;
  },
  async create(payload: ProductPayload): Promise<Product> {
    const { data } = await api.post<Product>(endpoints.products.base, payload);
    return data;
  },
  async update(id: Id, payload: ProductPayload): Promise<Product> {
    const { data } = await api.put<Product>(endpoints.products.byId(id), payload);
    return data;
  },
  async remove(id: Id): Promise<void> {
    await api.delete(endpoints.products.byId(id));
  },
  /** ⚠️ PROVISÓRIO: upload multipart com o campo "file". */
  async uploadImage(id: Id, file: File): Promise<Product> {
    const form = new FormData();
    form.append('file', file);
    const { data } = await api.post<Product>(endpoints.products.image(id), form, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
    return data;
  },
};
