import { useState, type FormEvent } from 'react';
import { Link } from 'react-router-dom';
import { Minus, Plus, ShoppingBag, Tag, Trash2, X } from 'lucide-react';
import { useCart } from '@/contexts/CartContext';
import { couponService } from '@/services/couponService';
import { useDocumentTitle } from '@/hooks/useDocumentTitle';
import { Button, EmptyState, ProductImage, buttonClass } from '@/components/ui';
import { money } from '@/utils/format';
import { errorMessage } from '@/utils/errors';

export function OrderSummary({ compact }: { compact?: boolean }) {
  const { subtotal, promoSavings, discount, total, coupon, count } = useCart();
  return (
    <dl className="space-y-3 text-sm">
      <div className="flex justify-between"><dt className="text-ink-soft">Subtotal ({count} {count === 1 ? 'item' : 'itens'})</dt><dd className="tabular-nums">{money(subtotal + promoSavings)}</dd></div>
      {promoSavings > 0 && <div className="flex justify-between text-wine-700"><dt>Descontos de promoção</dt><dd className="tabular-nums">−{money(promoSavings)}</dd></div>}
      {discount > 0 && <div className="flex justify-between text-wine-700"><dt>Cupom {coupon?.code}</dt><dd className="tabular-nums">−{money(discount)}</dd></div>}
      <div className="gold-rule !my-4" />
      <div className="flex items-baseline justify-between">
        <dt className="font-semibold">Total{!compact && ' estimado'}</dt>
        <dd className="font-display text-3xl font-semibold tabular-nums text-ink">{money(total)}</dd>
      </div>
      {!compact && <p className="text-xs text-ink-soft">O valor final é confirmado pela loja ao registrar o pedido.</p>}
    </dl>
  );
}

function CouponBox() {
  const { subtotal, coupon, applyCoupon } = useCart();
  const [code, setCode] = useState('');
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (!code.trim()) return;
    setLoading(true);
    setMsg(null);
    try {
      const res = await couponService.validate(code.trim().toUpperCase(), subtotal);
      if (res.valid) { applyCoupon(res); setCode(''); } else setMsg(res.message ?? 'Cupom inválido.');
    } catch (err) {
      setMsg(errorMessage(err, 'Não foi possível validar o cupom.'));
    } finally {
      setLoading(false);
    }
  };

  if (coupon?.valid)
    return (
      <div className="flex items-center justify-between rounded-xl bg-emerald-50 px-4 py-3 text-sm text-emerald-800 ring-1 ring-emerald-200">
        <span className="flex items-center gap-2"><Tag className="size-4" /> Cupom <b>{coupon.code}</b> aplicado</span>
        <button onClick={() => applyCoupon(null)} aria-label="Remover cupom"><X className="size-4" /></button>
      </div>
    );

  return (
    <form onSubmit={submit}>
      <label htmlFor="coupon" className="mb-1.5 block text-[13px] font-semibold">Cupom de desconto</label>
      <div className="flex gap-2">
        <input id="coupon" value={code} onChange={(e) => setCode(e.target.value.toUpperCase())} placeholder="Digite seu cupom"
          className="h-11 min-w-0 flex-1 rounded-full border border-line bg-white px-4 text-sm uppercase tracking-wider outline-none focus:border-gold focus:ring-4 focus:ring-gold/15" />
        <Button type="submit" variant="outline" loading={loading} disabled={!code.trim()}>Aplicar</Button>
      </div>
      {msg && <p className="mt-2 text-xs font-medium text-wine-700">{msg}</p>}
    </form>
  );
}

export default function CartPage() {
  useDocumentTitle('Minha sacola');
  const { items, setQuantity, remove, clear } = useCart();

  if (!items.length)
    return (
      <div className="mx-auto max-w-xl px-4 py-20">
        <EmptyState icon={<ShoppingBag className="size-6" />} title="Sua sacola está vazia" message="Explore o catálogo e encontre algo especial para você."
          action={<Link to="/catalogo" className={buttonClass('primary', 'lg')}>Ver catálogo</Link>} />
      </div>
    );

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6">
      <div className="mb-8 flex items-end justify-between">
        <div><p className="eyebrow">Sacola</p><h1 className="mt-1 text-4xl font-semibold sm:text-5xl">Minha sacola</h1></div>
        <Button variant="ghost" size="sm" onClick={clear}><Trash2 className="size-4" /> Esvaziar</Button>
      </div>

      <div className="grid gap-8 lg:grid-cols-[1fr_380px]">
        <ul className="card divide-y divide-line">
          {items.map((i) => (
            <li key={i.productId} className="flex gap-4 p-4 sm:p-5">
              <Link to={`/produto/${i.productId}`} className="size-24 shrink-0 overflow-hidden rounded-xl bg-ivory sm:size-28"><ProductImage src={i.imageUrl} alt={i.name} /></Link>
              <div className="flex min-w-0 flex-1 flex-col">
                <div className="flex justify-between gap-3">
                  <div className="min-w-0">
                    <p className="eyebrow !text-[10px]">{i.brand}</p>
                    <Link to={`/produto/${i.productId}`} className="line-clamp-2 font-semibold hover:text-wine-700">{i.name}</Link>
                  </div>
                  <button onClick={() => remove(i.productId)} className="h-fit rounded-full p-2 text-ink-soft hover:bg-wine-50 hover:text-wine-700" aria-label={`Remover ${i.name}`}><Trash2 className="size-4" /></button>
                </div>
                <div className="mt-auto flex flex-wrap items-end justify-between gap-3 pt-3">
                  <div className="flex items-center rounded-full border border-line">
                    <button className="grid size-10 place-items-center disabled:opacity-30" onClick={() => setQuantity(i.productId, i.quantity - 1)} disabled={i.quantity <= 1} aria-label="Diminuir"><Minus className="size-4" /></button>
                    <span className="w-8 text-center text-sm font-semibold tabular-nums">{i.quantity}</span>
                    <button className="grid size-10 place-items-center disabled:opacity-30" onClick={() => setQuantity(i.productId, i.quantity + 1)} disabled={i.quantity >= i.stock} aria-label="Aumentar"><Plus className="size-4" /></button>
                  </div>
                  <div className="text-right">
                    {i.originalPrice > i.unitPrice && <p className="text-xs text-ink-soft line-through">{money(i.originalPrice * i.quantity)}</p>}
                    <p className="font-bold tabular-nums">{money(i.unitPrice * i.quantity)}</p>
                  </div>
                </div>
              </div>
            </li>
          ))}
        </ul>

        <aside className="lg:sticky lg:top-36 lg:self-start">
          <div className="card space-y-6 p-6">
            <h2 className="text-2xl font-semibold">Resumo do pedido</h2>
            <CouponBox />
            <OrderSummary />
            <Link to="/finalizar" className={buttonClass('primary', 'lg', 'w-full')}>Finalizar pedido</Link>
            <Link to="/catalogo" className="block text-center text-sm font-semibold text-wine-700 hover:underline">Continuar comprando</Link>
          </div>
        </aside>
      </div>
    </div>
  );
}
