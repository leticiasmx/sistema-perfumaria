import { useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { ChevronLeft, Minus, Plus, ShieldCheck, ShoppingBag, MessageCircle } from 'lucide-react';
import { productService } from '@/services/productService';
import { useAsync } from '@/hooks/useAsync';
import { useDocumentTitle } from '@/hooks/useDocumentTitle';
import { useCart } from '@/contexts/CartContext';
import { useToast } from '@/contexts/ToastContext';
import { Badge, Button, ErrorState, Loading, ProductImage, buttonClass } from '@/components/ui';
import { PriceTag, discountPct } from '@/components/store/PriceTag';
import { ProductCard } from '@/components/store/ProductCard';
import { hasStoreWhatsapp, storeWaLink } from '@/utils/whatsapp';

export default function ProductDetailPage() {
  const { id = '' } = useParams();
  const navigate = useNavigate();
  const { add } = useCart();
  const toast = useToast();
  const [qty, setQty] = useState(1);

  const product = useAsync(() => productService.get(id), [id]);
  const p = product.data;
  useDocumentTitle(p?.name);
  const related = useAsync(
    async () => (p?.category ? (await productService.list({ categoryId: p.category.id })).filter((x) => String(x.id) !== String(p.id)).slice(0, 4) : []),
    [p?.id, p?.category?.id],
  );

  if (product.loading) return <Loading className="py-32" />;
  if (product.error || !p) return <div className="py-20"><ErrorState message={product.error ?? 'Produto não encontrado.'} onRetry={product.reload} /></div>;

  const out = p.stockQuantity <= 0;
  const pct = discountPct(p.price, p.promotionalPrice);

  const addToCart = (goToCart?: boolean) => {
    add(p, qty);
    toast.success(`${qty}x ${p.name} na sacola.`);
    if (goToCart) navigate('/carrinho');
  };

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6">
      <Link to="/catalogo" className="mb-6 inline-flex items-center gap-1 text-sm font-medium text-ink-soft hover:text-wine-700">
        <ChevronLeft className="size-4" /> Voltar ao catálogo
      </Link>

      <div className="grid gap-10 lg:grid-cols-2">
        <div className="relative aspect-square overflow-hidden rounded-3xl border border-line bg-white shadow-soft">
          <ProductImage src={p.imageUrl} alt={p.name} />
          {pct > 0 && <span className="absolute left-5 top-5 rounded-full bg-wine-700 px-3 py-1.5 text-sm font-bold text-white">-{pct}%</span>}
        </div>

        <div className="animate-fade-up lg:py-4">
          <div className="flex flex-wrap items-center gap-2">
            {p.brand && <Link to={`/catalogo?marca=${p.brand.id}`} className="eyebrow hover:text-wine-700">{p.brand.name}</Link>}
            {p.category && <Badge tone="neutral">{p.category.name}</Badge>}
          </div>
          <h1 className="mt-3 text-4xl font-semibold leading-tight sm:text-5xl">{p.name}</h1>
          <div className="gold-rule my-6" />
          <PriceTag price={p.price} promo={p.promotionalPrice} size="lg" />
          <p className={`mt-2 text-sm font-medium ${out ? 'text-wine-700' : p.stockQuantity <= p.minimumStock ? 'text-amber-700' : 'text-emerald-700'}`}>
            {out ? 'Indisponível no momento' : p.stockQuantity <= p.minimumStock ? `Restam apenas ${p.stockQuantity} unidades` : `${p.stockQuantity} unidades disponíveis`}
          </p>

          {p.description && <p className="mt-6 whitespace-pre-line leading-relaxed text-ink-soft">{p.description}</p>}

          {!out && (
            <div className="mt-8 space-y-3">
              <div className="flex items-center gap-4">
                <span className="text-sm font-semibold">Quantidade</span>
                <div className="flex items-center rounded-full border border-line bg-white">
                  <button className="grid size-11 place-items-center text-ink-soft hover:text-wine-700 disabled:opacity-30" onClick={() => setQty((q) => Math.max(1, q - 1))} disabled={qty <= 1} aria-label="Diminuir"><Minus className="size-4" /></button>
                  <span className="w-10 text-center font-semibold tabular-nums" aria-live="polite">{qty}</span>
                  <button className="grid size-11 place-items-center text-ink-soft hover:text-wine-700 disabled:opacity-30" onClick={() => setQty((q) => Math.min(p.stockQuantity, q + 1))} disabled={qty >= p.stockQuantity} aria-label="Aumentar"><Plus className="size-4" /></button>
                </div>
              </div>
              <div className="flex flex-col gap-3 sm:flex-row">
                <Button size="lg" className="flex-1" onClick={() => addToCart()}><ShoppingBag className="size-5" /> Adicionar à sacola</Button>
                <Button size="lg" variant="gold" className="flex-1" onClick={() => addToCart(true)}>Comprar agora</Button>
              </div>
            </div>
          )}
          {out && hasStoreWhatsapp() && (
            <a href={storeWaLink(`Olá! Tenho interesse no produto "${p.name}". Quando volta ao estoque?`)} target="_blank" rel="noreferrer" className={buttonClass('whatsapp', 'lg', 'mt-8 w-full sm:w-auto')}>
              <MessageCircle className="size-5" /> Avise-me quando chegar
            </a>
          )}

          <div className="mt-8 flex items-center gap-3 rounded-2xl bg-gold-50 p-4 text-sm ring-1 ring-gold-light">
            <ShieldCheck className="size-5 shrink-0 text-gold-dark" />
            <span>Produto original. Finalize sem cadastro e combine a entrega pelo WhatsApp.</span>
          </div>
        </div>
      </div>

      {(related.data?.length ?? 0) > 0 && (
        <section className="mt-20">
          <p className="eyebrow">Você também pode gostar</p>
          <h2 className="mt-1 mb-7 text-3xl font-semibold">Produtos relacionados</h2>
          <div className="grid grid-cols-2 gap-3 sm:gap-5 md:grid-cols-4">
            {related.data!.map((r) => <ProductCard key={r.id} product={r} />)}
          </div>
        </section>
      )}
    </div>
  );
}
