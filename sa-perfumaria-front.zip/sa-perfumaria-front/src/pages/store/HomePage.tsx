import type { ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Gift, MessageCircle, ShieldCheck, Sparkles, Truck } from 'lucide-react';
import { productService } from '@/services/productService';
import { brandService, categoryService } from '@/services/brandService';
import { useAsync } from '@/hooks/useAsync';
import { useDocumentTitle } from '@/hooks/useDocumentTitle';
import { ProductCard, ProductGridSkeleton } from '@/components/store/ProductCard';
import { ErrorState, buttonClass } from '@/components/ui';
import { env } from '@/config/env';
import { hasStoreWhatsapp, storeWaLink } from '@/utils/whatsapp';
import type { Product } from '@/interfaces';

function Section({ eyebrow, title, link, children }: { eyebrow: string; title: string; link?: { to: string; label: string }; children: ReactNode }) {
  return (
    <section className="mx-auto max-w-7xl px-4 pt-16 sm:px-6">
      <div className="mb-7 flex items-end justify-between gap-4">
        <div>
          <p className="eyebrow">{eyebrow}</p>
          <h2 className="mt-1 text-3xl font-semibold sm:text-4xl">{title}</h2>
        </div>
        {link && (
          <Link to={link.to} className="group hidden shrink-0 items-center gap-1.5 text-sm font-semibold text-wine-700 sm:inline-flex">
            {link.label} <ArrowRight className="size-4 transition group-hover:translate-x-1" />
          </Link>
        )}
      </div>
      {children}
    </section>
  );
}

const Grid = ({ items }: { items: Product[] }) => (
  <div className="grid grid-cols-2 gap-3 sm:gap-5 md:grid-cols-3 lg:grid-cols-4">
    {items.map((p) => <ProductCard key={p.id} product={p} />)}
  </div>
);

export default function HomePage() {
  useDocumentTitle();
  const products = useAsync(() => productService.list(), []);
  const brands = useAsync(() => brandService.list(), []);
  const categories = useAsync(() => categoryService.list(), []);

  const all = (products.data ?? []).filter((p) => p.active !== false);
  const promos = all.filter((p) => p.promotionalPrice != null && p.promotionalPrice < p.price).slice(0, 4);
  const featured = all.filter((p) => p.featured).slice(0, 8);
  const hasSales = all.some((p) => p.soldQuantity != null);
  const bestSellers = hasSales ? [...all].sort((a, b) => (b.soldQuantity ?? 0) - (a.soldQuantity ?? 0)).slice(0, 4) : [];

  return (
    <>
      {/* HERO */}
      <section className="relative overflow-hidden bg-wine-900">
        {env.heroImageUrl && (
          <img src={env.heroImageUrl} alt="" className="absolute inset-0 h-full w-full object-cover opacity-35 mix-blend-luminosity" />
        )}
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_80%_20%,rgba(212,175,55,0.22),transparent_55%),radial-gradient(ellipse_at_10%_90%,rgba(192,57,69,0.5),transparent_60%)]" />
        <svg className="absolute -right-24 top-1/2 hidden h-[560px] -translate-y-1/2 text-gold/25 lg:block" viewBox="0 0 400 400" fill="none" aria-hidden>
          <circle cx="200" cy="200" r="198" stroke="currentColor" />
          <circle cx="200" cy="200" r="150" stroke="currentColor" strokeDasharray="2 6" />
          <circle cx="200" cy="200" r="100" stroke="currentColor" />
        </svg>
        <div className="relative mx-auto grid max-w-7xl items-center gap-10 px-6 py-16 sm:py-24 lg:grid-cols-[1.2fr_1fr]">
          <div className="animate-fade-up">
            <p className="inline-flex items-center gap-2 rounded-full border border-gold/40 px-3 py-1 text-[11px] font-semibold uppercase tracking-[0.25em] text-gold-light">
              <Sparkles className="size-3.5" /> Novo ciclo de ofertas
            </p>
            <h1 className="mt-5 text-5xl font-semibold leading-[0.95] text-white sm:text-7xl">
              Sua beleza,<br /><em className="font-medium text-gold-light">com assinatura.</em>
            </h1>
            <p className="mt-6 max-w-md text-base leading-relaxed text-white/75">
              Perfumes, maquiagem e cuidados das marcas que você ama — escolhidos a dedo e entregues com atendimento pessoal.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link to="/catalogo" className={buttonClass('gold', 'lg')}>Ver catálogo <ArrowRight className="size-4" /></Link>
              <Link to="/catalogo?promo=1" className={buttonClass('outline', 'lg', '!bg-transparent !text-white border-white/40 hover:!bg-white/10')}>Promoções</Link>
            </div>
          </div>
          <div className="hidden lg:block">
            <div className="relative mx-auto aspect-[4/5] w-80 rounded-[2.5rem] border border-gold/40 bg-gradient-to-b from-white/10 to-white/0 p-3 backdrop-blur-sm">
              <div className="grid h-full place-items-center rounded-[2rem] bg-gradient-to-br from-wine-700 to-wine-900 ring-1 ring-gold/30">
                <svg viewBox="0 0 120 180" className="h-3/4" aria-hidden>
                  <rect x="46" y="8" width="28" height="26" rx="4" fill="#D4AF37" />
                  <rect x="40" y="32" width="40" height="10" rx="2" fill="#B8860B" />
                  <path d="M22 62c0-10 8-18 18-18h40c10 0 18 8 18 18v96c0 10-8 18-18 18H40c-10 0-18-8-18-18z" fill="#fff" fillOpacity=".1" stroke="#E8D9A8" strokeWidth="1.5" />
                  <text x="60" y="118" textAnchor="middle" fontFamily="Cormorant Garamond, serif" fontStyle="italic" fontSize="17" fill="#E8D9A8">{env.storeMonogram}</text>
                </svg>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Benefícios */}
      <div className="border-b border-line bg-white">
        <div className="scrollbar-none mx-auto flex max-w-7xl gap-8 overflow-x-auto px-6 py-5 text-sm">
          {[
            { Icon: ShieldCheck, t: 'Produtos originais', s: 'Direto das marcas' },
            { Icon: Gift, t: 'Parcelamento facilitado', s: 'Combine com a vendedora' },
            { Icon: Truck, t: 'Entrega combinada', s: 'Pelo WhatsApp' },
          ].map(({ Icon, t, s }) => (
            <div key={t} className="flex shrink-0 items-center gap-3">
              <span className="grid size-10 place-items-center rounded-full bg-gold-50 text-gold-dark ring-1 ring-gold-light"><Icon className="size-5" /></span>
              <div><p className="font-semibold">{t}</p><p className="text-xs text-ink-soft">{s}</p></div>
            </div>
          ))}
        </div>
      </div>

      {products.error ? (
        <div className="mx-auto max-w-7xl px-6 pt-10"><ErrorState message={products.error} onRetry={products.reload} /></div>
      ) : (
        <>
          {(products.loading || promos.length > 0) && (
            <Section eyebrow="Ofertas do ciclo" title="Promoções imperdíveis" link={{ to: '/catalogo?promo=1', label: 'Todas as promoções' }}>
              {products.loading ? <ProductGridSkeleton count={4} /> : <Grid items={promos} />}
            </Section>
          )}

          {/* Categorias */}
          {(categories.data?.length ?? 0) > 0 && (
            <Section eyebrow="Explore" title="Categorias">
              <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
                {categories.data!.map((c, i) => (
                  <Link key={c.id} to={`/catalogo?categoria=${c.id}`}
                    className={`group relative flex aspect-[4/3] items-end overflow-hidden rounded-2xl p-4 ring-1 ring-gold-light/60 transition hover:-translate-y-1 hover:shadow-lift ${i % 2 ? 'bg-gradient-to-br from-wine-700 to-wine-900 text-white' : 'bg-gradient-to-br from-gold-50 to-white text-ink'}`}>
                    <span className="absolute right-3 top-3 font-display text-4xl italic opacity-20">{String(i + 1).padStart(2, '0')}</span>
                    <span className="font-display text-xl font-semibold leading-tight">{c.name}</span>
                  </Link>
                ))}
              </div>
            </Section>
          )}

          {bestSellers.length > 0 && (
            <Section eyebrow="As queridinhas" title="Mais vendidos" link={{ to: '/catalogo', label: 'Ver catálogo' }}>
              <Grid items={bestSellers} />
            </Section>
          )}

          {/* Marcas */}
          {(brands.data?.length ?? 0) > 0 && (
            <Section eyebrow="Trabalho com" title="Marcas disponíveis">
              <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
                {brands.data!.map((b) => (
                  <Link key={b.id} to={`/catalogo?marca=${b.id}`}
                    className="grid h-24 place-items-center rounded-2xl border border-line bg-white px-4 text-center shadow-soft transition hover:border-gold hover:shadow-lift">
                    {b.logoUrl ? <img src={b.logoUrl} alt={b.name} className="max-h-12 object-contain" /> : <span className="font-display text-xl font-semibold text-wine-900">{b.name}</span>}
                  </Link>
                ))}
              </div>
            </Section>
          )}

          {(products.loading || featured.length > 0) && (
            <Section eyebrow="Seleção especial" title="Produtos em destaque" link={{ to: '/catalogo', label: 'Ver tudo' }}>
              {products.loading ? <ProductGridSkeleton /> : <Grid items={featured} />}
            </Section>
          )}
        </>
      )}

      {/* CTA WhatsApp */}
      {hasStoreWhatsapp() && (
        <section className="mx-auto max-w-7xl px-4 pt-20 sm:px-6">
          <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-wine-900 to-wine-700 px-8 py-12 text-white sm:px-14">
            <div className="absolute -right-10 -top-10 size-56 rounded-full border border-gold/30" />
            <div className="relative flex flex-col items-start justify-between gap-6 md:flex-row md:items-center">
              <div>
                <p className="eyebrow !text-gold-light">Atendimento pessoal</p>
                <h2 className="mt-2 text-3xl font-semibold sm:text-4xl">Precisa de ajuda para escolher?</h2>
                <p className="mt-2 max-w-lg text-white/75">Me chama no WhatsApp: indico o perfume ideal, tiro dúvidas e combino a entrega.</p>
              </div>
              <a href={storeWaLink('Olá! Gostaria de uma indicação de produto.')} target="_blank" rel="noreferrer" className={buttonClass('whatsapp', 'lg')}>
                <MessageCircle className="size-5" /> Conversar agora
              </a>
            </div>
          </div>
        </section>
      )}
    </>
  );
}
