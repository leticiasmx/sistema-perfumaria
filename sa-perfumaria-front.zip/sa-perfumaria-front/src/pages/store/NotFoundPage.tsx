import { Link } from 'react-router-dom';
import { buttonClass } from '@/components/ui';
import { useDocumentTitle } from '@/hooks/useDocumentTitle';

export default function NotFoundPage() {
  useDocumentTitle('Página não encontrada');
  return (
    <div className="mx-auto flex min-h-[60vh] max-w-lg flex-col items-center justify-center px-6 text-center">
      <p className="font-display text-8xl font-semibold italic text-gold">404</p>
      <h1 className="mt-2 text-3xl font-semibold">Página não encontrada</h1>
      <p className="mt-2 text-ink-soft">O endereço pode ter mudado ou não existe mais.</p>
      <Link to="/" className={buttonClass('primary', 'lg', 'mt-8')}>Voltar ao início</Link>
    </div>
  );
}
