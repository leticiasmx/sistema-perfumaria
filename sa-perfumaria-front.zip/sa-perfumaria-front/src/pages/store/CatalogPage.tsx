import { useMemo, useState, type ReactNode } from 'react';
import { useSearchParams } from 'react-router-dom';
import { SlidersHorizontal, Search, X } from 'lucide-react';
import { productService } from '@/services/productService';
import { brandService, categoryService } from '@/services/brandService';
import { useAsync } from '@/hooks/useAsync';
import { useDebounce } from '@/hooks/useDebounce';
import { useDocumentTitle } from '@/hooks/useDocumentTitle';
import { ProductCard, ProductGridSkeleton } from '@/components/store/ProductCard';
import { AsyncContent, Button, EmptyState } from '@/components/ui';
import { cn } from '@/utils/cn';

type Sort = 'relevance' | 'price-asc' | 'price-desc' | 'name';

export default function CatalogPage() {
  useDocumentTitle('Catálogo');
  const [params, setParams] = useSearchParams();
  const q = params.get('q') ?? '';
  const brandId = params.get('marca') ?? '';
  const categoryId = params.get('categoria') ?? '';
  const promoOnly = params.get('promo') === '1';
  const [search, setSearch] = useState(q);
  const [sort, setSort] = useState<Sort>('relevance');
  const [filtersOpen, setFiltersOpen] = useState(false);
  const debounced = useDebounce(search);

  const set = (key: string, value: string) => {
    const next = new URLSearchParams(params);
    value ? next.set(key, value) : next.delete(key);
    setParams(next, { replace: true });
  };

  // Busca/filtros são enviados à API (filtragem no servidor).
  const products = useAsync(
    () => productService.list({ name: debounced || undefined, brandId: brandId || undefined, categoryId: categoryId || undefined }),
    [debounced, brandId, categoryId],
  );
  const brands = useAsync(() => brandService.list(), []);
  const categories = useAsync(() => categoryService.list(), []);

  // Apenas ordenação/recorte de exibição no front.
  const visible = useMemo(() => {
    let list = (products.data ?? []).filter((p) => p.active !== false);
    if (promoOnly) list = list.filter((p) => p.promotionalPrice != null && p.promotionalPrice < p.price);
    const price = (p: (typeof list)[number]) => p.promotionalPrice ?? p.price;
    if (sort === 'price-asc') list = [...list].sort((a, b) => price(a) - price(b));
    if (sort === 'price-desc') list = [...list].sort((a, b) => price(b) - price(a));
    if (sort === 'name') list = [...list].sort((a, b) => a.name.localeCompare(b.name));
    return list;
  }, [products.data, promoOnly, sort]);

  const activeCount = [brandId, categoryId, promoOnly ? '1' : ''].filter(Boolean).length;

  const Chip = ({ active, onClick, children }: { active: boolean; onClick: () => void; children: ReactNode }) => (
    <button onClick={onClick} className={cn('rounded-full px-3.5 py-2 text-left text-sm font-medium transition',
      active ? 'bg-wine-700 text-white' : 'text-ink hover:bg-gold-50')}>{children}</button>
  );

  const filters = (
    <div className="space-y-7">
      <div>
        <p className="eyebrow mb-3">Ofertas</p>
        <Chip active={promoOnly} onClick={() => set('promo', promoOnly ? '' : '1')}>Somente promoções</Chip>
      </div>
      <div>
        <p className="eyebrow mb-3">Categorias</p>
        <div className="flex flex-col gap-0.5">
          <Chip active={!categoryId} onClick={() => set('categoria', '')}>Todas</Chip>
          {categories.data?.map((c) => <Chip key={c.id} active={categoryId === String(c.id)} onClick={() => set('categoria', String(c.id))}>{c.name}</Chip>)}
        </div>
      </div>
      <div>
        <p className="eyebrow mb-3">Marcas</p>
        <div className="flex flex-col gap-0.5">
          <Chip active={!brandId} onClick={() => set('marca', '')}>Todas</Chip>
          {brands.data?.map((b) => <Chip key={b.id} active={brandId === String(b.id)} onClick={() => set('marca', String(b.id))}>{b.name}</Chip>)}
        </div>
      </div>
    </div>
  );

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6">
      <div className="mb-8">
        <p className="eyebrow">{promoOnly ? 'Ofertas do ciclo' : 'Catálogo'}</p>
        <h1 className="mt-1 text-4xl font-semibold sm:text-5xl">{promoOnly ? 'Promoções' : 'Todos os produtos'}</h1>
      </div>

      <div className="mb-6 flex flex-col gap-3 sm:flex-row sm:items-center">
        <div className="relative flex-1">
          <Search className="pointer-events-none absolute left-4 top-1/2 size-4 -translate-y-1/2 text-gold-dark" />
          <input value={search} onChange={(e) => { setSearch(e.target.value); set('q', e.target.value); }} placeholder="Pesquisar pelo nome do produto"
            aria-label="Pesquisar produtos" className="h-12 w-full rounded-full border border-line bg-white pl-11 pr-4 text-sm outline-none focus:border-gold focus:ring-4 focus:ring-gold/15" />
        </div>
        <div className="flex gap-2">
          <Button variant="outline" className="lg:hidden" onClick={() => setFiltersOpen(true)}>
            <SlidersHorizontal className="size-4" /> Filtros {activeCount > 0 && <span className="rounded-full bg-wine-700 px-1.5 text-[11px] text-white">{activeCount}</span>}
          </Button>
          <select value={sort} onChange={(e) => setSort(e.target.value as Sort)} aria-label="Ordenar"
            className="h-11 rounded-full border border-line bg-white px-4 text-sm font-medium outline-none focus:border-gold">
            <option value="relevance">Relevância</option>
            <option value="price-asc">Menor preço</option>
            <option value="price-desc">Maior preço</option>
            <option value="name">Nome (A–Z)</option>
          </select>
        </div>
      </div>

      <div className="grid gap-8 lg:grid-cols-[220px_1fr]">
        <aside className="hidden lg:block">{filters}</aside>
        <div>
          <AsyncContent loading={products.loading} error={products.error} data={products.data} onRetry={products.reload}
            loadingView={<ProductGridSkeleton />}
            isEmpty={() => visible.length === 0}
            empty={<EmptyState title="Nenhum produto encontrado" message="Tente outro termo de busca ou limpe os filtros."
              action={<Button variant="outline" onClick={() => { setSearch(''); setParams({}); }}>Limpar filtros</Button>} />}>
            {() => (
              <>
                <p className="mb-4 text-sm text-ink-soft">{visible.length} {visible.length === 1 ? 'produto' : 'produtos'}</p>
                <div className={cn('grid grid-cols-2 gap-3 sm:gap-5 md:grid-cols-3', products.loading && 'opacity-60')}>
                  {visible.map((p) => <ProductCard key={p.id} product={p} />)}
                </div>
              </>
            )}
          </AsyncContent>
        </div>
      </div>

      {filtersOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 animate-fade-in bg-ink/40" onClick={() => setFiltersOpen(false)} />
          <div className="absolute inset-x-0 bottom-0 max-h-[85vh] animate-fade-up overflow-y-auto rounded-t-3xl bg-white p-6">
            <div className="mb-5 flex items-center justify-between">
              <h2 className="text-2xl font-semibold">Filtros</h2>
              <button onClick={() => setFiltersOpen(false)} aria-label="Fechar filtros" className="p-2"><X className="size-5" /></button>
            </div>
            {filters}
            <Button className="mt-8 w-full" size="lg" onClick={() => setFiltersOpen(false)}>Ver {visible.length} produtos</Button>
          </div>
        </div>
      )}
    </div>
  );
}
