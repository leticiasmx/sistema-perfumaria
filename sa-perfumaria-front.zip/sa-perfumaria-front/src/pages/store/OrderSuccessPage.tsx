import { Link, Navigate, useLocation } from 'react-router-dom';
import { CheckCircle2, MessageCircle } from 'lucide-react';
import type { Order } from '@/interfaces';
import { useDocumentTitle } from '@/hooks/useDocumentTitle';
import { buttonClass } from '@/components/ui';
import { money } from '@/utils/format';
import { paymentLabel } from '@/config/store';
import { hasStoreWhatsapp, orderMessage, storeWaLink } from '@/utils/whatsapp';

export default function OrderSuccessPage() {
  useDocumentTitle('Pedido confirmado');
  const order = (useLocation().state as { order?: Order } | null)?.order;
  if (!order) return <Navigate to="/" replace />;

  return (
    <div className="mx-auto max-w-2xl px-4 py-16 text-center">
      <div className="mx-auto grid size-20 animate-fade-up place-items-center rounded-full bg-gold-50 ring-1 ring-gold-light">
        <CheckCircle2 className="size-10 text-gold-dark" />
      </div>
      <p className="eyebrow mt-6">Pedido registrado</p>
      <h1 className="mt-2 text-4xl font-semibold sm:text-5xl">Obrigada, {order.customer.name.split(' ')[0]}!</h1>
      <p className="mt-3 text-ink-soft">Recebi seu pedido <b className="text-ink">{order.number ?? `#${order.id}`}</b>. Em breve entro em contato para combinar a entrega.</p>

      <div className="card mt-8 p-6 text-left">
        <ul className="divide-y divide-line text-sm">
          {order.items.map((i) => (
            <li key={String(i.productId)} className="flex justify-between gap-4 py-2.5">
              <span>{i.quantity}x {i.productName ?? `Produto ${i.productId}`}</span>
              {i.subtotal != null && <span className="tabular-nums">{money(i.subtotal)}</span>}
            </li>
          ))}
        </ul>
        <div className="gold-rule my-4" />
        {order.discount > 0 && <p className="flex justify-between text-sm text-wine-700"><span>Desconto</span><span>−{money(order.discount)}</span></p>}
        <p className="mt-1 flex items-baseline justify-between"><span className="font-semibold">Total</span><span className="font-display text-3xl font-semibold">{money(order.total)}</span></p>
        <p className="mt-1 text-sm text-ink-soft">{paymentLabel(order.paymentMethod)}{order.installments > 1 && ` em ${order.installments}x`}</p>
      </div>

      <div className="mt-8 flex flex-col justify-center gap-3 sm:flex-row">
        {hasStoreWhatsapp() && (
          <a href={storeWaLink(orderMessage(order))} target="_blank" rel="noreferrer" className={buttonClass('whatsapp', 'lg')}>
            <MessageCircle className="size-5" /> Enviar pedido no WhatsApp
          </a>
        )}
        <Link to="/catalogo" className={buttonClass('outline', 'lg')}>Continuar comprando</Link>
      </div>
    </div>
  );
}
