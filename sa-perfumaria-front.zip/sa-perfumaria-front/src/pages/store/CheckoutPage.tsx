import { useState, type FormEvent } from 'react';
import { Link, Navigate, useNavigate } from 'react-router-dom';
import { Check, ChevronLeft, CreditCard, Phone, User, ClipboardCheck } from 'lucide-react';
import { useCart } from '@/contexts/CartContext';
import { useToast } from '@/contexts/ToastContext';
import { customerService } from '@/services/customerService';
import { orderService } from '@/services/orderService';
import { useDocumentTitle } from '@/hooks/useDocumentTitle';
import { Button, Input, ProductImage } from '@/components/ui';
import { OrderSummary } from './CartPage';
import { PAYMENT_METHODS, paymentLabel } from '@/config/store';
import { date, maskPhone, money, onlyDigits } from '@/utils/format';
import { errorMessage } from '@/utils/errors';
import { cn } from '@/utils/cn';
import type { Customer, PaymentMethod } from '@/interfaces';

type Step = 0 | 1 | 2 | 3;
const steps = [
  { label: 'Telefone', Icon: Phone },
  { label: 'Seus dados', Icon: User },
  { label: 'Pagamento', Icon: CreditCard },
  { label: 'Revisão', Icon: ClipboardCheck },
];

export default function CheckoutPage() {
  useDocumentTitle('Finalizar pedido');
  const cart = useCart();
  const toast = useToast();
  const navigate = useNavigate();

  const [step, setStep] = useState<Step>(0);
  const [phone, setPhone] = useState('');
  const [existing, setExisting] = useState<Customer | null>(null);
  const [name, setName] = useState('');
  const [birthDate, setBirthDate] = useState('');
  const [method, setMethod] = useState<PaymentMethod | ''>('');
  const [installments, setInstallments] = useState(1);
  const [busy, setBusy] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  if (!cart.items.length) return <Navigate to="/carrinho" replace />;

  const digits = onlyDigits(phone);
  const maxInst = PAYMENT_METHODS.find((p) => p.value === method)?.maxInstallments ?? 1;

  const lookup = async (e: FormEvent) => {
    e.preventDefault();
    if (digits.length < 10) return setErrors({ phone: 'Informe o telefone com DDD.' });
    setErrors({});
    setBusy(true);
    try {
      const c = await customerService.findByPhone(digits);
      setExisting(c);
      if (c) { setName(c.name); setBirthDate(c.birthDate ?? ''); }
      setStep(1);
    } catch (err) {
      toast.error(errorMessage(err, 'Não foi possível consultar seu cadastro.'));
    } finally {
      setBusy(false);
    }
  };

  const saveData = (e: FormEvent) => {
    e.preventDefault();
    const errs: Record<string, string> = {};
    if (name.trim().split(/\s+/).length < 2) errs.name = 'Informe nome e sobrenome.';
    if (!existing && !birthDate) errs.birthDate = 'Informe sua data de aniversário.';
    setErrors(errs);
    if (!Object.keys(errs).length) setStep(2);
  };

  const savePayment = (e: FormEvent) => {
    e.preventDefault();
    if (!method) return setErrors({ method: 'Escolha a forma de pagamento.' });
    setErrors({});
    setStep(3);
  };

  const confirm = async () => {
    if (!method) return;
    setBusy(true);
    try {
      const order = await orderService.create({
        customer: { id: existing?.id, name: name.trim(), phone: digits, birthDate: birthDate || null },
        items: cart.items.map((i) => ({ productId: i.productId, quantity: i.quantity })),
        paymentMethod: method,
        installments: maxInst > 1 ? installments : 1,
        couponCode: cart.coupon?.valid ? cart.coupon.code : null,
      });
      cart.clear();
      navigate('/pedido/confirmado', { replace: true, state: { order } });
    } catch (err) {
      toast.error(errorMessage(err, 'Não foi possível registrar seu pedido.'));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6">
      <Link to="/carrinho" className="mb-6 inline-flex items-center gap-1 text-sm font-medium text-ink-soft hover:text-wine-700"><ChevronLeft className="size-4" /> Voltar à sacola</Link>
      <h1 className="text-4xl font-semibold sm:text-5xl">Finalizar pedido</h1>
      <p className="mt-2 text-sm text-ink-soft">Sem cadastro e sem senha — só precisamos do seu telefone.</p>

      {/* Stepper */}
      <ol className="mt-8 grid grid-cols-4 gap-2">
        {steps.map(({ label, Icon }, i) => (
          <li key={label} className="flex flex-col items-center gap-2 text-center">
            <span className={cn('grid size-10 place-items-center rounded-full ring-1 transition',
              i < step ? 'bg-gold text-white ring-gold' : i === step ? 'bg-wine-700 text-white ring-wine-700' : 'bg-white text-ink-soft ring-line')}>
              {i < step ? <Check className="size-4" /> : <Icon className="size-4" />}
            </span>
            <span className={cn('text-[11px] font-semibold sm:text-xs', i === step ? 'text-wine-700' : 'text-ink-soft')}>{label}</span>
          </li>
        ))}
      </ol>

      <div className="mt-8 grid gap-8 lg:grid-cols-[1fr_360px]">
        <div className="card p-6 sm:p-8">
          {step === 0 && (
            <form onSubmit={lookup} className="space-y-5 animate-fade-up">
              <div><h2 className="text-2xl font-semibold">Qual é o seu telefone?</h2><p className="text-sm text-ink-soft">Se você já comprou comigo, recupero seus dados automaticamente.</p></div>
              <Input label="Telefone (WhatsApp)" inputMode="tel" autoComplete="tel" placeholder="(11) 98765-4321" value={phone} onChange={(e) => setPhone(maskPhone(e.target.value))} error={errors.phone} icon={<Phone className="size-4" />} required autoFocus />
              <Button type="submit" size="lg" className="w-full" loading={busy}>Continuar</Button>
            </form>
          )}

          {step === 1 && (
            <form onSubmit={saveData} className="space-y-5 animate-fade-up">
              {existing ? (
                <div className="rounded-2xl bg-gold-50 p-4 ring-1 ring-gold-light">
                  <p className="font-display text-2xl font-semibold">Que bom te ver de novo, {existing.name.split(' ')[0]}! 💐</p>
                  <p className="text-sm text-ink-soft">Confira seus dados antes de continuar.</p>
                </div>
              ) : (
                <div><h2 className="text-2xl font-semibold">Primeira compra por aqui?</h2><p className="text-sm text-ink-soft">Preencha seus dados — leva só um minuto.</p></div>
              )}
              <Input label="Nome completo" autoComplete="name" value={name} onChange={(e) => setName(e.target.value)} error={errors.name} required readOnly={!!existing} />
              <Input label="Telefone" value={maskPhone(digits)} readOnly hint="Para alterar, volte à etapa anterior." />
              <Input label="Data de aniversário" type="date" value={birthDate} onChange={(e) => setBirthDate(e.target.value)} error={errors.birthDate} required={!existing} readOnly={!!existing && !!existing.birthDate}
                hint={!existing ? 'Assim posso te mandar um mimo no seu mês. 🎁' : undefined} />
              <div className="flex gap-3">
                <Button variant="ghost" onClick={() => setStep(0)}>Voltar</Button>
                <Button type="submit" size="lg" className="flex-1">Continuar</Button>
              </div>
            </form>
          )}

          {step === 2 && (
            <form onSubmit={savePayment} className="space-y-5 animate-fade-up">
              <h2 className="text-2xl font-semibold">Forma de pagamento</h2>
              <div className="grid gap-3 sm:grid-cols-2" role="radiogroup">
                {PAYMENT_METHODS.map((m) => (
                  <label key={m.value} className={cn('flex cursor-pointer items-center gap-3 rounded-2xl border p-4 transition',
                    method === m.value ? 'border-wine-700 bg-wine-50/60 ring-2 ring-wine-700/15' : 'border-line hover:border-gold')}>
                    <input type="radio" name="method" className="accent-wine-700" checked={method === m.value} onChange={() => { setMethod(m.value); setInstallments(1); }} />
                    <span className="text-sm font-semibold">{m.label}</span>
                  </label>
                ))}
              </div>
              {errors.method && <p className="text-xs font-medium text-wine-700">{errors.method}</p>}
              {maxInst > 1 && (
                <div>
                  <p className="mb-2 text-[13px] font-semibold">Parcelamento</p>
                  <div className="flex flex-wrap gap-2">
                    {Array.from({ length: maxInst }, (_, i) => i + 1).map((n) => (
                      <button type="button" key={n} onClick={() => setInstallments(n)}
                        className={cn('rounded-full border px-4 py-2 text-sm font-semibold transition', installments === n ? 'border-wine-700 bg-wine-700 text-white' : 'border-line hover:border-gold')}>
                        {n}x <span className="font-normal opacity-80">≈ {money(cart.total / n)}</span>
                      </button>
                    ))}
                  </div>
                  <p className="mt-2 text-xs text-ink-soft">Valores aproximados. As parcelas definitivas são geradas pela loja ao confirmar o pedido.</p>
                </div>
              )}
              <div className="flex gap-3">
                <Button variant="ghost" onClick={() => setStep(1)}>Voltar</Button>
                <Button type="submit" size="lg" className="flex-1">Revisar pedido</Button>
              </div>
            </form>
          )}

          {step === 3 && (
            <div className="space-y-6 animate-fade-up">
              <h2 className="text-2xl font-semibold">Revise seu pedido</h2>
              <div className="grid gap-4 rounded-2xl bg-ivory p-5 text-sm sm:grid-cols-2">
                <div><p className="eyebrow !text-[10px]">Cliente</p><p className="mt-1 font-semibold">{name}</p><p className="text-ink-soft">{maskPhone(digits)}{birthDate && ` · ${date(birthDate)}`}</p></div>
                <div><p className="eyebrow !text-[10px]">Pagamento</p><p className="mt-1 font-semibold">{paymentLabel(method)}</p>{maxInst > 1 && <p className="text-ink-soft">{installments}x</p>}</div>
              </div>
              <ul className="divide-y divide-line">
                {cart.items.map((i) => (
                  <li key={i.productId} className="flex items-center gap-3 py-3 text-sm">
                    <span className="size-12 shrink-0 overflow-hidden rounded-lg bg-ivory"><ProductImage src={i.imageUrl} alt={i.name} /></span>
                    <span className="flex-1">{i.quantity}x {i.name}</span>
                    <span className="font-semibold tabular-nums">{money(i.unitPrice * i.quantity)}</span>
                  </li>
                ))}
              </ul>
              <div className="flex gap-3">
                <Button variant="ghost" onClick={() => setStep(2)}>Voltar</Button>
                <Button size="lg" variant="gold" className="flex-1" loading={busy} onClick={confirm}>Confirmar pedido</Button>
              </div>
            </div>
          )}
        </div>

        <aside className="lg:sticky lg:top-36 lg:self-start">
          <div className="card p-6"><h2 className="mb-4 text-xl font-semibold">Resumo</h2><OrderSummary compact /></div>
        </aside>
      </div>
    </div>
  );
}
