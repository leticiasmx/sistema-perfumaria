import { useState, type FormEvent } from 'react';
import { Check, Pencil, Plus, Trash2, X, Tags, LayoutGrid } from 'lucide-react';
import { brandService, categoryService } from '@/services/brandService';
import { useAsync } from '@/hooks/useAsync';
import { useDocumentTitle } from '@/hooks/useDocumentTitle';
import { useToast } from '@/contexts/ToastContext';
import { AsyncContent, Button, ConfirmDialog, EmptyState, PageHeader, Panel } from '@/components/ui';
import { errorMessage } from '@/utils/errors';
import type { Id } from '@/interfaces';

interface Named { id: Id; name: string }
interface CrudService { list: () => Promise<Named[]>; create: (p: { name: string }) => Promise<Named>; update: (id: Id, p: { name: string }) => Promise<Named>; remove: (id: Id) => Promise<void> }

function NameList({ title, singular, service, Icon }: { title: string; singular: string; service: CrudService; Icon: typeof Tags }) {
  const toast = useToast();
  const list = useAsync(() => service.list(), []);
  const [newName, setNewName] = useState('');
  const [editId, setEditId] = useState<Id | null>(null);
  const [editName, setEditName] = useState('');
  const [busy, setBusy] = useState(false);
  const [toDelete, setToDelete] = useState<Named | null>(null);

  const run = async (fn: () => Promise<unknown>, ok: string) => {
    setBusy(true);
    try { await fn(); toast.success(ok); await list.reload(); return true; }
    catch (err) { toast.error(errorMessage(err)); return false; }
    finally { setBusy(false); }
  };

  const add = async (e: FormEvent) => {
    e.preventDefault();
    if (newName.trim().length < 2) return toast.error(`Informe o nome da ${singular}.`);
    if (await run(() => service.create({ name: newName.trim() }), `${singular[0].toUpperCase() + singular.slice(1)} cadastrada.`)) setNewName('');
  };

  const save = async () => {
    if (editId == null || editName.trim().length < 2) return;
    if (await run(() => service.update(editId, { name: editName.trim() }), 'Alteração salva.')) setEditId(null);
  };

  return (
    <Panel title={<span className="flex items-center gap-2 text-xl font-semibold"><Icon className="size-5 text-gold-dark" /> {title}</span>}>
      <form onSubmit={add} className="flex gap-2 border-b border-line p-4">
        <input value={newName} onChange={(e) => setNewName(e.target.value)} placeholder={`Nova ${singular}`} aria-label={`Nome da nova ${singular}`}
          className="h-11 min-w-0 flex-1 rounded-xl border border-line px-3.5 text-sm outline-none focus:border-gold focus:ring-4 focus:ring-gold/15" />
        <Button type="submit" loading={busy && editId == null}><Plus className="size-4" /> Adicionar</Button>
      </form>
      <AsyncContent {...list} onRetry={list.reload} empty={<EmptyState title={`Nenhuma ${singular} cadastrada`} />}>
        {(items) => (
          <ul className="divide-y divide-line">
            {items.map((it) => (
              <li key={it.id} className="flex items-center gap-2 px-4 py-2.5">
                {editId === it.id ? (
                  <>
                    <input autoFocus value={editName} onChange={(e) => setEditName(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter') save(); if (e.key === 'Escape') setEditId(null); }}
                      className="h-10 flex-1 rounded-lg border border-gold px-3 text-sm outline-none ring-4 ring-gold/15" aria-label="Novo nome" />
                    <button onClick={save} disabled={busy} className="rounded-full p-2 text-emerald-700 hover:bg-emerald-50" aria-label="Salvar"><Check className="size-4" /></button>
                    <button onClick={() => setEditId(null)} className="rounded-full p-2 text-ink-soft hover:bg-ivory" aria-label="Cancelar"><X className="size-4" /></button>
                  </>
                ) : (
                  <>
                    <span className="flex-1 py-1.5 text-sm font-medium">{it.name}</span>
                    <button onClick={() => { setEditId(it.id); setEditName(it.name); }} className="rounded-full p-2 text-ink-soft hover:bg-gold-50 hover:text-gold-dark" aria-label={`Editar ${it.name}`}><Pencil className="size-4" /></button>
                    <button onClick={() => setToDelete(it)} className="rounded-full p-2 text-ink-soft hover:bg-wine-50 hover:text-wine-700" aria-label={`Excluir ${it.name}`}><Trash2 className="size-4" /></button>
                  </>
                )}
              </li>
            ))}
          </ul>
        )}
      </AsyncContent>
      <ConfirmDialog open={!!toDelete} title={`Excluir ${singular}`} confirmLabel="Excluir" loading={busy}
        message={`Excluir "${toDelete?.name}"? Se houver produtos vinculados, a loja pode recusar a exclusão.`}
        onClose={() => setToDelete(null)}
        onConfirm={async () => { if (toDelete && (await run(() => service.remove(toDelete.id), 'Excluído com sucesso.'))) setToDelete(null); }} />
    </Panel>
  );
}

export default function BrandsCategoriesPage() {
  useDocumentTitle('Marcas e categorias');
  return (
    <>
      <PageHeader eyebrow="Catálogo" title="Marcas e categorias" description="Organize como os produtos aparecem nos filtros da loja." />
      <div className="grid gap-6 lg:grid-cols-2">
        <NameList title="Marcas" singular="marca" service={brandService} Icon={Tags} />
        <NameList title="Categorias" singular="categoria" service={categoryService} Icon={LayoutGrid} />
      </div>
    </>
  );
}
