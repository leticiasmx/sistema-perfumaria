import { useEffect, useState, type FormEvent } from 'react';
import { Pencil, Plus, Sparkles, TicketPercent, Trash2 } from 'lucide-react';
import { couponService } from '@/services/couponService';
import { promotionService } from '@/services/promotionService';
import { productService } from '@/services/productService';
import { useAsync } from '@/hooks/useAsync';
import { useDocumentTitle } from '@/hooks/useDocumentTitle';
import { useToast } from '@/contexts/ToastContext';
import {
  AsyncContent, Badge, Button, Checkbox, ConfirmDialog, DataTable, EmptyState, Input, Modal, PageHeader, Panel, Select, Tabs, type Column,
} from '@/components/ui';
import { date, money, today } from '@/utils/format';
import { errorMessage } from '@/utils/errors';
import type { Coupon, CouponPayload, DiscountType, Id, Product, Promotion, PromotionPayload, PromotionScope } from '@/interfaces';

const discountLabel = (t: DiscountType, v: number) => (t === 'PERCENTUAL' ? `${v}%` : money(v));
const isExpired = (until?: string | null) => !!until && until < today();

function CouponForm({ coupon, onClose, onSaved }: { coupon: Coupon | null; onClose: () => void; onSaved: () => void }) {
  const toast = useToast();
  const [f, setF] = useState({ code: '', discountType: 'PERCENTUAL' as DiscountType, discountValue: '', validFrom: today(), validUntil: '', minimumOrderValue: '', usageLimit: '', active: true });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);
  useEffect(() => {
    if (coupon) setF({ code: coupon.code, discountType: coupon.discountType, discountValue: String(coupon.discountValue), validFrom: coupon.validFrom ?? '', validUntil: coupon.validUntil ?? '',
      minimumOrderValue: coupon.minimumOrderValue != null ? String(coupon.minimumOrderValue) : '', usageLimit: coupon.usageLimit != null ? String(coupon.usageLimit) : '', active: coupon.active });
  }, [coupon]);
  const set = (k: keyof typeof f, v: string | boolean) => setF((s) => ({ ...s, [k]: v }));

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    const val = Number(f.discountValue.replace(',', '.'));
    const errs: Record<string, string> = {};
    if (!/^[A-Z0-9_-]{3,20}$/.test(f.code)) errs.code = 'Use de 3 a 20 letras maiúsculas, números, - ou _.';
    if (!(val > 0) || (f.discountType === 'PERCENTUAL' && val > 100)) errs.discountValue = f.discountType === 'PERCENTUAL' ? 'Entre 1 e 100.' : 'Maior que zero.';
    if (f.validFrom && f.validUntil && f.validUntil < f.validFrom) errs.validUntil = 'Deve ser posterior ao início.';
    setErrors(errs);
    if (Object.keys(errs).length) return;
    const payload: CouponPayload = {
      code: f.code, discountType: f.discountType, discountValue: val, validFrom: f.validFrom || null, validUntil: f.validUntil || null,
      minimumOrderValue: f.minimumOrderValue ? Number(f.minimumOrderValue.replace(',', '.')) : null, usageLimit: f.usageLimit ? Number(f.usageLimit) : null, active: f.active,
    };
    setSaving(true);
    try { coupon ? await couponService.update(coupon.id, payload) : await couponService.create(payload); toast.success('Cupom salvo.'); onSaved(); onClose(); }
    catch (err) { toast.error(errorMessage(err)); } finally { setSaving(false); }
  };

  return (
    <form onSubmit={submit} className="space-y-4" noValidate>
      <Input label="Código do cupom" value={f.code} onChange={(e) => set('code', e.target.value.toUpperCase().replace(/\s/g, ''))} error={errors.code} className="uppercase tracking-wider" required />
      <div className="grid gap-4 sm:grid-cols-2">
        <Select label="Tipo de desconto" value={f.discountType} onChange={(e) => set('discountType', e.target.value)}><option value="PERCENTUAL">Percentual (%)</option><option value="VALOR">Valor fixo (R$)</option></Select>
        <Input label={f.discountType === 'PERCENTUAL' ? 'Desconto (%)' : 'Desconto (R$)'} inputMode="decimal" value={f.discountValue} onChange={(e) => set('discountValue', e.target.value)} error={errors.discountValue} required />
      </div>
      <div className="grid gap-4 sm:grid-cols-2">
        <Input label="Válido a partir de" type="date" value={f.validFrom} onChange={(e) => set('validFrom', e.target.value)} />
        <Input label="Válido até" type="date" value={f.validUntil} onChange={(e) => set('validUntil', e.target.value)} error={errors.validUntil} hint="Em branco = sem prazo" />
      </div>
      <p className="eyebrow pt-2">Condições de uso</p>
      <div className="grid gap-4 sm:grid-cols-2">
        <Input label="Pedido mínimo (R$)" inputMode="decimal" value={f.minimumOrderValue} onChange={(e) => set('minimumOrderValue', e.target.value)} hint="Opcional" />
        <Input label="Limite de usos" type="number" min={1} value={f.usageLimit} onChange={(e) => set('usageLimit', e.target.value)} hint="Opcional" />
      </div>
      <Checkbox label="Cupom ativo" checked={f.active} onChange={(v) => set('active', v)} />
      <div className="flex justify-end gap-3 border-t border-line pt-4"><Button variant="ghost" onClick={onClose}>Cancelar</Button><Button type="submit" loading={saving}>Salvar cupom</Button></div>
    </form>
  );
}

function PromotionForm({ promo, products, onClose, onSaved }: { promo: Promotion | null; products: Product[]; onClose: () => void; onSaved: () => void }) {
  const toast = useToast();
  const [f, setF] = useState({ name: '', scope: 'PRODUTO' as PromotionScope, discountType: 'PERCENTUAL' as DiscountType, discountValue: '', startDate: today(), endDate: '', active: true });
  const [selected, setSelected] = useState<Id[]>([]);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);
  useEffect(() => {
    if (promo) { setF({ name: promo.name, scope: promo.scope, discountType: promo.discountType, discountValue: String(promo.discountValue), startDate: promo.startDate, endDate: promo.endDate, active: promo.active }); setSelected(promo.productIds ?? []); }
  }, [promo]);
  const set = (k: keyof typeof f, v: string | boolean) => setF((s) => ({ ...s, [k]: v }));
  const toggle = (id: Id) => setSelected((s) => (s.some((x) => String(x) === String(id)) ? s.filter((x) => String(x) !== String(id)) : [...s, id]));

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    const val = Number(f.discountValue.replace(',', '.'));
    const errs: Record<string, string> = {};
    if (f.name.trim().length < 3) errs.name = 'Dê um nome à promoção.';
    if (!(val > 0) || (f.discountType === 'PERCENTUAL' && val > 100)) errs.discountValue = 'Valor inválido.';
    if (!f.startDate || !f.endDate) errs.endDate = 'Informe o período.';
    else if (f.endDate < f.startDate) errs.endDate = 'Término antes do início.';
    if (f.scope === 'PRODUTO' && !selected.length) errs.products = 'Selecione ao menos um produto.';
    setErrors(errs);
    if (Object.keys(errs).length) return;
    const payload: PromotionPayload = { name: f.name.trim(), scope: f.scope, discountType: f.discountType, discountValue: val, startDate: f.startDate, endDate: f.endDate, active: f.active, productIds: f.scope === 'PRODUTO' ? selected : [] };
    setSaving(true);
    try { promo ? await promotionService.update(promo.id, payload) : await promotionService.create(payload); toast.success('Promoção salva.'); onSaved(); onClose(); }
    catch (err) { toast.error(errorMessage(err)); } finally { setSaving(false); }
  };

  return (
    <form onSubmit={submit} className="space-y-4" noValidate>
      <Input label="Nome da promoção" value={f.name} onChange={(e) => set('name', e.target.value)} error={errors.name} required />
      <div className="grid gap-4 sm:grid-cols-3">
        <Select label="Aplica-se a" value={f.scope} onChange={(e) => set('scope', e.target.value)}><option value="PRODUTO">Produtos</option><option value="PEDIDO">Pedido inteiro</option></Select>
        <Select label="Tipo" value={f.discountType} onChange={(e) => set('discountType', e.target.value)}><option value="PERCENTUAL">Percentual</option><option value="VALOR">Valor fixo</option></Select>
        <Input label="Desconto" inputMode="decimal" value={f.discountValue} onChange={(e) => set('discountValue', e.target.value)} error={errors.discountValue} required />
      </div>
      <div className="grid gap-4 sm:grid-cols-2">
        <Input label="Início" type="date" value={f.startDate} onChange={(e) => set('startDate', e.target.value)} required />
        <Input label="Término" type="date" value={f.endDate} onChange={(e) => set('endDate', e.target.value)} error={errors.endDate} required />
      </div>
      {f.scope === 'PRODUTO' && (
        <div>
          <p className="mb-1.5 text-[13px] font-semibold">Produtos participantes <span className="font-normal text-ink-soft">({selected.length})</span></p>
          <div className="max-h-56 space-y-1 overflow-y-auto rounded-xl border border-line p-2">
            {products.map((p) => (
              <label key={p.id} className="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 text-sm hover:bg-gold-50">
                <input type="checkbox" className="accent-wine-700" checked={selected.some((x) => String(x) === String(p.id))} onChange={() => toggle(p.id)} />
                <span className="flex-1">{p.name}</span><span className="text-xs text-ink-soft">{money(p.price)}</span>
              </label>
            ))}
          </div>
          {errors.products && <p className="mt-1 text-xs font-medium text-wine-700">{errors.products}</p>}
        </div>
      )}
      <Checkbox label="Promoção ativa" checked={f.active} onChange={(v) => set('active', v)} />
      <div className="flex justify-end gap-3 border-t border-line pt-4"><Button variant="ghost" onClick={onClose}>Cancelar</Button><Button type="submit" loading={saving}>Salvar promoção</Button></div>
    </form>
  );
}

export default function CouponsPage() {
  useDocumentTitle('Cupons e promoções');
  const toast = useToast();
  const [tab, setTab] = useState<'coupons' | 'promotions'>('coupons');
  const coupons = useAsync(() => couponService.list(), []);
  const promotions = useAsync(() => promotionService.list(), []);
  const products = useAsync(() => (tab === 'promotions' ? productService.list() : Promise.resolve([] as Product[])), [tab]);
  const [editCoupon, setEditCoupon] = useState<Coupon | null | undefined>(undefined);
  const [editPromo, setEditPromo] = useState<Promotion | null | undefined>(undefined);
  const [toDelete, setToDelete] = useState<{ kind: 'coupon' | 'promo'; id: Id; name: string } | null>(null);
  const [deleting, setDeleting] = useState(false);

  const remove = async () => {
    if (!toDelete) return;
    setDeleting(true);
    try {
      if (toDelete.kind === 'coupon') { await couponService.remove(toDelete.id); coupons.reload(); } else { await promotionService.remove(toDelete.id); promotions.reload(); }
      toast.success('Excluído.'); setToDelete(null);
    } catch (err) { toast.error(errorMessage(err)); } finally { setDeleting(false); }
  };

  const actions = (onEdit: () => void, onDelete: () => void, label: string) => (
    <div className="flex justify-end gap-1">
      <button onClick={onEdit} className="rounded-full p-2 text-ink-soft hover:bg-gold-50 hover:text-gold-dark" aria-label={`Editar ${label}`}><Pencil className="size-4" /></button>
      <button onClick={onDelete} className="rounded-full p-2 text-ink-soft hover:bg-wine-50 hover:text-wine-700" aria-label={`Excluir ${label}`}><Trash2 className="size-4" /></button>
    </div>
  );

  const couponCols: Column<Coupon>[] = [
    { key: 'c', header: 'Cupom', render: (c) => <span className="rounded-lg border border-dashed border-gold bg-gold-50 px-2.5 py-1 font-mono text-sm font-bold tracking-wider text-gold-dark">{c.code}</span> },
    { key: 'd', header: 'Desconto', render: (c) => <b>{discountLabel(c.discountType, c.discountValue)}</b> },
    { key: 'v', header: 'Validade', render: (c) => <span className="text-ink-soft">{c.validUntil ? `até ${date(c.validUntil)}` : 'Sem prazo'}</span> },
    { key: 'cond', header: 'Condições', hideOnMobile: true, render: (c) => <span className="text-xs text-ink-soft">{[c.minimumOrderValue && `mín. ${money(c.minimumOrderValue)}`, c.usageLimit && `${c.timesUsed ?? 0}/${c.usageLimit} usos`].filter(Boolean).join(' · ') || '—'}</span> },
    { key: 's', header: 'Status', render: (c) => !c.active ? <Badge>Inativo</Badge> : isExpired(c.validUntil) ? <Badge tone="danger">Expirado</Badge> : <Badge tone="success" dot>Ativo</Badge> },
    { key: 'a', header: '', align: 'right', render: (c) => actions(() => setEditCoupon(c), () => setToDelete({ kind: 'coupon', id: c.id, name: c.code }), c.code) },
  ];
  const promoCols: Column<Promotion>[] = [
    { key: 'n', header: 'Promoção', render: (p) => <span className="font-semibold">{p.name}</span> },
    { key: 'sc', header: 'Aplica-se a', render: (p) => p.scope === 'PEDIDO' ? <Badge tone="gold">Pedido</Badge> : <Badge tone="info">{p.productIds?.length ?? 0} produto(s)</Badge> },
    { key: 'd', header: 'Desconto', render: (p) => <b>{discountLabel(p.discountType, p.discountValue)}</b> },
    { key: 'per', header: 'Período', hideOnMobile: true, render: (p) => <span className="text-ink-soft">{date(p.startDate)} – {date(p.endDate)}</span> },
    { key: 's', header: 'Status', render: (p) => !p.active ? <Badge>Inativa</Badge> : isExpired(p.endDate) ? <Badge tone="danger">Encerrada</Badge> : p.startDate > today() ? <Badge tone="info">Agendada</Badge> : <Badge tone="success" dot>Vigente</Badge> },
    { key: 'a', header: '', align: 'right', render: (p) => actions(() => setEditPromo(p), () => setToDelete({ kind: 'promo', id: p.id, name: p.name }), p.name) },
  ];

  return (
    <>
      <PageHeader eyebrow="Vendas" title="Cupons e promoções" description="Crie descontos para atrair e fidelizar clientes."
        actions={tab === 'coupons' ? <Button onClick={() => setEditCoupon(null)}><Plus className="size-4" /> Novo cupom</Button> : <Button onClick={() => setEditPromo(null)}><Plus className="size-4" /> Nova promoção</Button>} />
      <div className="mb-4"><Tabs value={tab} onChange={setTab} tabs={[{ value: 'coupons', label: 'Cupons', count: coupons.data?.length }, { value: 'promotions', label: 'Promoções', count: promotions.data?.length }]} /></div>
      <Panel>
        {tab === 'coupons' ? (
          <AsyncContent {...coupons} onRetry={coupons.reload} empty={<EmptyState icon={<TicketPercent className="size-6" />} title="Nenhum cupom criado" action={<Button onClick={() => setEditCoupon(null)}><Plus className="size-4" /> Criar cupom</Button>} />}>
            {(rows) => <DataTable columns={couponCols} rows={rows} rowKey={(c) => String(c.id)} />}
          </AsyncContent>
        ) : (
          <AsyncContent {...promotions} onRetry={promotions.reload} empty={<EmptyState icon={<Sparkles className="size-6" />} title="Nenhuma promoção criada" action={<Button onClick={() => setEditPromo(null)}><Plus className="size-4" /> Criar promoção</Button>} />}>
            {(rows) => <DataTable columns={promoCols} rows={rows} rowKey={(p) => String(p.id)} />}
          </AsyncContent>
        )}
      </Panel>

      <Modal open={editCoupon !== undefined} onClose={() => setEditCoupon(undefined)} title={editCoupon ? 'Editar cupom' : 'Novo cupom'}>
        {editCoupon !== undefined && <CouponForm coupon={editCoupon} onClose={() => setEditCoupon(undefined)} onSaved={coupons.reload} />}
      </Modal>
      <Modal open={editPromo !== undefined} onClose={() => setEditPromo(undefined)} title={editPromo ? 'Editar promoção' : 'Nova promoção'} size="lg">
        {editPromo !== undefined && <PromotionForm promo={editPromo} products={products.data ?? []} onClose={() => setEditPromo(undefined)} onSaved={promotions.reload} />}
      </Modal>
      <ConfirmDialog open={!!toDelete} title="Confirmar exclusão" message={`Excluir "${toDelete?.name}"? Esta ação não pode ser desfeita.`} confirmLabel="Excluir" loading={deleting} onConfirm={remove} onClose={() => setToDelete(null)} />
    </>
  );
}
