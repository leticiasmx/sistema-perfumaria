import { useState, type FormEvent } from 'react';
import { Link, Navigate, useLocation, useNavigate } from 'react-router-dom';
import { Eye, EyeOff, Lock, Mail, AlertCircle } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { useDocumentTitle } from '@/hooks/useDocumentTitle';
import { Button, Input, Logo, MockBanner } from '@/components/ui';
import { errorMessage } from '@/utils/errors';
import { env } from '@/config/env';

export default function LoginPage() {
  useDocumentTitle('Entrar');
  const { login, isAuthenticated } = useAuth();
  const navigate = useNavigate();
  const from = (useLocation().state as { from?: string } | null)?.from ?? '/admin';
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [show, setShow] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (isAuthenticated) return <Navigate to={from} replace />;

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (!email || !password) return setError('Preencha e-mail e senha.');
    setLoading(true);
    setError(null);
    try {
      await login({ email: email.trim(), password });
      navigate(from, { replace: true });
    } catch (err) {
      setError(errorMessage(err, 'Não foi possível entrar.'));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen">
      <MockBanner />
      <div className="grid min-h-screen lg:grid-cols-2">
        <div className="relative hidden overflow-hidden bg-wine-900 lg:flex lg:flex-col lg:justify-between lg:p-14">
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_20%_10%,rgba(212,175,55,0.22),transparent_55%),radial-gradient(ellipse_at_90%_100%,rgba(192,57,69,0.55),transparent_60%)]" />
          <svg className="absolute -bottom-40 -right-40 size-[520px] text-gold/20" viewBox="0 0 200 200" fill="none" aria-hidden>
            <circle cx="100" cy="100" r="99" stroke="currentColor" /><circle cx="100" cy="100" r="70" stroke="currentColor" strokeDasharray="1 4" />
          </svg>
          <Logo light className="relative" />
          <div className="relative">
            <p className="eyebrow !text-gold-light">Área da vendedora</p>
            <h1 className="mt-3 text-6xl font-semibold leading-[0.95] text-white">Seu negócio,<br /><em className="font-medium text-gold-light">na palma da mão.</em></h1>
            <p className="mt-5 max-w-sm text-white/70">Pedidos, estoque, parcelas e cobranças em um só lugar.</p>
          </div>
          <p className="relative text-xs text-white/40">© {new Date().getFullYear()} {env.storeName}</p>
        </div>

        <div className="flex items-center justify-center px-6 py-12">
          <form onSubmit={submit} className="w-full max-w-sm animate-fade-up space-y-5">
            <div className="lg:hidden"><Logo /></div>
            <div>
              <h2 className="text-4xl font-semibold">Bem-vinda de volta</h2>
              <p className="mt-1 text-sm text-ink-soft">Entre com seus dados de acesso.</p>
            </div>
            {error && (
              <div role="alert" className="flex items-start gap-2 rounded-xl bg-wine-50 px-4 py-3 text-sm text-wine-900 ring-1 ring-wine-500/25">
                <AlertCircle className="mt-0.5 size-4 shrink-0" /> {error}
              </div>
            )}
            <Input label="E-mail ou usuário" autoComplete="username" value={email} onChange={(e) => setEmail(e.target.value)} icon={<Mail className="size-4" />} required autoFocus />
            <div className="relative">
              <Input label="Senha" type={show ? 'text' : 'password'} autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)} icon={<Lock className="size-4" />} className="pr-11" required />
              <button type="button" onClick={() => setShow((s) => !s)} className="absolute bottom-0 right-1 grid size-11 place-items-center text-ink-soft hover:text-wine-700" aria-label={show ? 'Ocultar senha' : 'Mostrar senha'}>
                {show ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
              </button>
            </div>
            <Button type="submit" size="lg" className="w-full" loading={loading}>Entrar</Button>
            {env.useMocks && <p className="text-center text-xs text-ink-soft">Demonstração: qualquer e-mail e a senha <b>demo123</b>.</p>}
            <Link to="/" className="block text-center text-sm font-semibold text-wine-700 hover:underline">Ir para a loja</Link>
          </form>
        </div>
      </div>
    </div>
  );
}
