import { useState } from 'react';
import { Link } from 'react-router-dom';
import { AlertTriangle, CalendarClock, Cake, CircleDollarSign, Clock, HandCoins, PackageX, ShoppingCart, TrendingUp, MessageCircle } from 'lucide-react';
import { dashboardService } from '@/services/dashboardService';
import { useAsync } from '@/hooks/useAsync';
import { useDocumentTitle } from '@/hooks/useDocumentTitle';
import { useAuth } from '@/contexts/AuthContext';
import { Badge, EmptyState, ErrorState, PageHeader, Panel, PeriodFilter, StatCard } from '@/components/ui';
import { IncomeExpenseChart, MonthlyBarChart, SalesAreaChart, TopProductsChart } from '@/components/charts/Charts';
import { date, daysUntil, money, periodPreset, dayMonth, phone } from '@/utils/format';
import { ORDER_STATUS } from '@/utils/status';
import { birthdayMessage, waLink } from '@/utils/whatsapp';
import type { Period } from '@/interfaces';

const greeting = () => { const h = new Date().getHours(); return h < 12 ? 'Bom dia' : h < 18 ? 'Boa tarde' : 'Boa noite'; };

export default function DashboardPage() {
  useDocumentTitle('Dashboard');
  const { user } = useAuth();
  const [period, setPeriod] = useState<Period>(periodPreset('month'));
  const { data, loading, error, reload } = useAsync(() => dashboardService.get(period), [period.from, period.to]);

  const empty = <p className="px-5 py-10 text-center text-sm text-ink-soft">Sem dados no período.</p>;

  return (
    <>
      <PageHeader eyebrow={new Date().toLocaleDateString('pt-BR', { weekday: 'long', day: 'numeric', month: 'long' })}
        title={`${greeting()}, ${user?.name?.split(' ')[0] ?? 'vendedora'}`}
        description="Resumo do seu negócio no período selecionado."
        actions={<PeriodFilter value={period} onChange={setPeriod} />} />

      {error ? <ErrorState message={error} onRetry={reload} /> : (
        <div className="space-y-6">
          <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
            <StatCard label="Faturamento" value={money(data?.monthRevenue)} icon={CircleDollarSign} loading={loading && !data} />
            <StatCard label="Lucro" value={money(data?.monthProfit)} icon={TrendingUp} loading={loading && !data} />
            <StatCard label="Total de pedidos" value={data?.totalOrders ?? 0} icon={ShoppingCart} loading={loading && !data} />
            <StatCard label="Pedidos pendentes" value={data?.pendingOrders ?? 0} icon={Clock} loading={loading && !data} tone={data?.pendingOrders ? 'gold' : 'default'} />
          </div>
          <div className="grid grid-cols-2 gap-4 lg:grid-cols-3">
            <StatCard label="Valores a receber" value={money(data?.receivable)} icon={HandCoins} loading={loading && !data} />
            <StatCard label="Parcelas em atraso" value={data?.overdueInstallments ?? 0} icon={AlertTriangle} loading={loading && !data} tone={data?.overdueInstallments ? 'alert' : 'default'} />
            <StatCard label="Estoque baixo" value={data?.lowStockProducts ?? 0} icon={PackageX} loading={loading && !data} tone={data?.lowStockProducts ? 'alert' : 'default'} hint="produtos no mínimo ou abaixo" />
          </div>

          {data && (
            <>
              <div className="grid gap-6 xl:grid-cols-5">
                <Panel title="Vendas por período" className="xl:col-span-3"><div className="p-4">{data.salesByPeriod.length ? <SalesAreaChart data={data.salesByPeriod} /> : empty}</div></Panel>
                <Panel title="Faturamento mensal" className="xl:col-span-2"><div className="p-4">{data.monthlyRevenue.length ? <MonthlyBarChart data={data.monthlyRevenue} dataKey="revenue" name="Faturamento" /> : empty}</div></Panel>
              </div>
              <div className="grid gap-6 xl:grid-cols-2">
                <Panel title="Receitas x despesas"><div className="p-4">{data.incomeVsExpenses.length ? <IncomeExpenseChart data={data.incomeVsExpenses} /> : empty}</div></Panel>
                <Panel title="Produtos mais vendidos"><div className="p-4">{data.topProducts.length ? <TopProductsChart data={data.topProducts} /> : empty}</div></Panel>
              </div>

              <div className="grid gap-6 xl:grid-cols-3">
                <Panel title="Últimos pedidos" className="xl:col-span-2" action={<Link to="/admin/pedidos" className="text-sm font-semibold text-wine-700 hover:underline">Ver todos</Link>}>
                  {data.latestOrders.length ? (
                    <ul className="divide-y divide-line">
                      {data.latestOrders.map((o) => (
                        <li key={o.id}>
                          <Link to={`/admin/pedidos?id=${o.id}`} className="flex items-center gap-4 px-5 py-3.5 transition hover:bg-gold-50/50">
                            <div className="min-w-0 flex-1"><p className="truncate font-semibold">{o.customer.name}</p><p className="text-xs text-ink-soft">{o.number ?? `#${o.id}`} · {date(o.createdAt)}</p></div>
                            <Badge tone={ORDER_STATUS[o.status]?.tone}>{ORDER_STATUS[o.status]?.label ?? o.status}</Badge>
                            <span className="w-24 text-right font-semibold tabular-nums">{money(o.total)}</span>
                          </Link>
                        </li>
                      ))}
                    </ul>
                  ) : <EmptyState title="Nenhum pedido ainda" />}
                </Panel>

                <Panel title={<span className="flex items-center gap-2 text-xl font-semibold"><CalendarClock className="size-5 text-gold-dark" /> Próximas parcelas</span>}
                  action={<Link to="/admin/parcelas" className="text-sm font-semibold text-wine-700 hover:underline">Ver</Link>}>
                  {data.upcomingInstallments.length ? (
                    <ul className="divide-y divide-line">
                      {data.upcomingInstallments.map((i) => {
                        const d = daysUntil(i.dueDate);
                        return (
                          <li key={i.id} className="flex items-center gap-3 px-5 py-3">
                            <div className="min-w-0 flex-1"><p className="truncate text-sm font-semibold">{i.customer.name}</p><p className="text-xs text-ink-soft">Parcela {i.number}/{i.totalInstallments} · {dayMonth(i.dueDate)}</p></div>
                            <div className="text-right"><p className="text-sm font-semibold tabular-nums">{money(i.amount)}</p>
                              <p className={`text-[11px] font-semibold ${d < 0 ? 'text-wine-700' : d <= 3 ? 'text-amber-700' : 'text-ink-soft'}`}>{d < 0 ? `${-d}d em atraso` : d === 0 ? 'vence hoje' : `em ${d}d`}</p></div>
                          </li>
                        );
                      })}
                    </ul>
                  ) : <p className="px-5 py-10 text-center text-sm text-ink-soft">Nenhuma parcela a vencer.</p>}
                </Panel>
              </div>

              <div className="grid gap-6 xl:grid-cols-2">
                <Panel title={<span className="flex items-center gap-2 text-xl font-semibold"><Cake className="size-5 text-gold-dark" /> Aniversariantes do mês</span>}>
                  {data.birthdayCustomers.length ? (
                    <ul className="divide-y divide-line">
                      {data.birthdayCustomers.map((c) => (
                        <li key={c.id} className="flex items-center gap-3 px-5 py-3">
                          <span className="grid size-10 place-items-center rounded-full bg-gold-50 font-display text-lg font-semibold text-gold-dark ring-1 ring-gold-light">{c.name.charAt(0)}</span>
                          <div className="flex-1"><p className="text-sm font-semibold">{c.name}</p><p className="text-xs text-ink-soft">{dayMonth(c.birthDate)} · {phone(c.phone)}</p></div>
                          <a href={waLink(c.phone, birthdayMessage(c))} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1.5 rounded-full bg-[#1f9d55] px-3 py-1.5 text-xs font-semibold text-white hover:bg-[#178246]">
                            <MessageCircle className="size-3.5" /> Parabenizar
                          </a>
                        </li>
                      ))}
                    </ul>
                  ) : <p className="px-5 py-10 text-center text-sm text-ink-soft">Nenhuma aniversariante neste mês.</p>}
                </Panel>
                <Panel title={<span className="flex items-center gap-2 text-xl font-semibold"><PackageX className="size-5 text-wine-700" /> Alertas de estoque</span>}
                  action={<Link to="/admin/estoque" className="text-sm font-semibold text-wine-700 hover:underline">Estoque</Link>}>
                  {data.stockAlerts.length ? (
                    <ul className="divide-y divide-line">
                      {data.stockAlerts.map((p) => (
                        <li key={p.id} className="flex items-center gap-3 px-5 py-3">
                          <div className="min-w-0 flex-1"><p className="truncate text-sm font-semibold">{p.name}</p><p className="text-xs text-ink-soft">{p.brand?.name} · mínimo {p.minimumStock}</p></div>
                          <Badge tone={p.stockQuantity <= 0 ? 'danger' : 'warning'} dot>{p.stockQuantity <= 0 ? 'Esgotado' : `${p.stockQuantity} un.`}</Badge>
                        </li>
                      ))}
                    </ul>
                  ) : <p className="px-5 py-10 text-center text-sm text-ink-soft">Estoque em dia. ✨</p>}
                </Panel>
              </div>
            </>
          )}
        </div>
      )}
    </>
  );
}
