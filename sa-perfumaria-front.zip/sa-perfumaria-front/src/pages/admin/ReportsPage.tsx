import { useState } from 'react';
import { BarChart3, Boxes, CalendarClock, Download, FileSpreadsheet, Printer, ShoppingBag, Users, Wallet } from 'lucide-react';
import { reportService } from '@/services/reportService';
import { useAsync } from '@/hooks/useAsync';
import { useDocumentTitle } from '@/hooks/useDocumentTitle';
import { useToast } from '@/contexts/ToastContext';
import { AsyncContent, Button, EmptyState, PageHeader, Panel, PeriodFilter } from '@/components/ui';
import { date, money, periodPreset } from '@/utils/format';
import { errorMessage } from '@/utils/errors';
import { cn } from '@/utils/cn';
import type { Period, ReportResult, ReportType } from '@/interfaces';

const REPORTS: { type: ReportType; label: string; desc: string; Icon: typeof BarChart3 }[] = [
  { type: 'sales', label: 'Vendas', desc: 'Pedidos do período', Icon: ShoppingBag },
  { type: 'financial', label: 'Financeiro', desc: 'Receitas, despesas e resultado', Icon: Wallet },
  { type: 'top-products', label: 'Mais vendidos', desc: 'Ranking de produtos', Icon: BarChart3 },
  { type: 'stock', label: 'Estoque', desc: 'Posição e valor em estoque', Icon: Boxes },
  { type: 'customers', label: 'Clientes', desc: 'Compras por cliente', Icon: Users },
  { type: 'installments', label: 'Parcelas', desc: 'Situação das parcelas', Icon: CalendarClock },
];

function cell(value: unknown, type?: string) {
  if (value == null || value === '') return '—';
  if (type === 'money') return money(Number(value));
  if (type === 'date') return date(String(value));
  if (type === 'number') return Number(value).toLocaleString('pt-BR');
  return String(value);
}

function ReportTable({ report }: { report: ReportResult }) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full min-w-[600px] text-sm">
        <thead><tr className="border-b border-line">{report.columns.map((c) => (
          <th key={c.key} className={cn('px-4 py-3 text-[11px] font-semibold uppercase tracking-[0.14em] text-ink-soft', c.type === 'money' || c.type === 'number' ? 'text-right' : 'text-left')}>{c.label}</th>
        ))}</tr></thead>
        <tbody>{report.rows.map((r, i) => (
          <tr key={i} className="border-b border-line/70 last:border-0">{report.columns.map((c) => (
            <td key={c.key} className={cn('px-4 py-3', c.type === 'money' || c.type === 'number' ? 'text-right tabular-nums' : '')}>{cell(r[c.key], c.type)}</td>
          ))}</tr>
        ))}</tbody>
        {report.totals && (
          <tfoot><tr className="border-t-2 border-gold-light bg-gold-50/50 font-semibold">{report.columns.map((c, i) => (
            <td key={c.key} className={cn('px-4 py-3', c.type === 'money' || c.type === 'number' ? 'text-right tabular-nums' : '')}>
              {i === 0 ? 'Total' : report.totals![c.key] != null ? cell(report.totals![c.key], c.type) : ''}
            </td>
          ))}</tr></tfoot>
        )}
      </table>
    </div>
  );
}

export default function ReportsPage() {
  useDocumentTitle('Relatórios');
  const toast = useToast();
  const [type, setType] = useState<ReportType>('sales');
  const [period, setPeriod] = useState<Period>(periodPreset('month'));
  const [exporting, setExporting] = useState(false);
  const report = useAsync(() => reportService.get(type, period), [type, period.from, period.to]);
  const meta = REPORTS.find((r) => r.type === type)!;

  const exportCsv = async () => {
    setExporting(true);
    try {
      const blob = await reportService.export(type, 'csv', period);
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `relatorio-${type}-${period.from ?? ''}_${period.to ?? ''}.csv`;
      a.click();
      URL.revokeObjectURL(url);
    } catch (err) {
      toast.error(`Exportação indisponível: ${errorMessage(err)}`);
    } finally { setExporting(false); }
  };

  return (
    <>
      <PageHeader eyebrow="Gestão" title="Relatórios" description="Consulte e exporte os dados do seu negócio." actions={<PeriodFilter value={period} onChange={setPeriod} />} />
      <div className="mb-6 grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-6 print:hidden">
        {REPORTS.map(({ type: t, label, desc, Icon }) => (
          <button key={t} onClick={() => setType(t)}
            className={cn('card flex flex-col items-start gap-2 p-4 text-left transition hover:-translate-y-0.5 hover:shadow-lift', type === t && 'border-wine-700 ring-2 ring-wine-700/15')}>
            <Icon className={cn('size-5', type === t ? 'text-wine-700' : 'text-gold-dark')} />
            <span className="font-semibold">{label}</span>
            <span className="text-xs text-ink-soft">{desc}</span>
          </button>
        ))}
      </div>
      <Panel title={`Relatório de ${meta.label.toLowerCase()}`}
        action={<div className="flex gap-2 print:hidden">
          <Button size="sm" variant="ghost" onClick={() => window.print()} disabled={!report.data}><Printer className="size-4" /> Imprimir</Button>
          <Button size="sm" variant="outline" onClick={exportCsv} loading={exporting} disabled={!report.data}><Download className="size-4" /> Exportar CSV</Button>
        </div>}>
        <AsyncContent {...report} onRetry={report.reload} isEmpty={(d) => !d.rows.length}
          empty={<EmptyState icon={<FileSpreadsheet className="size-6" />} title="Sem dados no período" message="Escolha outro período ou outro relatório." />}>
          {(d) => <ReportTable report={d} />}
        </AsyncContent>
      </Panel>
    </>
  );
}
