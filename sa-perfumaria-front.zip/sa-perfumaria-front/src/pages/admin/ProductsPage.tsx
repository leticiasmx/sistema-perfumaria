import { useEffect, useMemo, useState, type FormEvent } from 'react';
import { ImagePlus, Pencil, Plus, Search, Trash2 } from 'lucide-react';
import { productService } from '@/services/productService';
import { brandService, categoryService } from '@/services/brandService';
import { useAsync } from '@/hooks/useAsync';
import { useDebounce } from '@/hooks/useDebounce';
import { useDocumentTitle } from '@/hooks/useDocumentTitle';
import { useToast } from '@/contexts/ToastContext';
import {
  AsyncContent, Badge, Button, Checkbox, ConfirmDialog, DataTable, EmptyState, Input, Modal, PageHeader, Panel, ProductImage, Select, Textarea, type Column,
} from '@/components/ui';
import { money } from '@/utils/format';
import { errorMessage } from '@/utils/errors';
import type { Brand, Category, Product, ProductPayload } from '@/interfaces';

type FormState = {
  name: string; description: string; price: string; promotionalPrice: string; costPrice: string;
  stockQuantity: string; minimumStock: string; brandId: string; categoryId: string; featured: boolean; active: boolean;
};
const blank: FormState = { name: '', description: '', price: '', promotionalPrice: '', costPrice: '', stockQuantity: '0', minimumStock: '3', brandId: '', categoryId: '', featured: false, active: true };
const num = (v: string) => Number(v.replace(',', '.'));

function ProductForm({ product, brands, categories, onClose, onSaved }: {
  product: Product | null; brands: Brand[]; categories: Category[]; onClose: () => void; onSaved: () => void;
}) {
  const toast = useToast();
  const [f, setF] = useState<FormState>(blank);
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [errors, setErrors] = useState<Partial<Record<keyof FormState, string>>>({});
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    setF(product ? {
      name: product.name, description: product.description ?? '', price: String(product.price),
      promotionalPrice: product.promotionalPrice != null ? String(product.promotionalPrice) : '',
      costPrice: product.costPrice != null ? String(product.costPrice) : '',
      stockQuantity: String(product.stockQuantity), minimumStock: String(product.minimumStock),
      brandId: product.brand ? String(product.brand.id) : '', categoryId: product.category ? String(product.category.id) : '',
      featured: !!product.featured, active: product.active !== false,
    } : blank);
    setPreview(product?.imageUrl ?? null);
    setFile(null);
    setErrors({});
  }, [product]);

  const set = <K extends keyof FormState>(k: K, v: FormState[K]) => setF((s) => ({ ...s, [k]: v }));

  const validate = () => {
    const e: typeof errors = {};
    if (f.name.trim().length < 3) e.name = 'Informe o nome do produto.';
    if (!(num(f.price) > 0)) e.price = 'Preço deve ser maior que zero.';
    if (f.promotionalPrice && !(num(f.promotionalPrice) > 0 && num(f.promotionalPrice) < num(f.price))) e.promotionalPrice = 'Deve ser menor que o preço normal.';
    if (f.costPrice && !(num(f.costPrice) >= 0)) e.costPrice = 'Valor inválido.';
    if (!(Number(f.stockQuantity) >= 0) || !Number.isInteger(Number(f.stockQuantity))) e.stockQuantity = 'Quantidade inválida.';
    if (!(Number(f.minimumStock) >= 0) || !Number.isInteger(Number(f.minimumStock))) e.minimumStock = 'Quantidade inválida.';
    if (!f.brandId) e.brandId = 'Selecione a marca.';
    if (!f.categoryId) e.categoryId = 'Selecione a categoria.';
    setErrors(e);
    return !Object.keys(e).length;
  };

  const submit = async (ev: FormEvent) => {
    ev.preventDefault();
    if (!validate()) return;
    const payload: ProductPayload = {
      name: f.name.trim(), description: f.description.trim() || undefined, price: num(f.price),
      promotionalPrice: f.promotionalPrice ? num(f.promotionalPrice) : null, costPrice: f.costPrice ? num(f.costPrice) : null,
      stockQuantity: Number(f.stockQuantity), minimumStock: Number(f.minimumStock), brandId: f.brandId, categoryId: f.categoryId,
      featured: f.featured, active: f.active,
    };
    setSaving(true);
    try {
      const saved = product ? await productService.update(product.id, payload) : await productService.create(payload);
      if (file) {
        try { await productService.uploadImage(saved.id, file); }
        catch (err) { toast.error(`Produto salvo, mas a imagem falhou: ${errorMessage(err)}`); }
      }
      toast.success(product ? 'Produto atualizado.' : 'Produto cadastrado.');
      onSaved();
      onClose();
    } catch (err) {
      toast.error(errorMessage(err));
    } finally {
      setSaving(false);
    }
  };

  return (
    <form onSubmit={submit} className="grid gap-6 md:grid-cols-[200px_1fr]" id="product-form" noValidate>
      <div>
        <label className="group relative block aspect-square cursor-pointer overflow-hidden rounded-2xl border-2 border-dashed border-gold-light bg-ivory transition hover:border-gold">
          {preview ? <img src={preview} alt="" className="h-full w-full object-cover" /> : <ProductImage alt="Sem imagem" />}
          <span className="absolute inset-x-0 bottom-0 flex items-center justify-center gap-1.5 bg-ink/60 py-2 text-xs font-semibold text-white opacity-90 group-hover:opacity-100">
            <ImagePlus className="size-4" /> {preview ? 'Trocar imagem' : 'Adicionar imagem'}
          </span>
          <input type="file" accept="image/*" className="sr-only" onChange={(e) => {
            const fl = e.target.files?.[0];
            if (!fl) return;
            if (fl.size > 5 * 1024 * 1024) return toast.error('Imagem acima de 5 MB.');
            setFile(fl); setPreview(URL.createObjectURL(fl));
          }} />
        </label>
        <p className="mt-2 text-center text-[11px] text-ink-soft">JPG ou PNG, até 5 MB, de preferência quadrada.</p>
      </div>
      <div className="space-y-4">
        <Input label="Nome do produto" value={f.name} onChange={(e) => set('name', e.target.value)} error={errors.name} required />
        <div className="grid gap-4 sm:grid-cols-2">
          <Select label="Marca" value={f.brandId} onChange={(e) => set('brandId', e.target.value)} error={errors.brandId} required>
            <option value="">Selecione…</option>{brands.map((b) => <option key={b.id} value={b.id}>{b.name}</option>)}
          </Select>
          <Select label="Categoria" value={f.categoryId} onChange={(e) => set('categoryId', e.target.value)} error={errors.categoryId} required>
            <option value="">Selecione…</option>{categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
          </Select>
        </div>
        <Textarea label="Descrição" value={f.description} onChange={(e) => set('description', e.target.value)} rows={3} />
        <div className="grid gap-4 sm:grid-cols-3">
          <Input label="Preço de venda (R$)" inputMode="decimal" value={f.price} onChange={(e) => set('price', e.target.value)} error={errors.price} required />
          <Input label="Preço promocional" inputMode="decimal" value={f.promotionalPrice} onChange={(e) => set('promotionalPrice', e.target.value)} error={errors.promotionalPrice} hint="Opcional" />
          <Input label="Custo (R$)" inputMode="decimal" value={f.costPrice} onChange={(e) => set('costPrice', e.target.value)} error={errors.costPrice} hint="Usado no cálculo de lucro" />
        </div>
        <div className="grid gap-4 sm:grid-cols-2">
          <Input label="Quantidade em estoque" type="number" min={0} value={f.stockQuantity} onChange={(e) => set('stockQuantity', e.target.value)} error={errors.stockQuantity} disabled={!!product}
            hint={product ? 'Para alterar, registre uma entrada em Estoque.' : undefined} />
          <Input label="Estoque mínimo" type="number" min={0} value={f.minimumStock} onChange={(e) => set('minimumStock', e.target.value)} error={errors.minimumStock} />
        </div>
        <div className="flex flex-wrap gap-6 pt-1">
          <Checkbox label="Destacar na loja" checked={f.featured} onChange={(v) => set('featured', v)} />
          <Checkbox label="Visível na loja" checked={f.active} onChange={(v) => set('active', v)} />
        </div>
        <div className="flex justify-end gap-3 border-t border-line pt-4">
          <Button variant="ghost" onClick={onClose}>Cancelar</Button>
          <Button type="submit" loading={saving}>{product ? 'Salvar alterações' : 'Cadastrar produto'}</Button>
        </div>
      </div>
    </form>
  );
}

export default function ProductsPage() {
  useDocumentTitle('Produtos');
  const toast = useToast();
  const [search, setSearch] = useState('');
  const [brandId, setBrandId] = useState('');
  const [categoryId, setCategoryId] = useState('');
  const q = useDebounce(search);
  const products = useAsync(() => productService.list({ name: q || undefined, brandId: brandId || undefined, categoryId: categoryId || undefined }), [q, brandId, categoryId]);
  const brands = useAsync(() => brandService.list(), []);
  const categories = useAsync(() => categoryService.list(), []);
  const [editing, setEditing] = useState<Product | null | undefined>(undefined);
  const [toDelete, setToDelete] = useState<Product | null>(null);
  const [deleting, setDeleting] = useState(false);

  const remove = async () => {
    if (!toDelete) return;
    setDeleting(true);
    try {
      await productService.remove(toDelete.id);
      toast.success('Produto excluído.');
      setToDelete(null);
      products.reload();
    } catch (err) { toast.error(errorMessage(err)); } finally { setDeleting(false); }
  };

  const columns = useMemo<Column<Product>[]>(() => [
    { key: 'p', header: 'Produto', render: (p) => (
      <div className="flex items-center gap-3">
        <span className="size-12 shrink-0 overflow-hidden rounded-lg bg-ivory ring-1 ring-line"><ProductImage src={p.imageUrl} alt={p.name} /></span>
        <div className="min-w-0"><p className="truncate font-semibold">{p.name}</p><p className="text-xs text-ink-soft">{p.brand?.name} · {p.category?.name}</p></div>
      </div>) },
    { key: 'price', header: 'Preço', align: 'right', render: (p) => (
      <div>{p.promotionalPrice != null && p.promotionalPrice < p.price ? <><p className="text-xs text-ink-soft line-through">{money(p.price)}</p><p className="font-semibold text-wine-700">{money(p.promotionalPrice)}</p></> : <p className="font-semibold">{money(p.price)}</p>}</div>) },
    { key: 'stock', header: 'Estoque', align: 'center', render: (p) => (
      <Badge tone={p.stockQuantity <= 0 ? 'danger' : p.stockQuantity <= p.minimumStock ? 'warning' : 'success'} dot>{p.stockQuantity} un.</Badge>) },
    { key: 'status', header: 'Loja', hideOnMobile: true, render: (p) => (
      <div className="flex flex-wrap gap-1">{p.active === false ? <Badge>Oculto</Badge> : <Badge tone="success">Visível</Badge>}{p.featured && <Badge tone="gold">Destaque</Badge>}</div>) },
    { key: 'a', header: '', align: 'right', render: (p) => (
      <div className="flex justify-end gap-1">
        <button onClick={() => setEditing(p)} className="rounded-full p-2 text-ink-soft hover:bg-gold-50 hover:text-gold-dark" aria-label={`Editar ${p.name}`}><Pencil className="size-4" /></button>
        <button onClick={() => setToDelete(p)} className="rounded-full p-2 text-ink-soft hover:bg-wine-50 hover:text-wine-700" aria-label={`Excluir ${p.name}`}><Trash2 className="size-4" /></button>
      </div>) },
  ], []);

  return (
    <>
      <PageHeader eyebrow="Catálogo" title="Produtos" description="Cadastre, edite e organize os produtos da loja."
        actions={<Button onClick={() => setEditing(null)}><Plus className="size-4" /> Novo produto</Button>} />
      <Panel>
        <div className="grid gap-3 border-b border-line p-4 sm:grid-cols-[1fr_200px_200px]">
          <Input placeholder="Buscar por nome" value={search} onChange={(e) => setSearch(e.target.value)} icon={<Search className="size-4" />} aria-label="Buscar produtos" />
          <Select value={brandId} onChange={(e) => setBrandId(e.target.value)} aria-label="Filtrar por marca"><option value="">Todas as marcas</option>{brands.data?.map((b) => <option key={b.id} value={b.id}>{b.name}</option>)}</Select>
          <Select value={categoryId} onChange={(e) => setCategoryId(e.target.value)} aria-label="Filtrar por categoria"><option value="">Todas as categorias</option>{categories.data?.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</Select>
        </div>
        <AsyncContent {...products} onRetry={products.reload}
          empty={<EmptyState title="Nenhum produto encontrado" message="Cadastre o primeiro produto ou ajuste os filtros." action={<Button onClick={() => setEditing(null)}><Plus className="size-4" /> Novo produto</Button>} />}>
          {(rows) => <DataTable columns={columns} rows={rows} rowKey={(p) => String(p.id)} />}
        </AsyncContent>
      </Panel>

      <Modal open={editing !== undefined} onClose={() => setEditing(undefined)} title={editing ? 'Editar produto' : 'Novo produto'} size="lg">
        <ProductForm product={editing ?? null} brands={brands.data ?? []} categories={categories.data ?? []} onClose={() => setEditing(undefined)} onSaved={products.reload} />
      </Modal>
      <ConfirmDialog open={!!toDelete} title="Excluir produto" message={`Tem certeza que deseja excluir "${toDelete?.name}"? Esta ação não pode ser desfeita.`}
        confirmLabel="Excluir" loading={deleting} onConfirm={remove} onClose={() => setToDelete(null)} />
    </>
  );
}
