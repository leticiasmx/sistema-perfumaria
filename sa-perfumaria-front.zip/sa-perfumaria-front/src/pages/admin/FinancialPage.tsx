import { useState, type FormEvent } from 'react';
import { ArrowDownCircle, ArrowUpCircle, CircleDollarSign, HandCoins, Plus, TrendingUp, Wallet, CheckCircle2 } from 'lucide-react';
import { financialService } from '@/services/financialService';
import { useAsync } from '@/hooks/useAsync';
import { useDocumentTitle } from '@/hooks/useDocumentTitle';
import { useToast } from '@/contexts/ToastContext';
import {
  AsyncContent, Badge, Button, Checkbox, DataTable, EmptyState, ErrorState, Input, Modal, PageHeader, Panel, PeriodFilter, Select, StatCard, Tabs, type Column,
} from '@/components/ui';
import { IncomeExpenseChart } from '@/components/charts/Charts';
import { date, money, periodPreset, today } from '@/utils/format';
import { errorMessage } from '@/utils/errors';
import type { Expense, ExpenseType, Period, Revenue } from '@/interfaces';

type Tab = 'revenues' | 'expenses';
type Kind = 'revenue' | 'expense' | 'purchase';

function EntryForm({ kind, onClose, onSaved }: { kind: Kind; onClose: () => void; onSaved: () => void }) {
  const toast = useToast();
  const [description, setDescription] = useState(kind === 'purchase' ? 'Compra de mercadorias' : '');
  const [amount, setAmount] = useState('');
  const [when, setWhen] = useState(today());
  const [category, setCategory] = useState('');
  const [received, setReceived] = useState(true);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    const value = Number(amount.replace(',', '.'));
    const errs: Record<string, string> = {};
    if (description.trim().length < 3) errs.description = 'Descreva o lançamento.';
    if (!(value > 0)) errs.amount = 'Informe um valor maior que zero.';
    if (!when) errs.when = 'Informe a data.';
    setErrors(errs);
    if (Object.keys(errs).length) return;
    setSaving(true);
    try {
      if (kind === 'revenue') await financialService.createRevenue({ description: description.trim(), amount: value, date: when, received });
      else await financialService.createExpense({ description: description.trim(), amount: value, date: when, type: (kind === 'purchase' ? 'COMPRA_MERCADORIA' : 'DESPESA') as ExpenseType, category: category || undefined });
      toast.success('Lançamento registrado.');
      onSaved();
      onClose();
    } catch (err) { toast.error(errorMessage(err)); } finally { setSaving(false); }
  };

  return (
    <form onSubmit={submit} className="space-y-4" noValidate>
      <Input label="Descrição" value={description} onChange={(e) => setDescription(e.target.value)} error={errors.description} required />
      <div className="grid gap-4 sm:grid-cols-2">
        <Input label="Valor (R$)" inputMode="decimal" value={amount} onChange={(e) => setAmount(e.target.value)} error={errors.amount} required />
        <Input label="Data" type="date" value={when} onChange={(e) => setWhen(e.target.value)} error={errors.when} required />
      </div>
      {kind === 'expense' && (
        <Select label="Categoria" value={category} onChange={(e) => setCategory(e.target.value)}>
          <option value="">Sem categoria</option>
          {['Operacional', 'Embalagens', 'Transporte', 'Taxas', 'Marketing', 'Outros'].map((c) => <option key={c}>{c}</option>)}
        </Select>
      )}
      {kind === 'revenue' && <Checkbox label="Valor já recebido" checked={received} onChange={setReceived} />}
      <div className="flex justify-end gap-3 pt-2"><Button variant="ghost" onClick={onClose}>Cancelar</Button><Button type="submit" loading={saving}>Registrar</Button></div>
    </form>
  );
}

export default function FinancialPage() {
  useDocumentTitle('Financeiro');
  const [period, setPeriod] = useState<Period>(periodPreset('month'));
  const [tab, setTab] = useState<Tab>('revenues');
  const [revFilter, setRevFilter] = useState<'' | 'true' | 'false'>('');
  const [expType, setExpType] = useState<'' | ExpenseType>('');
  const [form, setForm] = useState<Kind | null>(null);
  const deps = [period.from, period.to];

  const summary = useAsync(() => financialService.summary(period), deps);
  const monthly = useAsync(() => financialService.monthly(period), deps);
  const revenues = useAsync(() => financialService.revenues({ ...period, received: revFilter === '' ? undefined : revFilter === 'true' }), [...deps, revFilter]);
  const expenses = useAsync(() => financialService.expenses({ ...period, type: expType || undefined }), [...deps, expType]);

  const reloadAll = () => { summary.reload(); monthly.reload(); revenues.reload(); expenses.reload(); };
  const s = summary.data;
  const sl = summary.loading && !s;

  const revCols: Column<Revenue>[] = [
    { key: 'd', header: 'Data', render: (r) => <span className="text-ink-soft">{date(r.date)}</span> },
    { key: 'desc', header: 'Descrição', render: (r) => <span className="font-medium">{r.description}</span> },
    { key: 's', header: 'Situação', render: (r) => r.received ? <Badge tone="success" dot>Recebido</Badge> : <Badge tone="warning" dot>A receber</Badge> },
    { key: 'v', header: 'Valor', align: 'right', render: (r) => <b className="tabular-nums text-emerald-700">+{money(r.amount)}</b> },
  ];
  const expCols: Column<Expense>[] = [
    { key: 'd', header: 'Data', render: (e) => <span className="text-ink-soft">{date(e.date)}</span> },
    { key: 'desc', header: 'Descrição', render: (e) => <div><p className="font-medium">{e.description}</p>{e.category && <p className="text-xs text-ink-soft">{e.category}</p>}</div> },
    { key: 't', header: 'Tipo', render: (e) => e.type === 'COMPRA_MERCADORIA' ? <Badge tone="gold">Mercadorias</Badge> : <Badge>Despesa</Badge> },
    { key: 'v', header: 'Valor', align: 'right', render: (e) => <b className="tabular-nums text-wine-700">−{money(e.amount)}</b> },
  ];

  return (
    <>
      <PageHeader eyebrow="Financeiro" title="Gestão financeira" description="Receitas, despesas e resultado do período."
        actions={<PeriodFilter value={period} onChange={setPeriod} />} />

      {summary.error ? <ErrorState message={summary.error} onRetry={summary.reload} /> : (
        <div className="mb-6 grid grid-cols-2 gap-4 lg:grid-cols-3 xl:grid-cols-6">
          <StatCard label="Faturamento" value={money(s?.revenue)} icon={CircleDollarSign} loading={sl} />
          <StatCard label="Lucro" value={money(s?.profit)} icon={TrendingUp} loading={sl} tone={s && s.profit < 0 ? 'alert' : 'default'} />
          <StatCard label="Total de receitas" value={money(s?.totalIncome)} icon={ArrowUpCircle} loading={sl} />
          <StatCard label="Total de despesas" value={money(s?.totalExpenses)} icon={ArrowDownCircle} loading={sl} />
          <StatCard label="Recebido" value={money(s?.received)} icon={CheckCircle2} loading={sl} />
          <StatCard label="A receber" value={money(s?.receivable)} icon={HandCoins} loading={sl} tone="gold" />
        </div>
      )}

      <Panel title="Receitas x despesas" className="mb-6">
        <div className="p-4">
          <AsyncContent {...monthly} onRetry={monthly.reload} empty={<p className="py-10 text-center text-sm text-ink-soft">Sem lançamentos no período.</p>}>
            {(d) => <IncomeExpenseChart data={d} />}
          </AsyncContent>
        </div>
      </Panel>

      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <Tabs value={tab} onChange={setTab} tabs={[{ value: 'revenues', label: 'Receitas' }, { value: 'expenses', label: 'Despesas' }]} />
        <div className="flex flex-wrap gap-2">
          {tab === 'revenues' ? <Button onClick={() => setForm('revenue')}><Plus className="size-4" /> Registrar entrada</Button> : (
            <><Button variant="outline" onClick={() => setForm('purchase')}><Wallet className="size-4" /> Compra de mercadorias</Button><Button onClick={() => setForm('expense')}><Plus className="size-4" /> Registrar despesa</Button></>
          )}
        </div>
      </div>

      {tab === 'revenues' ? (
        <Panel>
          <div className="border-b border-line p-4 sm:w-64">
            <Select value={revFilter} onChange={(e) => setRevFilter(e.target.value as typeof revFilter)} aria-label="Situação">
              <option value="">Todas as receitas</option><option value="true">Valores recebidos</option><option value="false">Valores a receber</option>
            </Select>
          </div>
          <AsyncContent {...revenues} onRetry={revenues.reload} empty={<EmptyState title="Nenhuma receita no período" />}>
            {(rows) => <DataTable columns={revCols} rows={rows} rowKey={(r) => String(r.id)} />}
          </AsyncContent>
        </Panel>
      ) : (
        <Panel>
          <div className="border-b border-line p-4 sm:w-64">
            <Select value={expType} onChange={(e) => setExpType(e.target.value as typeof expType)} aria-label="Tipo de despesa">
              <option value="">Todas as despesas</option><option value="DESPESA">Despesas operacionais</option><option value="COMPRA_MERCADORIA">Compras de mercadorias</option>
            </Select>
          </div>
          <AsyncContent {...expenses} onRetry={expenses.reload} empty={<EmptyState title="Nenhuma despesa no período" />}>
            {(rows) => <DataTable columns={expCols} rows={rows} rowKey={(e) => String(e.id)} />}
          </AsyncContent>
        </Panel>
      )}

      <Modal open={!!form} onClose={() => setForm(null)} title={form === 'revenue' ? 'Registrar entrada' : form === 'purchase' ? 'Compra de mercadorias' : 'Registrar despesa'}>
        {form && <EntryForm key={form} kind={form} onClose={() => setForm(null)} onSaved={reloadAll} />}
      </Modal>
    </>
  );
}
