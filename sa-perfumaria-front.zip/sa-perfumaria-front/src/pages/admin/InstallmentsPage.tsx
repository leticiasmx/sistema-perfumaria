import { useMemo, useState, type FormEvent } from 'react';
import { AlertTriangle, BellRing, CalendarClock, CheckCircle2, HandCoins, MessageCircle, Search } from 'lucide-react';
import { installmentService } from '@/services/installmentService';
import { useAsync } from '@/hooks/useAsync';
import { useDocumentTitle } from '@/hooks/useDocumentTitle';
import { useToast } from '@/contexts/ToastContext';
import {
  AsyncContent, Badge, Button, DataTable, EmptyState, Input, Modal, PageHeader, Panel, StatCard, Tabs, Textarea, buttonClass, type Column,
} from '@/components/ui';
import { date, daysUntil, money, phone, today } from '@/utils/format';
import { INSTALLMENT_STATUS } from '@/utils/status';
import { DUE_SOON_DAYS } from '@/config/store';
import { chargeMessage, waLink } from '@/utils/whatsapp';
import { errorMessage } from '@/utils/errors';
import { cn } from '@/utils/cn';
import type { Installment } from '@/interfaces';

type Tab = 'all' | 'paid' | 'open' | 'overdue' | 'soon';
const isSoon = (i: Installment) => i.status === 'EM_ABERTO' && daysUntil(i.dueDate) >= 0 && daysUntil(i.dueDate) <= DUE_SOON_DAYS;

function PayForm({ inst, onClose, onPaid }: { inst: Installment; onClose: () => void; onPaid: () => void }) {
  const toast = useToast();
  const [when, setWhen] = useState(today());
  const [amount, setAmount] = useState(String(inst.amount));
  const [saving, setSaving] = useState(false);
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    const v = Number(amount.replace(',', '.'));
    if (!(v > 0) || !when) return toast.error('Informe data e valor do pagamento.');
    setSaving(true);
    try { await installmentService.pay(inst.id, { paymentDate: when, amount: v }); toast.success('Pagamento registrado.'); onPaid(); onClose(); }
    catch (err) { toast.error(errorMessage(err)); } finally { setSaving(false); }
  };
  return (
    <form onSubmit={submit} className="space-y-4">
      <div className="rounded-2xl bg-ivory p-4 text-sm">
        <p className="font-semibold">{inst.customer.name}</p>
        <p className="text-ink-soft">Parcela {inst.number}/{inst.totalInstallments} · vencimento {date(inst.dueDate)} · {money(inst.amount)}</p>
      </div>
      <div className="grid gap-4 sm:grid-cols-2">
        <Input label="Data do pagamento" type="date" value={when} onChange={(e) => setWhen(e.target.value)} required />
        <Input label="Valor recebido (R$)" inputMode="decimal" value={amount} onChange={(e) => setAmount(e.target.value)} required />
      </div>
      <div className="flex justify-end gap-3 pt-2"><Button variant="ghost" onClick={onClose}>Cancelar</Button><Button type="submit" loading={saving}><CheckCircle2 className="size-4" /> Confirmar pagamento</Button></div>
    </form>
  );
}

function ChargeForm({ inst, onClose }: { inst: Installment; onClose: () => void }) {
  const [text, setText] = useState(() => chargeMessage(inst));
  return (
    <div className="space-y-4">
      <Textarea label="Mensagem de cobrança" value={text} onChange={(e) => setText(e.target.value)} rows={9} hint="Edite à vontade antes de enviar." />
      <div className="flex justify-end gap-3">
        <Button variant="ghost" onClick={onClose}>Fechar</Button>
        <a href={waLink(inst.customer.phone, text)} target="_blank" rel="noreferrer" onClick={onClose} className={buttonClass('whatsapp')}><MessageCircle className="size-4" /> Abrir no WhatsApp</a>
      </div>
    </div>
  );
}

export default function InstallmentsPage() {
  useDocumentTitle('Parcelas e cobranças');
  const [tab, setTab] = useState<Tab>('all');
  const [search, setSearch] = useState('');
  const [paying, setPaying] = useState<Installment | null>(null);
  const [charging, setCharging] = useState<Installment | null>(null);
  const list = useAsync(() => installmentService.list(), []);

  const all = list.data ?? [];
  const groups = useMemo(() => ({
    all, paid: all.filter((i) => i.status === 'PAGA'), open: all.filter((i) => i.status === 'EM_ABERTO'),
    overdue: all.filter((i) => i.status === 'VENCIDA'), soon: all.filter(isSoon),
  }), [all]);
  const rows = groups[tab].filter((i) => !search || i.customer.name.toLowerCase().includes(search.toLowerCase()) || i.customer.phone.includes(search.replace(/\D/g, '') || '§'));
  const sum = (l: Installment[]) => l.reduce((s, i) => s + i.amount, 0);

  const columns: Column<Installment>[] = [
    { key: 'c', header: 'Cliente', render: (i) => <div><p className="font-semibold">{i.customer.name}</p><p className="text-xs text-ink-soft md:hidden">{phone(i.customer.phone)}</p></div> },
    { key: 'p', header: 'Telefone', hideOnMobile: true, render: (i) => <span className="whitespace-nowrap text-ink-soft">{phone(i.customer.phone)}</span> },
    { key: 'n', header: 'Parcela', align: 'center', render: (i) => <span className="font-medium">{i.number}/{i.totalInstallments}</span> },
    { key: 'v', header: 'Valor', align: 'right', render: (i) => <b className="tabular-nums">{money(i.amount)}</b> },
    { key: 'd', header: 'Vencimento', render: (i) => {
      const d = daysUntil(i.dueDate);
      return <div><p>{date(i.dueDate)}</p>{i.status !== 'PAGA' && <p className={cn('text-[11px] font-semibold', i.status === 'VENCIDA' ? 'text-wine-700' : isSoon(i) ? 'text-amber-700' : 'text-ink-soft')}>
        {d < 0 ? `${-d} dia(s) em atraso` : d === 0 ? 'Vence hoje' : `Em ${d} dia(s)`}</p>}
        {i.status === 'PAGA' && i.paymentDate && <p className="text-[11px] text-ink-soft">Pago em {date(i.paymentDate)}</p>}</div>;
    } },
    { key: 's', header: 'Status', render: (i) => (
      <div className="flex flex-col items-start gap-1">
        <Badge tone={INSTALLMENT_STATUS[i.status]?.tone} dot>{INSTALLMENT_STATUS[i.status]?.label ?? i.status}</Badge>
        {isSoon(i) && <Badge tone="warning"><BellRing className="size-3" /> Próxima</Badge>}
      </div>) },
    { key: 'a', header: '', align: 'right', render: (i) => i.status === 'PAGA' ? null : (
      <div className="flex justify-end gap-2">
        <Button size="sm" variant="outline" onClick={() => setCharging(i)}><MessageCircle className="size-3.5" /> Cobrar</Button>
        <Button size="sm" onClick={() => setPaying(i)}>Registrar pagamento</Button>
      </div>) },
  ];

  return (
    <>
      <PageHeader eyebrow="Financeiro" title="Parcelas e cobranças" description="Acompanhe vencimentos, registre pagamentos e envie lembretes pelo WhatsApp." />

      <div className="mb-6 grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard label="Em aberto" value={money(sum(groups.open))} icon={HandCoins} loading={list.loading && !list.data} hint={`${groups.open.length} parcela(s)`} />
        <StatCard label="Vencidas" value={money(sum(groups.overdue))} icon={AlertTriangle} tone={groups.overdue.length ? 'alert' : 'default'} loading={list.loading && !list.data} hint={`${groups.overdue.length} parcela(s)`} />
        <StatCard label={`Vencem em até ${DUE_SOON_DAYS} dias`} value={money(sum(groups.soon))} icon={CalendarClock} tone="gold" loading={list.loading && !list.data} hint={`${groups.soon.length} parcela(s)`} />
        <StatCard label="Recebido em parcelas" value={money(sum(groups.paid))} icon={CheckCircle2} loading={list.loading && !list.data} hint={`${groups.paid.length} parcela(s)`} />
      </div>

      {groups.overdue.length > 0 && tab !== 'overdue' && (
        <button onClick={() => setTab('overdue')} className="mb-4 flex w-full items-center gap-3 rounded-2xl bg-wine-50 px-5 py-3.5 text-left text-sm text-wine-900 ring-1 ring-wine-500/25 transition hover:bg-wine-50/70">
          <AlertTriangle className="size-5 shrink-0 text-wine-700" />
          <span><b>{groups.overdue.length} parcela(s) vencida(s)</b> somando {money(sum(groups.overdue))}. Clique para ver e cobrar.</span>
        </button>
      )}

      <Panel>
        <div className="flex flex-col gap-3 border-b border-line p-4 lg:flex-row lg:items-center lg:justify-between">
          <Tabs value={tab} onChange={setTab} tabs={[
            { value: 'all', label: 'Todas', count: groups.all.length }, { value: 'paid', label: 'Pagas', count: groups.paid.length },
            { value: 'open', label: 'Em aberto', count: groups.open.length }, { value: 'overdue', label: 'Vencidas', count: groups.overdue.length },
            { value: 'soon', label: 'Próximas do vencimento', count: groups.soon.length },
          ]} />
          <div className="lg:w-72"><Input placeholder="Cliente ou telefone" value={search} onChange={(e) => setSearch(e.target.value)} icon={<Search className="size-4" />} aria-label="Buscar parcela" /></div>
        </div>
        <AsyncContent {...list} onRetry={list.reload} isEmpty={() => rows.length === 0} empty={<EmptyState icon={<CalendarClock className="size-6" />} title="Nenhuma parcela nesta aba" />}>
          {() => <DataTable columns={columns} rows={rows} rowKey={(i) => String(i.id)}
            rowClassName={(i) => (i.status === 'VENCIDA' ? 'bg-wine-50/50' : isSoon(i) ? 'bg-amber-50/50' : undefined)} />}
        </AsyncContent>
      </Panel>

      <Modal open={!!paying} onClose={() => setPaying(null)} title="Registrar pagamento" size="sm">
        {paying && <PayForm inst={paying} onClose={() => setPaying(null)} onPaid={list.reload} />}
      </Modal>
      <Modal open={!!charging} onClose={() => setCharging(null)} title="Mensagem de cobrança" description={charging ? `${charging.customer.name} · ${phone(charging.customer.phone)}` : undefined}>
        {charging && <ChargeForm inst={charging} onClose={() => setCharging(null)} />}
      </Modal>
    </>
  );
}
