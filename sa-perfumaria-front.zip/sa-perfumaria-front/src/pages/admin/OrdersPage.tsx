import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Ban, History, MessageCircle, Receipt, UserRound } from 'lucide-react';
import { orderService } from '@/services/orderService';
import { customerService } from '@/services/customerService';
import { useAsync } from '@/hooks/useAsync';
import { useDocumentTitle } from '@/hooks/useDocumentTitle';
import { useToast } from '@/contexts/ToastContext';
import {
  AsyncContent, Badge, Button, DataTable, EmptyState, Loading, Modal, PageHeader, Panel, Select, Tabs, Textarea, type Column,
} from '@/components/ui';
import { date, dateTime, money, phone } from '@/utils/format';
import { ORDER_STATUS } from '@/utils/status';
import { paymentLabel } from '@/config/store';
import { errorMessage } from '@/utils/errors';
import { waLink } from '@/utils/whatsapp';
import type { Id, Order, OrderStatus } from '@/interfaces';

const STATUS_OPTIONS = Object.entries(ORDER_STATUS).filter(([k]) => k !== 'CANCELADO') as [OrderStatus, { label: string }][];

function OrderDetail({ id, onChanged }: { id: Id; onChanged: () => void }) {
  const toast = useToast();
  const [tab, setTab] = useState<'items' | 'history' | 'customer'>('items');
  const order = useAsync(() => orderService.get(id), [id]);
  const history = useAsync(() => (tab === 'history' ? orderService.history(id) : Promise.resolve(undefined)), [id, tab]);
  const custOrders = useAsync(() => (tab === 'customer' && order.data ? customerService.orders(order.data.customer.id) : Promise.resolve(undefined)), [tab, order.data?.customer.id]);
  const [status, setStatus] = useState<OrderStatus | ''>('');
  const [saving, setSaving] = useState(false);
  const [cancelOpen, setCancelOpen] = useState(false);
  const [reason, setReason] = useState('');

  useEffect(() => { if (order.data) setStatus(order.data.status); }, [order.data]);

  const update = async () => {
    if (!status || !order.data || status === order.data.status) return;
    setSaving(true);
    try { const o = await orderService.updateStatus(id, status); order.setData(o); toast.success('Status atualizado.'); onChanged(); history.reload(); }
    catch (err) { toast.error(errorMessage(err)); } finally { setSaving(false); }
  };
  const cancel = async () => {
    setSaving(true);
    try { const o = await orderService.cancel(id, reason.trim() || undefined); order.setData(o); setCancelOpen(false); toast.success('Pedido cancelado.'); onChanged(); }
    catch (err) { toast.error(errorMessage(err)); } finally { setSaving(false); }
  };

  if (order.loading && !order.data) return <Loading />;
  if (order.error || !order.data) return <EmptyState title="Não foi possível carregar o pedido" message={order.error ?? undefined} />;
  const o = order.data;
  const cancelled = o.status === 'CANCELADO';

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 gap-4 rounded-2xl bg-ivory p-4 text-sm">
        <div><p className="eyebrow !text-[10px]">Cliente</p><p className="mt-1 font-semibold">{o.customer.name}</p><p className="text-ink-soft">{phone(o.customer.phone)}</p></div>
        <div><p className="eyebrow !text-[10px]">Data</p><p className="mt-1 font-semibold">{dateTime(o.createdAt)}</p></div>
        <div><p className="eyebrow !text-[10px]">Pagamento</p><p className="mt-1 font-semibold">{paymentLabel(o.paymentMethod)}{o.installments > 1 && ` · ${o.installments}x`}</p></div>
        <div><p className="eyebrow !text-[10px]">Status</p><div className="mt-1"><Badge tone={ORDER_STATUS[o.status]?.tone}>{ORDER_STATUS[o.status]?.label}</Badge></div></div>
      </div>

      {!cancelled && (
        <div className="flex flex-wrap items-end gap-3">
          <div className="min-w-48 flex-1">
            <Select label="Atualizar status" value={status} onChange={(e) => setStatus(e.target.value as OrderStatus)}>
              {STATUS_OPTIONS.map(([v, s]) => <option key={v} value={v}>{s.label}</option>)}
            </Select>
          </div>
          <Button onClick={update} loading={saving} disabled={status === o.status}>Salvar status</Button>
          <Button variant="danger" onClick={() => setCancelOpen(true)}><Ban className="size-4" /> Cancelar pedido</Button>
        </div>
      )}
      <a href={waLink(o.customer.phone, `Olá, ${o.customer.name.split(' ')[0]}! Sobre seu pedido ${o.number ?? `#${o.id}`}: `)} target="_blank" rel="noreferrer"
        className="inline-flex items-center gap-2 text-sm font-semibold text-[#178246] hover:underline"><MessageCircle className="size-4" /> Conversar com a cliente</a>

      <Tabs value={tab} onChange={setTab} tabs={[{ value: 'items', label: 'Itens' }, { value: 'history', label: 'Histórico' }, { value: 'customer', label: 'Compras da cliente' }]} />

      {tab === 'items' && (
        <div>
          <ul className="divide-y divide-line text-sm">
            {o.items.map((i) => (
              <li key={String(i.productId)} className="flex justify-between gap-3 py-2.5">
                <span>{i.quantity}x {i.productName ?? `Produto ${i.productId}`}</span>
                <span className="tabular-nums">{i.subtotal != null ? money(i.subtotal) : '—'}</span>
              </li>
            ))}
          </ul>
          <div className="gold-rule my-3" />
          <dl className="space-y-1 text-sm">
            <div className="flex justify-between"><dt className="text-ink-soft">Subtotal</dt><dd>{money(o.subtotal)}</dd></div>
            {o.discount > 0 && <div className="flex justify-between text-wine-700"><dt>Desconto{o.couponCode && ` (${o.couponCode})`}</dt><dd>−{money(o.discount)}</dd></div>}
            <div className="flex justify-between pt-1 text-base font-semibold"><dt>Total</dt><dd className="font-display text-2xl">{money(o.total)}</dd></div>
          </dl>
        </div>
      )}
      {tab === 'history' && (
        <AsyncContent {...history} onRetry={history.reload} empty={<EmptyState icon={<History className="size-6" />} title="Sem alterações registradas" />}>
          {(h) => (
            <ol className="relative space-y-5 border-l border-gold-light pl-6">
              {h.map((e) => (
                <li key={String(e.id)} className="relative">
                  <span className="absolute -left-[29px] top-1 size-3 rounded-full bg-gold ring-4 ring-white" />
                  <p className="text-sm font-semibold">{ORDER_STATUS[e.status]?.label ?? e.status}</p>
                  <p className="text-xs text-ink-soft">{dateTime(e.changedAt)}{e.note && ` · ${e.note}`}</p>
                </li>
              ))}
            </ol>
          )}
        </AsyncContent>
      )}
      {tab === 'customer' && (
        <AsyncContent {...custOrders} onRetry={custOrders.reload} empty={<EmptyState icon={<UserRound className="size-6" />} title="Sem outras compras" />}>
          {(list) => (
            <ul className="divide-y divide-line text-sm">
              {list.map((c) => (
                <li key={String(c.id)} className="flex items-center justify-between gap-3 py-2.5">
                  <span>{c.number ?? `#${c.id}`} · {date(c.createdAt)}</span>
                  <span className="flex items-center gap-3"><Badge tone={ORDER_STATUS[c.status]?.tone}>{ORDER_STATUS[c.status]?.label}</Badge><b className="tabular-nums">{money(c.total)}</b></span>
                </li>
              ))}
            </ul>
          )}
        </AsyncContent>
      )}

      <Modal open={cancelOpen} onClose={() => setCancelOpen(false)} title="Cancelar pedido" size="sm"
        footer={<><Button variant="ghost" onClick={() => setCancelOpen(false)}>Voltar</Button><Button onClick={cancel} loading={saving}>Confirmar cancelamento</Button></>}>
        <p className="mb-4 text-sm text-ink-soft">O pedido {o.number ?? `#${o.id}`} será cancelado. Estoque e parcelas são tratados pelo sistema conforme as regras do back-end.</p>
        <Textarea label="Motivo (opcional)" value={reason} onChange={(e) => setReason(e.target.value)} rows={3} />
      </Modal>
    </div>
  );
}

export default function OrdersPage() {
  useDocumentTitle('Pedidos');
  const [params, setParams] = useSearchParams();
  const [status, setStatus] = useState<OrderStatus | ''>('');
  const [from, setFrom] = useState('');
  const [to, setTo] = useState('');
  const orders = useAsync(() => orderService.list({ status, from: from || undefined, to: to || undefined }), [status, from, to]);
  const openId = params.get('id');
  const setOpen = (id?: Id) => { const n = new URLSearchParams(params); id != null ? n.set('id', String(id)) : n.delete('id'); setParams(n, { replace: true }); };

  const columns: Column<Order>[] = [
    { key: 'n', header: 'Pedido', render: (o) => <span className="font-semibold text-wine-700">{o.number ?? `#${o.id}`}</span> },
    { key: 'c', header: 'Cliente', render: (o) => <span className="font-medium">{o.customer.name}</span> },
    { key: 'd', header: 'Data', render: (o) => <span className="text-ink-soft">{date(o.createdAt)}</span> },
    { key: 't', header: 'Total', align: 'right', render: (o) => <b className="tabular-nums">{money(o.total)}</b> },
    { key: 'p', header: 'Pagamento', hideOnMobile: true, render: (o) => <span className="text-ink-soft">{paymentLabel(o.paymentMethod)}{o.installments > 1 && ` ${o.installments}x`}</span> },
    { key: 's', header: 'Status', render: (o) => <Badge tone={ORDER_STATUS[o.status]?.tone}>{ORDER_STATUS[o.status]?.label ?? o.status}</Badge> },
  ];

  return (
    <>
      <PageHeader eyebrow="Vendas" title="Pedidos" description="Acompanhe, atualize e consulte o histórico de cada pedido." />
      <Panel>
        <div className="space-y-3 border-b border-line p-4">
          <Tabs value={status} onChange={setStatus} tabs={[{ value: '' as const, label: 'Todos' }, ...(Object.entries(ORDER_STATUS) as [OrderStatus, { label: string }][]).map(([v, s]) => ({ value: v, label: s.label }))]} />
          <div className="flex flex-wrap items-center gap-2 text-sm">
            <span className="text-ink-soft">Período:</span>
            <input type="date" value={from} onChange={(e) => setFrom(e.target.value)} aria-label="Data inicial" className="h-10 rounded-xl border border-line px-3 outline-none focus:border-gold" />
            <span className="text-ink-soft">até</span>
            <input type="date" value={to} onChange={(e) => setTo(e.target.value)} aria-label="Data final" className="h-10 rounded-xl border border-line px-3 outline-none focus:border-gold" />
            {(from || to) && <Button size="sm" variant="ghost" onClick={() => { setFrom(''); setTo(''); }}>Limpar</Button>}
          </div>
        </div>
        <AsyncContent {...orders} onRetry={orders.reload} empty={<EmptyState icon={<Receipt className="size-6" />} title="Nenhum pedido encontrado" message="Ajuste os filtros de status ou período." />}>
          {(rows) => <DataTable columns={columns} rows={rows} rowKey={(o) => String(o.id)} onRowClick={(o) => setOpen(o.id)} />}
        </AsyncContent>
      </Panel>
      <Modal side open={!!openId} onClose={() => setOpen()} title="Detalhes do pedido">
        {openId && <OrderDetail id={openId} onChanged={orders.reload} />}
      </Modal>
    </>
  );
}
