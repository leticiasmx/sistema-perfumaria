import { useState } from 'react';
import { Cake, MessageCircle, Search, Users } from 'lucide-react';
import { customerService } from '@/services/customerService';
import { useAsync } from '@/hooks/useAsync';
import { useDebounce } from '@/hooks/useDebounce';
import { useDocumentTitle } from '@/hooks/useDocumentTitle';
import { AsyncContent, Badge, DataTable, EmptyState, Input, Modal, PageHeader, Panel, StatCard, Tabs, type Column } from '@/components/ui';
import { date, dayMonth, money, phone } from '@/utils/format';
import { ORDER_STATUS } from '@/utils/status';
import { birthdayMessage, waLink } from '@/utils/whatsapp';
import type { Customer } from '@/interfaces';

function CustomerHistory({ customer }: { customer: Customer }) {
  const orders = useAsync(() => customerService.orders(customer.id), [customer.id]);
  return (
    <div className="space-y-5">
      <div className="grid grid-cols-3 gap-3">
        <div className="rounded-2xl bg-ivory p-4"><p className="text-xs text-ink-soft">Total comprado</p><p className="mt-1 font-display text-2xl font-semibold">{money(customer.totalSpent)}</p></div>
        <div className="rounded-2xl bg-ivory p-4"><p className="text-xs text-ink-soft">Pedidos</p><p className="mt-1 font-display text-2xl font-semibold">{customer.ordersCount ?? 0}</p></div>
        <div className="rounded-2xl bg-ivory p-4"><p className="text-xs text-ink-soft">Aniversário</p><p className="mt-1 font-display text-2xl font-semibold">{dayMonth(customer.birthDate)}</p></div>
      </div>
      <a href={waLink(customer.phone, `Olá, ${customer.name.split(' ')[0]}! `)} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 text-sm font-semibold text-[#178246] hover:underline">
        <MessageCircle className="size-4" /> Abrir conversa no WhatsApp
      </a>
      <div>
        <h3 className="mb-2 text-lg font-semibold">Histórico de compras</h3>
        <AsyncContent {...orders} onRetry={orders.reload} empty={<p className="py-6 text-center text-sm text-ink-soft">Nenhuma compra registrada.</p>}>
          {(list) => (
            <ul className="divide-y divide-line text-sm">
              {list.map((o) => (
                <li key={String(o.id)} className="py-3">
                  <div className="flex items-center justify-between gap-3">
                    <span className="font-semibold">{o.number ?? `#${o.id}`} <span className="font-normal text-ink-soft">· {date(o.createdAt)}</span></span>
                    <b className="tabular-nums">{money(o.total)}</b>
                  </div>
                  <div className="mt-1 flex items-center justify-between gap-3">
                    <span className="truncate text-xs text-ink-soft">{o.items.map((i) => `${i.quantity}x ${i.productName ?? i.productId}`).join(', ')}</span>
                    <Badge tone={ORDER_STATUS[o.status]?.tone}>{ORDER_STATUS[o.status]?.label}</Badge>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </AsyncContent>
      </div>
    </div>
  );
}

export default function CustomersPage() {
  useDocumentTitle('Clientes');
  const [tab, setTab] = useState<'all' | 'birthdays'>('all');
  const [search, setSearch] = useState('');
  const q = useDebounce(search);
  const month = new Date().getMonth() + 1;
  const customers = useAsync(() => customerService.list(q || undefined), [q]);
  const birthdays = useAsync(() => customerService.birthdays(month), [month]);
  const [selected, setSelected] = useState<Customer | null>(null);

  const columns: Column<Customer>[] = [
    { key: 'n', header: 'Cliente', render: (c) => (
      <div className="flex items-center gap-3">
        <span className="grid size-9 shrink-0 place-items-center rounded-full bg-gold-50 font-display text-lg font-semibold text-gold-dark ring-1 ring-gold-light">{c.name.charAt(0)}</span>
        <span className="font-semibold">{c.name}</span>
      </div>) },
    { key: 'p', header: 'Telefone', render: (c) => <span className="whitespace-nowrap text-ink-soft">{phone(c.phone)}</span> },
    { key: 'b', header: 'Aniversário', hideOnMobile: true, render: (c) => <span className="text-ink-soft">{date(c.birthDate)}</span> },
    { key: 'o', header: 'Pedidos', align: 'center', hideOnMobile: true, render: (c) => c.ordersCount ?? 0 },
    { key: 't', header: 'Total', align: 'right', render: (c) => <b className="tabular-nums">{money(c.totalSpent)}</b> },
    { key: 'l', header: 'Último pedido', hideOnMobile: true, render: (c) => <span className="text-ink-soft">{date(c.lastOrderDate)}</span> },
  ];

  return (
    <>
      <PageHeader eyebrow="Vendas" title="Clientes" description="Cadastro, histórico de compras e aniversariantes." />
      <div className="mb-6 grid grid-cols-2 gap-4 lg:grid-cols-3">
        <StatCard label="Clientes cadastradas" value={customers.data?.length ?? 0} icon={Users} loading={customers.loading && !customers.data} hint={q ? 'no resultado da busca' : undefined} />
        <StatCard label="Aniversariantes do mês" value={birthdays.data?.length ?? 0} icon={Cake} tone="gold" loading={birthdays.loading && !birthdays.data} />
      </div>
      <div className="mb-4"><Tabs value={tab} onChange={setTab} tabs={[{ value: 'all', label: 'Todas' }, { value: 'birthdays', label: 'Aniversariantes do mês', count: birthdays.data?.length }]} /></div>

      {tab === 'all' ? (
        <Panel>
          <div className="border-b border-line p-4"><Input placeholder="Buscar por nome ou telefone" value={search} onChange={(e) => setSearch(e.target.value)} icon={<Search className="size-4" />} aria-label="Buscar cliente" /></div>
          <AsyncContent {...customers} onRetry={customers.reload} empty={<EmptyState icon={<Users className="size-6" />} title="Nenhuma cliente encontrada" message="As clientes são cadastradas automaticamente no primeiro pedido." />}>
            {(rows) => <DataTable columns={columns} rows={rows} rowKey={(c) => String(c.id)} onRowClick={setSelected} />}
          </AsyncContent>
        </Panel>
      ) : (
        <AsyncContent {...birthdays} onRetry={birthdays.reload} empty={<Panel><EmptyState icon={<Cake className="size-6" />} title="Nenhuma aniversariante este mês" /></Panel>}>
          {(list) => (
            <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
              {[...list].sort((a, b) => (a.birthDate ?? '').slice(5).localeCompare((b.birthDate ?? '').slice(5))).map((c) => (
                <div key={String(c.id)} className="card relative overflow-hidden p-5">
                  <div className="absolute -right-6 -top-6 size-24 rounded-full bg-gold-50" />
                  <Cake className="relative size-6 text-gold-dark" />
                  <p className="relative mt-3 font-display text-2xl font-semibold">{c.name}</p>
                  <p className="relative text-sm text-ink-soft">{dayMonth(c.birthDate)} · {phone(c.phone)}</p>
                  <a href={waLink(c.phone, birthdayMessage(c))} target="_blank" rel="noreferrer"
                    className="relative mt-4 inline-flex items-center gap-2 rounded-full bg-[#1f9d55] px-4 py-2 text-sm font-semibold text-white hover:bg-[#178246]">
                    <MessageCircle className="size-4" /> Enviar parabéns
                  </a>
                </div>
              ))}
            </div>
          )}
        </AsyncContent>
      )}

      <Modal side open={!!selected} onClose={() => setSelected(null)} title={selected?.name ?? ''} description={selected ? phone(selected.phone) : undefined}>
        {selected && <CustomerHistory customer={selected} />}
      </Modal>
    </>
  );
}
