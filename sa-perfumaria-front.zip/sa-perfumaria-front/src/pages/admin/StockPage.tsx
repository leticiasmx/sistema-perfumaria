import { useMemo, useState, type FormEvent } from 'react';
import { ArrowDownToLine, ArrowUpFromLine, PackagePlus, Search, AlertTriangle } from 'lucide-react';
import { stockService } from '@/services/stockService';
import { useAsync } from '@/hooks/useAsync';
import { useDocumentTitle } from '@/hooks/useDocumentTitle';
import { useToast } from '@/contexts/ToastContext';
import {
  AsyncContent, Badge, Button, DataTable, EmptyState, Input, Modal, PageHeader, Panel, Select, StatCard, Tabs, type Column,
} from '@/components/ui';
import { dateTime } from '@/utils/format';
import { errorMessage } from '@/utils/errors';
import { cn } from '@/utils/cn';
import type { Product, StockMovement, StockMovementType } from '@/interfaces';

type View = 'stock' | 'movements';

function EntryForm({ products, initial, onClose, onSaved }: { products: Product[]; initial?: Product; onClose: () => void; onSaved: () => void }) {
  const toast = useToast();
  const [productId, setProductId] = useState(initial ? String(initial.id) : '');
  const [quantity, setQuantity] = useState('');
  const [unitCost, setUnitCost] = useState('');
  const [note, setNote] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    const errs: Record<string, string> = {};
    if (!productId) errs.productId = 'Selecione o produto.';
    if (!(Number(quantity) > 0) || !Number.isInteger(Number(quantity))) errs.quantity = 'Informe uma quantidade inteira maior que zero.';
    setErrors(errs);
    if (Object.keys(errs).length) return;
    setSaving(true);
    try {
      await stockService.registerEntry({ productId, quantity: Number(quantity), unitCost: unitCost ? Number(unitCost.replace(',', '.')) : null, note: note.trim() || undefined });
      toast.success('Entrada registrada.');
      onSaved();
      onClose();
    } catch (err) { toast.error(errorMessage(err)); } finally { setSaving(false); }
  };

  return (
    <form onSubmit={submit} className="space-y-4" noValidate>
      <Select label="Produto" value={productId} onChange={(e) => setProductId(e.target.value)} error={errors.productId} required>
        <option value="">Selecione…</option>
        {products.map((p) => <option key={p.id} value={p.id}>{p.name} — atual: {p.stockQuantity}</option>)}
      </Select>
      <div className="grid gap-4 sm:grid-cols-2">
        <Input label="Quantidade" type="number" min={1} value={quantity} onChange={(e) => setQuantity(e.target.value)} error={errors.quantity} required />
        <Input label="Custo unitário (R$)" inputMode="decimal" value={unitCost} onChange={(e) => setUnitCost(e.target.value)} hint="Opcional" />
      </div>
      <Input label="Observação" value={note} onChange={(e) => setNote(e.target.value)} placeholder="Ex.: reposição do ciclo 18" />
      <div className="flex justify-end gap-3 pt-2"><Button variant="ghost" onClick={onClose}>Cancelar</Button><Button type="submit" loading={saving}>Registrar entrada</Button></div>
    </form>
  );
}

export default function StockPage() {
  useDocumentTitle('Estoque');
  const [view, setView] = useState<View>('stock');
  const [search, setSearch] = useState('');
  const [onlyLow, setOnlyLow] = useState(false);
  const [movType, setMovType] = useState<StockMovementType | ''>('');
  const [entryFor, setEntryFor] = useState<Product | null | undefined>(undefined);

  const stock = useAsync(() => stockService.list(), []);
  const movements = useAsync(() => (view === 'movements' ? stockService.movements({ type: movType }) : Promise.resolve([] as StockMovement[])), [view, movType]);

  const all = stock.data ?? [];
  const low = all.filter((p) => p.stockQuantity > 0 && p.stockQuantity <= p.minimumStock);
  const out = all.filter((p) => p.stockQuantity <= 0);
  const rows = useMemo(() => all
    .filter((p) => !search || p.name.toLowerCase().includes(search.toLowerCase()))
    .filter((p) => !onlyLow || p.stockQuantity <= p.minimumStock)
    .sort((a, b) => a.stockQuantity / Math.max(1, a.minimumStock) - b.stockQuantity / Math.max(1, b.minimumStock)), [all, search, onlyLow]);

  const stockCols: Column<Product>[] = [
    { key: 'n', header: 'Produto', render: (p) => <div><p className="font-semibold">{p.name}</p><p className="text-xs text-ink-soft">{p.brand?.name}</p></div> },
    { key: 'q', header: 'Disponível', align: 'center', render: (p) => <span className={cn('font-display text-2xl font-semibold tabular-nums', p.stockQuantity <= 0 ? 'text-wine-700' : p.stockQuantity <= p.minimumStock ? 'text-amber-700' : '')}>{p.stockQuantity}</span> },
    { key: 'm', header: 'Mínimo', align: 'center', hideOnMobile: true, render: (p) => p.minimumStock },
    { key: 'bar', header: 'Nível', hideOnMobile: true, render: (p) => {
      const pct = Math.min(100, (p.stockQuantity / Math.max(1, p.minimumStock * 3)) * 100);
      return <div className="h-1.5 w-32 overflow-hidden rounded-full bg-line"><div className={cn('h-full rounded-full', p.stockQuantity <= 0 ? 'bg-wine-700' : p.stockQuantity <= p.minimumStock ? 'bg-amber-500' : 'bg-emerald-600')} style={{ width: `${pct}%` }} /></div>;
    } },
    { key: 's', header: 'Situação', render: (p) => p.stockQuantity <= 0 ? <Badge tone="danger" dot>Esgotado</Badge> : p.stockQuantity <= p.minimumStock ? <Badge tone="warning" dot>Crítico</Badge> : <Badge tone="success" dot>Normal</Badge> },
    { key: 'a', header: '', align: 'right', render: (p) => <Button size="sm" variant="outline" onClick={() => setEntryFor(p)}><ArrowDownToLine className="size-3.5" /> Entrada</Button> },
  ];
  const movCols: Column<StockMovement>[] = [
    { key: 'd', header: 'Data', render: (m) => <span className="whitespace-nowrap text-ink-soft">{dateTime(m.date)}</span> },
    { key: 'p', header: 'Produto', render: (m) => <span className="font-medium">{m.productName}</span> },
    { key: 't', header: 'Tipo', render: (m) => m.type === 'ENTRADA'
      ? <Badge tone="success"><ArrowDownToLine className="size-3" /> Entrada</Badge> : <Badge tone="wine"><ArrowUpFromLine className="size-3" /> Saída</Badge> },
    { key: 'q', header: 'Qtd.', align: 'right', render: (m) => <b className="tabular-nums">{m.type === 'ENTRADA' ? '+' : '−'}{m.quantity}</b> },
    { key: 'n', header: 'Observação', hideOnMobile: true, render: (m) => <span className="text-ink-soft">{m.note ?? '—'}</span> },
  ];

  return (
    <>
      <PageHeader eyebrow="Catálogo" title="Controle de estoque" description="Quantidades, entradas, saídas e alertas de reposição."
        actions={<Button onClick={() => setEntryFor(null)}><PackagePlus className="size-4" /> Registrar entrada</Button>} />

      <div className="mb-6 grid grid-cols-2 gap-4 lg:grid-cols-3">
        <StatCard label="Produtos cadastrados" value={all.length} icon={PackagePlus} loading={stock.loading && !stock.data} />
        <StatCard label="Estoque crítico" value={low.length} icon={AlertTriangle} tone={low.length ? 'alert' : 'default'} loading={stock.loading && !stock.data} />
        <StatCard label="Esgotados" value={out.length} icon={AlertTriangle} tone={out.length ? 'alert' : 'default'} loading={stock.loading && !stock.data} />
      </div>

      <div className="mb-4"><Tabs value={view} onChange={setView} tabs={[{ value: 'stock', label: 'Posição atual' }, { value: 'movements', label: 'Movimentações' }]} /></div>

      {view === 'stock' ? (
        <Panel>
          <div className="flex flex-col gap-3 border-b border-line p-4 sm:flex-row sm:items-center">
            <div className="flex-1"><Input placeholder="Buscar produto" value={search} onChange={(e) => setSearch(e.target.value)} icon={<Search className="size-4" />} aria-label="Buscar produto" /></div>
            <Button variant={onlyLow ? 'primary' : 'outline'} onClick={() => setOnlyLow((v) => !v)}><AlertTriangle className="size-4" /> Somente críticos</Button>
          </div>
          <AsyncContent {...stock} onRetry={stock.reload} isEmpty={() => rows.length === 0} empty={<EmptyState title="Nenhum produto encontrado" />}>
            {() => <DataTable columns={stockCols} rows={rows} rowKey={(p) => String(p.id)} rowClassName={(p) => (p.stockQuantity <= 0 ? 'bg-wine-50/40' : undefined)} />}
          </AsyncContent>
        </Panel>
      ) : (
        <Panel>
          <div className="border-b border-line p-4 sm:w-64">
            <Select value={movType} onChange={(e) => setMovType(e.target.value as StockMovementType | '')} aria-label="Tipo de movimentação">
              <option value="">Entradas e saídas</option><option value="ENTRADA">Somente entradas</option><option value="SAIDA">Somente saídas</option>
            </Select>
          </div>
          <AsyncContent {...movements} onRetry={movements.reload} empty={<EmptyState title="Nenhuma movimentação" />}>
            {(m) => <DataTable columns={movCols} rows={m} rowKey={(x) => String(x.id)} />}
          </AsyncContent>
        </Panel>
      )}

      <Modal open={entryFor !== undefined} onClose={() => setEntryFor(undefined)} title="Registrar entrada" description="A quantidade será somada ao estoque atual.">
        <EntryForm key={String(entryFor?.id ?? "nova")} products={all} initial={entryFor ?? undefined} onClose={() => setEntryFor(undefined)} onSaved={() => { stock.reload(); movements.reload(); }} />
      </Modal>
    </>
  );
}
