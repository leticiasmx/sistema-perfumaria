import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App';
import { env } from './config/env';
import { api } from './services/api';
import './index.css';

async function bootstrap() {
  // ── mocks ─────────────────────────────────────────────────────────
  // Só carrega dados fictícios com VITE_USE_MOCKS=true.
  // Para remover os mocks do projeto: apague src/mocks e este bloco.
  if (env.useMocks) {
    const { installMocks } = await import('./mocks/mockAdapter');
    installMocks(api);
  }
  // ──────────────────────────────────────────────────────────────────
  document.title = env.storeName;
  createRoot(document.getElementById('root')!).render(
    <StrictMode>
      <App />
    </StrictMode>,
  );
}

void bootstrap();
