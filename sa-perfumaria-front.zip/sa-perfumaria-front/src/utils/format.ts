const brl = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' });

export const money = (v?: number | null) => brl.format(Number(v ?? 0));

/** Converte 'yyyy-MM-dd' ou ISO em Date sem deslocar o dia pelo fuso. */
export function parseDate(value?: string | null): Date | null {
  if (!value) return null;
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(value);
  if (m) return new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3]));
  const d = new Date(value);
  return isNaN(d.getTime()) ? null : d;
}

export function date(value?: string | null) {
  const d = parseDate(value);
  return d ? d.toLocaleDateString('pt-BR') : '—';
}

export function dateTime(value?: string | null) {
  const d = parseDate(value);
  return d ? d.toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' }) : '—';
}

export function dayMonth(value?: string | null) {
  const d = parseDate(value);
  return d ? d.toLocaleDateString('pt-BR', { day: '2-digit', month: 'short' }) : '—';
}

export function monthLabel(yyyyMm: string) {
  const [y, m] = yyyyMm.split('-').map(Number);
  return new Date(y, (m || 1) - 1, 1).toLocaleDateString('pt-BR', { month: 'short' }).replace('.', '');
}

export function phone(value?: string | null) {
  const d = (value || '').replace(/\D/g, '');
  if (d.length === 11) return `(${d.slice(0, 2)}) ${d.slice(2, 7)}-${d.slice(7)}`;
  if (d.length === 10) return `(${d.slice(0, 2)}) ${d.slice(2, 6)}-${d.slice(6)}`;
  return value || '—';
}

export const onlyDigits = (v: string) => v.replace(/\D/g, '');

export function maskPhone(v: string) {
  const d = onlyDigits(v).slice(0, 11);
  if (d.length <= 2) return d.length ? `(${d}` : '';
  if (d.length <= 6) return `(${d.slice(0, 2)}) ${d.slice(2)}`;
  if (d.length <= 10) return `(${d.slice(0, 2)}) ${d.slice(2, 6)}-${d.slice(6)}`;
  return `(${d.slice(0, 2)}) ${d.slice(2, 7)}-${d.slice(7)}`;
}

export const toISODate = (d: Date) =>
  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;

export const today = () => toISODate(new Date());

export function daysUntil(value?: string | null) {
  const d = parseDate(value);
  if (!d) return Infinity;
  const t = new Date();
  t.setHours(0, 0, 0, 0);
  return Math.round((d.getTime() - t.getTime()) / 86_400_000);
}

/** Presets de período usados nos filtros. */
export function periodPreset(preset: 'month' | 'last30' | 'quarter' | 'year') {
  const now = new Date();
  const to = toISODate(now);
  if (preset === 'month') return { from: toISODate(new Date(now.getFullYear(), now.getMonth(), 1)), to };
  if (preset === 'last30') return { from: toISODate(new Date(now.getTime() - 29 * 86_400_000)), to };
  if (preset === 'quarter') return { from: toISODate(new Date(now.getFullYear(), now.getMonth() - 2, 1)), to };
  return { from: toISODate(new Date(now.getFullYear(), 0, 1)), to };
}
