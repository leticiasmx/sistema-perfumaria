import { env } from '@/config/env';
import type { Installment, Order, Customer } from '@/interfaces';
import { date, money } from './format';
import { paymentLabel } from '@/config/store';

/** Normaliza para o formato do wa.me (DDI 55 + DDD + número). */
export function waNumber(phone: string) {
  const d = phone.replace(/\D/g, '');
  if (!d) return '';
  return d.startsWith('55') && d.length >= 12 ? d : `55${d}`;
}

export function waLink(phone: string, text?: string) {
  const n = waNumber(phone);
  return `https://wa.me/${n}${text ? `?text=${encodeURIComponent(text)}` : ''}`;
}

export const hasStoreWhatsapp = () => Boolean(env.whatsappNumber);
export const storeWaLink = (text?: string) => waLink(env.whatsappNumber, text);

export function orderMessage(order: Order) {
  const items = order.items
    .map((i) => `• ${i.quantity}x ${i.productName ?? `Produto ${i.productId}`}${i.subtotal != null ? ` — ${money(i.subtotal)}` : ''}`)
    .join('\n');
  return [
    `Olá! Acabei de fazer o pedido *${order.number ?? `#${order.id}`}* na loja ${env.storeName}.`,
    '',
    items,
    '',
    order.discount ? `Desconto: ${money(order.discount)}` : null,
    `Total: *${money(order.total)}*`,
    `Pagamento: ${paymentLabel(order.paymentMethod)}${order.installments > 1 ? ` em ${order.installments}x` : ''}`,
    `Nome: ${order.customer.name}`,
  ]
    .filter((l) => l !== null)
    .join('\n');
}

export function chargeMessage(inst: Installment) {
  const first = inst.customer.name.split(' ')[0];
  const overdue = inst.status === 'VENCIDA';
  return [
    `Olá, ${first}! Tudo bem? 💐`,
    overdue
      ? `Passando para lembrar que a parcela ${inst.number}/${inst.totalInstallments} do seu pedido, no valor de ${money(inst.amount)}, venceu em ${date(inst.dueDate)}.`
      : `Passando para lembrar que a parcela ${inst.number}/${inst.totalInstallments} do seu pedido, no valor de ${money(inst.amount)}, vence em ${date(inst.dueDate)}.`,
    'Se já tiver pago, por favor desconsidere esta mensagem. Qualquer dúvida, estou à disposição!',
    `— ${env.storeName}`,
  ].join('\n\n');
}

export function birthdayMessage(c: Customer) {
  return `Feliz aniversário, ${c.name.split(' ')[0]}! 🎉\n\nQue seu dia seja lindo e perfumado. Preparei um carinho especial para você este mês — me chama aqui para saber! 💝\n\n— ${env.storeName}`;
}
