import type { InstallmentStatus, OrderStatus } from '@/interfaces';

export type Tone = 'neutral' | 'gold' | 'wine' | 'success' | 'warning' | 'danger' | 'info';

export const ORDER_STATUS: Record<OrderStatus, { label: string; tone: Tone }> = {
  PENDENTE: { label: 'Pendente', tone: 'warning' },
  CONFIRMADO: { label: 'Confirmado', tone: 'info' },
  EM_SEPARACAO: { label: 'Em separação', tone: 'gold' },
  ENTREGUE: { label: 'Entregue', tone: 'success' },
  CANCELADO: { label: 'Cancelado', tone: 'danger' },
};

export const INSTALLMENT_STATUS: Record<InstallmentStatus, { label: string; tone: Tone }> = {
  PAGA: { label: 'Paga', tone: 'success' },
  EM_ABERTO: { label: 'Em aberto', tone: 'info' },
  VENCIDA: { label: 'Vencida', tone: 'danger' },
};
