import axios from 'axios';

/** Extrai uma mensagem legível de erros do Axios / Spring Boot. */
export function errorMessage(err: unknown, fallback = 'Não foi possível concluir a operação.') {
  if (axios.isAxiosError(err)) {
    if (!err.response) return 'Sem conexão com o servidor. Verifique se a API está no ar.';
    const data = err.response.data as Record<string, unknown> | string | undefined;
    if (typeof data === 'string' && data.trim()) return data;
    if (data && typeof data === 'object') {
      const msg = (data.message || data.error || data.detail || data.title) as string | undefined;
      if (msg) return msg;
    }
    const s = err.response.status;
    if (s === 401) return 'Sessão expirada. Faça login novamente.';
    if (s === 403) return 'Você não tem permissão para esta ação.';
    if (s === 404) return 'Recurso não encontrado.';
    if (s >= 500) return 'Erro no servidor. Tente novamente em instantes.';
  }
  if (err instanceof Error && err.message) return err.message;
  return fallback;
}

export const isNotFound = (err: unknown) => axios.isAxiosError(err) && err.response?.status === 404;
