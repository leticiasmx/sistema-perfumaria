import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import type { CouponValidation, Id, Product } from '@/interfaces';
import { safeStorage } from '@/services/api';

const CART_KEY = 'be.cart.v1';

export interface CartItem {
  productId: Id;
  name: string;
  brand?: string;
  imageUrl?: string | null;
  unitPrice: number; // preço exibido no momento — o back-end recalcula ao registrar
  originalPrice: number;
  quantity: number;
  stock: number;
}

interface CartState {
  items: CartItem[];
  count: number;
  subtotal: number;
  promoSavings: number;
  coupon: CouponValidation | null;
  discount: number;
  total: number;
  add: (p: Product, qty?: number) => void;
  setQuantity: (id: Id, qty: number) => void;
  remove: (id: Id) => void;
  clear: () => void;
  applyCoupon: (c: CouponValidation | null) => void;
}

const CartContext = createContext<CartState | null>(null);

export function CartProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<CartItem[]>(() => {
    try { return JSON.parse(safeStorage.get(CART_KEY) || '[]'); } catch { return []; }
  });
  const [coupon, setCoupon] = useState<CouponValidation | null>(null);

  useEffect(() => { safeStorage.set(CART_KEY, JSON.stringify(items)); }, [items]);
  // Qualquer mudança no carrinho invalida o cupom: ele precisa ser revalidado pela API.
  useEffect(() => { setCoupon(null); }, [items]);

  const value = useMemo<CartState>(() => {
    const subtotal = +items.reduce((s, i) => s + i.unitPrice * i.quantity, 0).toFixed(2);
    const promoSavings = +items.reduce((s, i) => s + (i.originalPrice - i.unitPrice) * i.quantity, 0).toFixed(2);
    const discount = coupon?.valid ? coupon.discount : 0;
    return {
      items,
      count: items.reduce((s, i) => s + i.quantity, 0),
      subtotal,
      promoSavings,
      coupon,
      discount,
      total: Math.max(0, +(subtotal - discount).toFixed(2)),
      add: (p, qty = 1) =>
        setItems((cur) => {
          const ex = cur.find((i) => String(i.productId) === String(p.id));
          if (ex) return cur.map((i) => (i === ex ? { ...i, quantity: Math.min(i.quantity + qty, p.stockQuantity) } : i));
          return [...cur, {
            productId: p.id, name: p.name, brand: p.brand?.name, imageUrl: p.imageUrl,
            unitPrice: p.promotionalPrice ?? p.price, originalPrice: p.price,
            quantity: Math.min(qty, p.stockQuantity), stock: p.stockQuantity,
          }];
        }),
      setQuantity: (id, qty) =>
        setItems((cur) => cur.map((i) => (String(i.productId) === String(id) ? { ...i, quantity: Math.max(1, Math.min(qty, i.stock)) } : i))),
      remove: (id) => setItems((cur) => cur.filter((i) => String(i.productId) !== String(id))),
      clear: () => setItems([]),
      applyCoupon: setCoupon,
    };
  }, [items, coupon]);

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

export function useCart() {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error('useCart deve ser usado dentro de CartProvider');
  return ctx;
}
