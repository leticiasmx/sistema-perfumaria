import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from 'react';
import { authService } from '@/services/authService';
import { safeStorage, tokenStorage, UNAUTHORIZED_EVENT } from '@/services/api';
import type { AuthUser, LoginRequest } from '@/interfaces';

const USER_KEY = 'be.admin.user';

interface AuthState {
  user: AuthUser | null;
  isAuthenticated: boolean;
  login: (p: LoginRequest) => Promise<void>;
  logout: () => void;
}

const AuthContext = createContext<AuthState | null>(null);

function readUser(): AuthUser | null {
  try { return JSON.parse(safeStorage.get(USER_KEY) || 'null'); } catch { return null; }
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [token, setToken] = useState(() => tokenStorage.get());
  const [user, setUser] = useState<AuthUser | null>(readUser);

  const logout = useCallback(() => {
    authService.logout();
    safeStorage.remove(USER_KEY);
    setToken(null);
    setUser(null);
  }, []);

  useEffect(() => {
    window.addEventListener(UNAUTHORIZED_EVENT, logout);
    return () => window.removeEventListener(UNAUTHORIZED_EVENT, logout);
  }, [logout]);

  const login = async (payload: LoginRequest) => {
    const res = await authService.login(payload);
    const u = res.user ?? { id: '', name: payload.email.split('@')[0], email: payload.email };
    safeStorage.set(USER_KEY, JSON.stringify(u));
    setToken(res.token);
    setUser(u);
  };

  return (
    <AuthContext.Provider value={{ user, isAuthenticated: Boolean(token), login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth deve ser usado dentro de AuthProvider');
  return ctx;
}
